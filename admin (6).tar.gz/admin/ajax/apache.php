<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');


include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";


if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	echo "Sorry, You Are Not Allowed to Access This Page";
	exit;
}

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Blackhost Path";
	exit;
}

$Command=$_REQUEST['Command'];
$Value=$_REQUEST['Value'];

if (stristr($Command,"directoryindex"))
{
$Value=str_replace(" ",",",$Value);
$Value=str_replace(";",",",$Value);

$Array=explode(",",$Value);

	$Value="";
	foreach ($Array as &$File) 
	{
		$File=trim($File);
		if ($File)
		{	
			if ($Value=="")
			{
			$Value=$File;
			}
			else
			{
			$Value.=" ".$File;
			}
		}
	}
	
	$Value=trim($Value);
	if ($Value=="")
	{
	$Value="index.html";
	}

}
elseif (stristr($Command,"maxkeepaliverequests"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<=0)
	{
	$Value="0";
	}
	elseif ($Value>500)
	{
	$Value="500";
	}

}
elseif (stristr($Command,"keepalivetimeout"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);

	if (trim($Value==""))
	{
	$Value="5";
	}
	else
	{
	$Value=intval($Value);
	}
	
	if ($Value<=0)
	{
	$Value="0";
	}
	elseif ($Value>=5)
	{
	$Value="5";
	}
	else
	{
	$Value=trim($Value);
	}
	
}
elseif (stristr($Command,"keepalive"))
{

	if ($Value=="1" or stristr($Value,"n"))
	{
	$Value="On";
	}
	else
	{
	$Value="Off";
	}
}
else
{
exit;
}

$Error=SSH ("$Command $Value",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

if (stristr($Error,"!"))
{
echo $Error;
}
else
{
echo $Value;
}


?>