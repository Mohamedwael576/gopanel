<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";




if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	echo "Sorry, You Are Not Allowed to Access This Page";
	exit;
}

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Go Panel Path";
	exit;
}

// Input ID
$ID=$_REQUEST['ID'];

$SiteID=$_REQUEST['SiteID'];
$Value=$_REQUEST['Value'];
$Value=str_replace('"','',$Value);
$Value=str_replace("'","",$Value);

if ($ID=="AccountID" and $Value!="")
{
SSH ("/go/cloudflare $Value --accountid",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
}
elseif ($ID=="AuthEmail" and $Value!="")
{
SSH ("/go/cloudflare $Value --authemail",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
}
elseif ($ID=="AuthKey" and $Value!="")
{
SSH ("/go/cloudflare $Value --authkey",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
}
else
{
SQL("UPDATE Site set ZoneID='$Value' where SiteID='$SiteID'");
}

echo $Value;

?>