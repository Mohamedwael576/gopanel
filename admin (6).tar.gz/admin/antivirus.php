<?php



include "navigator.php";
$Buttons="";
include "title.php";

	Echo "
	<div>
	<span class=Tab>{$LNG['ClamAVTitle']}</span>
	</div>
	";




	Echo "
	<form name=Form method=POST onsubmit='return ClamAVAntivirus(this);' autocomplete='off' action='$CurrentFileName'>
	<input type='hidden' name='MemberID' value='$MemberID'>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}<br>
	";
	
		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['Domain'];
		}
		

		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['AddonDomain'];
		}
		
		sort($Domains);
		
		echo "
		<select name='Domain' id='Domain' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{
			if ($Domain==$_REQUEST['Domain'])
			{
			echo "<option value='$Domain' selected>$Domain</option>";
			}
			else
			{
			echo "<option value='$Domain'>$Domain</option>";
			}
		}

		echo "
		</select>
	
		</div>

	<div class='DivInput {$Dir}DivInput'>
	<input type=submit value='{$LNG['Scan']}' Class=InputButton>
	</div>
	

	<div id=DivScan style='margin:10px' class=Message></div>


</form>


	";
	

?>