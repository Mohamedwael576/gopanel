<?php



include "navigator.php";
$Buttons="";
include "title.php";


		$Result = SQL("select * from Config where ConfigID=1");
		foreach ($Result as $Row)
		{
		$CloudflareAccountID=$Row['CloudflareAccountID'];
		$CloudflareAuthEmail=$Row['CloudflareAuthEmail'];		
		$CloudflareAuthKey=$Row['CloudflareAuthKey'];		
		}


		
			
			Echo "
			<form name=Form method=POST autocomplete='off' action='$CurrentFileName'>

			<div class='DivInput {$Dir}DivInput'>Account ID<br>
			
			<input type='text' value='$CloudflareAccountID' id='AccountID' onchange=\"Cloudflare('AccountID',encodeURI(document.getElementById('AccountID').value),'AccountID')\" class=InputText>
			
			</div>
		
	
			<div class='DivInput {$Dir}DivInput'>Auth Email<br>
			<input type='text' value='$CloudflareAuthEmail' id='AuthEmail' onchange=\"Cloudflare('AuthEmail',encodeURI(document.getElementById('AuthEmail').value),'AuthEmail')\" class=InputText>
			</div>

			<div class='DivInput {$Dir}DivInput'>Auth Key<br>
			<input type='text' value='$CloudflareAuthKey' id='AuthKey' onchange=\"Cloudflare('AuthKey',encodeURI(document.getElementById('AuthKey').value),'AuthKey')\" class=InputText> <a href='https://dash.cloudflare.com/profile/api-tokens'>Get Global API Key</a>
			</div>

			</form>
			


";

// End Scroll 
echo "
</div>
";


?>