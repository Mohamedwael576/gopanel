<?php

$IconControlID=0;

if ($_SESSION['SessionUsername']=="root")
{
$ServiceSql = "and Service like '%Root%'";
}
elseif ($_SESSION['SessionType']=="Website")
{
$ServiceSql = "and Service like '%Website%'";
}
elseif ($_SESSION['SessionType']=="Reseller")
{
$ServiceSql = "and Service like '%Reseller%'";
}

			
echo "
<div class=DivControl>
";
	
	
	$Sub=0;
	$SubTimes=0;
	if ($IconControlID=="" or $IconControlID=="0")
	{
	$Sql = "select * from Control where ControlID>=1 $ServiceSql ORDER BY Sort";
	}
	else
	{
	$Sql = "select * from Control where ControlID in ($IconControlID) $ServiceSql ORDER BY Sort";
	}
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		$SubControl=$Row['SubControl'];
		$ControlID=$Row['ControlID'];
		$ControlTarget=$Row['ControlTarget'];
		
		if ($SubControl==1)
		{
			$Sub++;		
			if ($Sub==1)
			{			
			$CollapsePlusNo=10000+$Sub+$SubTimes;
			
			$SubPlusCode="<img id=CollapsePlusImage$CollapsePlusNo onclick=\"Plus('CollapsePlus$CollapsePlusNo',$CollapsePlusNo,CollapsePlusImage$CollapsePlusNo)\" src='media/image/admin/$Theme/bulet-plus.gif' style='cursor:pointer' > ";
			}
			else
			{
			$SubPlusCode="";
			}
		
		}
		else
		{
		$Sub=0;
		$SubTimes++;
		}
		

		$ControlText=$LNG[$Row['Control']];
		$ControlFind="$ControlText {$LNG[$Row['ControlMenu']]} {$Row['SubFiles']}";

		
		$ControlMenuText=$LNG[$Row['ControlMenu']];
		
		$ControlMenuImage=$Row['ControlMenuImage'];
		
		$ControlMenuImage=str_replace(".png",".svg",$ControlMenuImage);
		
		$ControlUrl=$Row['ControlUrl'];
		$ControlTarget=$Row['ControlTarget'];
		
		$ControlUrl=str_replace("[ControlID]",$ControlID,$ControlUrl);
		
			$ControlUrlArray=explode("?",$ControlUrl);
			$ControlFile=$ControlUrlArray[0];
		


				
			if ($LastControlMenu!=$ControlMenuText)
			{
			

			
					$ControlTitle="";
					$MenuControlFind="";


					
					$ResultQ = SQL("select * from Control where ControlMenu='{$Row['ControlMenu']}' ORDER BY Sort");
					foreach ($ResultQ as $RowQ)
					{
					
						$BControlFind="{$LNG[$RowQ['Control']]} {$LNG[$RowQ['ControlMenu']]} {$LNG[$RowQ['SubFiles']]}";
						
						$MenuControlFind.="-$BControlFind-";

					}
				
			
					if ($_SESSION['SessionTheme']=="light")
					{
					$ColorMenuB="#E0E0E0";
					}
					else
					{
					$ColorMenuB="#23232E";
					}
			
				$CollapseControlMenu=str_replace(" ","",$ControlMenu);
				$CNO++;
				Echo "
				<div divid='Find' find='$MenuControlFind' class='MenuB {$Dir}MenuB' style='background:$ColorMenuB url(theme/{$_SESSION['SessionTheme']}/svg/over/$ControlMenuImage) no-repeat $DAlign 8px center;background-size:24px'>$ControlMenuText</div>
				";	

				
			}
		

		
			if ($ControlText!="")
			{
				if ($ControlTarget=="")
				{
				echo "
				<div divid='Find' name=Collapse"."$CollapseControlMenu id='C{$ControlID}' find='$ControlFind' class='Menu {$Dir}Menu' onclick='Load(\"$ControlUrl\",\"$ControlID\")'>$ControlText</div>
				";
				}
				else
				{
				echo "
				<div divid='Find' name=Collapse"."$CollapseControlMenu id='C{$ControlID}' find='$ControlFind' class='Menu {$Dir}Menu' onclick=\"window.open('$ControlUrl')\">$ControlText</div>
				";
				}
			}
			
			
			$LastControlMenu=$ControlMenuText;
	}
	
echo "
</div>
";

?>