<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

$Command=$_REQUEST['Command'];
$Path=$_REQUEST['Path'];

include("../../include/function/function.php");
include("../../../include/config/config.php");



if (!StartsWith($Path,"/home/{$_SESSION['SessionUsername']}/"))
{
echo "Invalid Path $Path";
exit;
}



$Success="0";

if (StartsWith(getcwd(),"/awspanel"))
{
	// Domain Login
	$Sql = "select * from Site where Domain='{$_SESSION['SessionUsername']}' and Password='$_SESSION[SessionPassword]'";
	$Result = $PDO->query($Sql)->fetchAll();
	foreach ($Result as $Row)
	{
	$Success="1";
	}
}
else
{
echo "Invalid Blackhost Path";
exit;
}

if ($Success!=1)
{
	echo "Invalid username or password.";
	exit;
}

$Command=$_REQUEST['Command'];

if ($Command=="Delete")
{
$Error=SSH ("rm -rf $Path",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

echo md5($Path);
}

if ($Command=="Paste")
{

	$PathArray=explode("|",$Path);
	$CopyFrom=$PathArray[0];

	$Type=filetype($CopyFrom);

	if ($Type=="file")
	{
	
		if ($PathArray[0]==$PathArray[1])
		{

			$DirArray=explode("/",$CopyFrom);
			$FileName=end($DirArray);
			$FileLen=strlen($FileName)+1;
			$DirPath=substr($CopyFrom,0,-$FileLen);

			$FileArray=explode(".",$FileName);

			if ($FileArray[2]=="")
			{
			$CopyTo="$DirPath/{$FileArray[0]}_copy.{$FileArray[1]}";
			}
			else
			{
			$CopyTo="$DirPath/{$FileArray[0]}_copy.{$FileArray[1]}.{$FileArray[2]}";
			}
			
			if (file_exists($CopyTo))
			{
			$CopyTo="";
			
				for ($i=2;$i<=25;$i++)
				{
					$CopyTo=$CopyTo="$DirPath/{$FileArray[0]}_copy_$i.{$FileArray[1]}";
					if (!file_exists($CopyTo))
					{
					break;
					}
				}
			
			}

			if ($CopyTo!="")
			{

				if (!StartsWith($CopyFrom,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyFrom";
				exit;
				}		
				
				if (!StartsWith($CopyTo,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyTo";
				exit;
				}	
			
				$Error=SSH ("cp $CopyFrom $CopyTo",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

			}
			
		}
		else
		{
			if (filetype($PathArray[1])=="dir")
			{
			$DirArray=explode("/",$PathArray[0]);
			$FileName=end($DirArray);
			
			$DirPath=$PathArray[1];
			
			$FileArray=explode(".",$FileName);
			}
			else
			{
			$DirArray=explode("/",$PathArray[0]);
			$FileName=end($DirArray);
			
			$DirArray=explode("/",$PathArray[1]);
			$SkipFileName=end($DirArray);
			$FileLen=strlen($SkipFileName)+1;
			$DirPath=substr($PathArray[1],0,-$FileLen);
			
			$FileArray=explode(".",$FileName);
			}
			
			$CopyTo="$DirPath/$FileName";
			if (file_exists($CopyTo))
			{
			$CopyTo="";
			
				for ($i=2;$i<=25;$i++)
				{
					$CopyTo=$CopyTo="$DirPath/{$FileArray[0]}_copy_$i.{$FileArray[1]}";
					if (!file_exists($CopyTo))
					{
					break;
					}
				}
			
			}

			if ($CopyTo!="")
			{
			
				if (!StartsWith($CopyFrom,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyFrom";
				exit;
				}		
				
				if (!StartsWith($CopyTo,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyTo";
				exit;
				}
			
				$Error=SSH ("cp $CopyFrom $CopyTo",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
				
				echo "cp $CopyFrom $CopyTo";
			}
		
		}
	
	}
	else
	{
	// Copy Dir
	
		if ($PathArray[0]==$PathArray[1])
		{
			$CopyTo=$PathArray[1]."_copy";
			if (file_exists($CopyTo))
			{
			$CopyTo="";
			
				for ($i=2;$i<=25;$i++)
				{
					$CopyTo=$PathArray[1]."_copy_{$i}";
					if (!file_exists($CopyTo))
					{
					break;
					}
				}
			
			}

			if ($CopyTo!="")
			{
			
				if (!StartsWith($CopyFrom,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyFrom";
				exit;
				}
				
				if (!StartsWith($CopyTo,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyTo";
				exit;
				}
			
				$Error=SSH ("cp -r $CopyFrom $CopyTo",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
			}
			
		}
		else
		{
			$DirArray=explode("/",$CopyFrom);
			$DirName=end($DirArray);
			
			$CopyTo=$PathArray[1]."/$DirName";
			if (file_exists($CopyTo))
			{
			$CopyTo="";
			
				for ($i=2;$i<=25;$i++)
				{
					$CopyTo=$PathArray[1]."/{$DirName}_copy_{$i}";
					if (!file_exists($CopyTo))
					{
					break;
					}
				}
			
			}

			if ($CopyTo!="")
			{
				if (!StartsWith($CopyFrom,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyFrom";
				exit;
				}
				
				if (!StartsWith($CopyTo,"/home/{$_SESSION['SessionUsername']}/"))
				{
				echo "Invalid Path $CopyTo";
				exit;
				}
				
				$Error=SSH ("cp -r $CopyFrom $CopyTo",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
			}
		
		}
	
	
	}



}

?>