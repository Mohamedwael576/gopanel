<?php
include("verify.php");


$Path=ValidateDirectory($_REQUEST['Path']);
	
if (!StartsWith($Path,"/home/{$_SESSION['SessionDomain']}"))
{
exit;
}



$Permissions = @substr(sprintf("%o", fileperms($Path)), -3);


$Error=SSH ("chmod 777 $Path",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);


		if ($_SERVER['REQUEST_METHOD']=="POST")
		{
	
			// 10 KB
			$FileSizeMax=100000000000000000;



				for ($x=0 ;$x<=24 ; $x++)
				{				
				
					iF ($_FILES['FileName'][name][$x]!="none" and $_FILES['FileName'][name][$x]!="")
					{

					
						$File=$_FILES[FileName][name][$x];

						copy($_FILES[FileName][tmp_name][$x],"$Path/$File");
							
						echo "$Path/$File";

					
					}
				}
				
				
$Error=SSH ("chmod $Permissions $Path",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

echo "<script>window.top.location.reload();</script>";
				
		}	



?>