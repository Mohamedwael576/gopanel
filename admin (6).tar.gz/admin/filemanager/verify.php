<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_COMPILE_ERROR|E_RECOVERABLE_ERROR|E_ERROR|E_CORE_ERROR);

include("/awspanel/admin/include/function/function.php");
include("/awspanel/include/config/config.php");
if ($DBHost=="")
{
	echo "Can not access database.";
	exit;
}
else
{


}

try {$PDOSite=new PDO("sqlite:/awspanel/database/site.db");$PDOSite->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);} catch (Exception $E) {echo $E->getMessage();exit;}

if (! $_SESSION['SessionType']=="Website")
{
echo "Please Login as User";

exit;
}

if (!is_dir("/home/{$_SESSION['SessionDomain']}"))
{
echo "Directory \"{$_SESSION['SessionDomain']}\" not exists.";
exit;
}

$Success="0";

if (StartsWith(getcwd(),"/awspanel"))
{
	// Domain Login
	$Sql = "select * from Site where Username='{$_SESSION['SessionUsername']}' and Password='{$_SESSION['SessionPassword']}'";
	$Result = $PDOSite->query($Sql)->fetchAll();
	foreach ($Result as $Row)
	{
	$Success="1";
	}
}
else
{
echo "Invalid awsPanel Path";
exit;
}

if ($Success!=1)
{
	echo "Invalid username or password.";
	exit;
}


$Path=$_REQUEST['Path'];

if ($Path!="")
{
	if (!StartsWith($Path,"/home/{$_SESSION['SessionDomain']}/"))
	{
	echo "Invalid Path $Path";
	exit;
	}
}

?>