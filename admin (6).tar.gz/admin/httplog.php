<?php



include "navigator.php";
$Buttons="";
include "title.php";

$HttplogID=$_REQUEST['HttplogID'];


if ($Action=="Block")
{
	$IP=$_REQUEST['IP'];
	$Domain=ValidateDomain($_REQUEST['Domain']);
	$Domain=strtolower($Domain);

	if ($Domain=="")
	{
	$Domain="-";
	}

	$Error=SSH ("/go/blocker $IP $Domain add",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	if (stristr($Error,"success"))
	{
	echo Error("Users from the IP address(es) $IP will not be able to access your site.");
	}
	else
	{
	echo Error($Error);
	}
	
}

	
	$Error=SSH ("screen -d -m bash -c '/go/httplog'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	if (stristr($Error,"Invalid Apache HTTP LogFormat"))
	{
	echo Error($Error);
	exit;
	}
	
		include "search.php";
	
		Echo "

		<div class=DivXTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

		<THEAD>
		
		<tr>
		
		<th  width='2%' height=40>

		</th>
	
		<th align='$DAlign' nowrap>
		{$LNG['Domain']}
		</th>
		
		<th align='$DAlign' nowrap>
		{$LNG['Date']}
		</th>
		
		
		<th align='$DAlign' nowrap>
		{$LNG['IP']}
		</th>
		
		<th align='$DAlign' nowrap>
		{$LNG['BlockIP']}
		</th>

		<th align='$DAlign' nowrap>
		{$LNG['Country']}
		</th>


		<th align='$DAlign' nowrap>
		{$LNG['Descr']}
		</th>
		
		<th align='$DAlign' nowrap>
		{$LNG['Organization']}	
		</th>

		<th align='$DAlign' nowrap>
		{$LNG['Method']}
		</th>
		
		<th align='$DAlign' nowrap>
		{$LNG['Request']}
		</th>
		

		<th align='$DAlign' nowrap>
		{$LNG['Referer']}
		</th>

		<th align='$DAlign' nowrap>
		{$LNG['ResponseSize']}
		</th>
		
		<th align='$DAlign' nowrap>
		{$LNG['UserAgent']}
		</th>
		
		<th align='$DAlign' nowrap>
		{$LNG['Browser']}
		</th>
		
		</tr>

		</THEAD>
		
		";


		$Table="Httplog";$Field="HttplogID>=1";
		$DefaultSortBy="TimeStamp";
		$DefaultDirection=="DESC";
		include "include/sql.php";
		
		$X=0;
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{

			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$SerialNo=(($Page-1)*$PageNo)+($X+1);
			
			echo "
			
			<tr name=R$X id=R$X divid=Find find='{$Row['Domain']}-{$Row['Country']}-{$Row['Descr']}-{$Row['IP']}-{$Row['Organization']}-{$Row['Request']}-{$Row['Referer']}-{$Row['UserAgent']}-{$Row['Browser']}' class='$TDColor'>

			<TD align='middle' width='2%' height=40>
			$SerialNo
			</span>
			</TD>
			";

			$ResponseSize=FormatSize($Row['ResponseSize']);
			
			$Date=date("D j M Y g:i a", $Row['TimeStamp']);

			$Flag="";
			if (strlen($Row['Country'])==2)
			{
			$Flag="<img src='image/flag/24x24/".strtolower($Row['Country']).".png' title='{$Row['Country']}' style='vertical-align:middle;padding:5px'>";
			}
			
			$BlockIP="<a href=\"javascript:Load('$CurrentFileName?Action=Block&Domain={$Row['Domain']}&IP={$Row['IP']}')\" class=Action>Block</a>";

			echo "
			<TD>{$Row['Domain']}</TD>
			<TD nowrap>$Date</TD>
			<TD><a href=\"javascript:Load('whois.php?Domain={$Row['IP']}')\">{$Row['IP']}</a></TD>
			<TD>{$BlockIP}</TD>
			<TD align='right'>{$Flag}{$Row['Country']}</TD>
			<TD>{$Row['Descr']}</TD>
			<TD>{$Row['Organization']}</TD>
			<TD nowrap>{$Row['Method']}</TD>
			<TD nowrap>{$Row['Request']}</TD>
			<TD nowrap>{$Row['Referer']}</TD>
			<TD nowrap>$ResponseSize</TD>
			<TD>{$Row['UserAgent']}</TD>
			<TD>{$Row['Browser']}</TD>
			";
			
		$X++;
		}
		
		if ($X!=0)
		{
		echo "</TBODY>";
		}
		
		echo "
	
		<TFOOT>

		<tr>

		<th align='$DAlign' colspan=4>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=10>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>
	
	
		</TABLE>
		";
		
	
		
		
?>