<?php
// انشاء تمبلت فارغة للتمبلت من النوع Txt - لجميع الثيمات
	
	// Header
	$HeaderDisplayOption="";
	$OptionPath=strtolower("../module/$LService/theme/$ThemeFolder/html/option/header.php");
	$X=@include($OptionPath);
	
	$TemplateFound=0;
	$TKey="Header";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Header','$HeaderDisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}
	
	// Footer
	$FooterDisplayOption="";
	$OptionPath=strtolower("../module/$LService/theme/$ThemeFolder/html/option/footer.php");
	$X=@include($OptionPath);
	
	$TemplateFound=0;
	$TKey="Footer";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Footer','$FooterDisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	// Left
	$LeftDisplayOption="";
	$OptionPath=strtolower("../module/$LService/theme/$ThemeFolder/html/option/left.php");
	$X=@include($OptionPath);
	
	$TemplateFound=0;
	$TKey="Left";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Left','$LeftDisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	// Right
	$RightDisplayOption="";
	$OptionPath=strtolower("../module/$LService/theme/$ThemeFolder/html/option/right.php");
	$X=@include($OptionPath);
	
	$TemplateFound=0;
	$TKey="Right";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Right','$RightDisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}
	
	// Up
	$UpDisplayOption="";
	$OptionPath=strtolower("../module/$LService/theme/$ThemeFolder/html/option/up.php");
	$X=@include($OptionPath);
	
	$TemplateFound=0;
	$TKey="Up";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Up','$UpDisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}
	
	// Down
	$DownDisplayOption="";
	$OptionPath=strtolower("../module/$LService/theme/$ThemeFolder/html/option/down.php");
	$X=@include($OptionPath);
	
	$TemplateFound=0;
	$TKey="Down";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Down','$DownDisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}




	// Introduction
	$IntroductionDisplayOption="";
	$OptionPath=strtolower("../module/$LService/theme/$ThemeFolder/html/option/introduction.php");
	$X=@include($OptionPath);
	
	$TemplateFound=0;
	$TKey="Introduction";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Introduction','$IntroductionDisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}


	// Home
	$TemplateFound=0;
	$TKey="Home";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Home','$DisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	// Category
	$TemplateFound=0;
	$TKey="Category";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Category','$DisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	// List
	$TemplateFound=0;
	$TKey="List";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('List','$DisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	// Show
	$TemplateFound=0;
	$TKey="Show";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Show','$DisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	// Dedicate
	$TemplateFound=0;
	$TKey="Dedicate";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Dedicate','$DisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}
	
	// Find
	$TemplateFound=0;
	$TKey="Find";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Find','$DisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	// Letter
	$TemplateFound=0;
	$TKey="Letter";
	$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$TemplateFound=1;
	}
	
	if ($TemplateFound==0)
	{
	$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,Theme) VALUES ('Letter','$DisplayOption','$ThemeFolder')";
	$Result = SQL($Sql);
	}

	










	
?>
