<?php
function Xmlmap ($SiteName,$TableName)
{

	
			$ResultField = $PDO->query("select * from $TableName");
			$FieldsNo = mysql_num_fields($ResultField);
			
			echo "<ol>";
			
			$FieldNameString="";			
			for ($XField=0;$XField<$FieldsNo;$XField++)
			{
				$FieldName=mysql_field_name($ResultField, $XField);
				$FieldType=mysql_field_type($ResultField, $XField);
			
				$F=0;
				$Sql = "select * from Xmlmap where SiteName='$SiteName' and FieldName='$FieldName'";
				$Result = SQL($Sql);
				foreach ($Result as $Row)
				{ 
				$F=1;
				}
				
				if ($F==0)
				{
				$Sql = "INSERT INTO Xmlmap (SiteName,FieldName,Element) VALUES ('$SiteName','$FieldName','$Element')";
				$Result = SQL($Sql);

				echo "<li>Field $FieldName Mapping Successfully.<br />";
				}
				else
				{
				echo "<li><span style='color:#FF0000'>Field $FieldName Exists.</span><br />";
				}
				
				
			}
			
			echo "</ol>";

}

?>