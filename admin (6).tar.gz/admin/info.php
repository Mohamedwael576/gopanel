<?php

	if ($_SESSION['SessionUsername']=="root")
	{
		$PHPVersion=phpversion();
	}
	else
	{
		$Result=SQL("select * from Site where Domain='{$_SESSION['SessionDomain']}'");
		foreach ($Result as $Row)
		{	
			$ExpiresOn = date("D j M Y", strtotime($Row['ExpiresOn']));
			$DomainExpiresOn = date("D j M Y", strtotime($Row['DomainExpiresOn']));

			$AddonNo=$Row['AddonNo'];
			$SubDomainNo=$Row['SubDomainNo'];
			$AliasNo=$Row['AliasNo'];
			$EmailNo=$Row['EmailNo'];
			$FTPNo=$Row['FTPNo'];
			$DatabaseNo=$Row['DatabaseNo'];
			$PHPVersion=$Row['PHPVersion'];

			$SpaceUsed=FormatSize($Row['SpaceUsed']);
			$MailSpaceUsed=FormatSize($Row['MailSpaceUsed']);
			
			if ($Row['DiskSpace']==0) 
			{
			$DiskSpace="Unlimited";
			
			$DiskSpacePercent=1;
			}
			else
			{
			$DiskSpace=FormatSize($Row['DiskSpace']);
			
			$DiskSpacePercent=floor($Row['SpaceUsed']*100/$Row['DiskSpace']); 
			}
			
				
			$BandwidthUsed=FormatSize($Row['BandwidthUsed']);
			
			if ($Row['Bandwidth']==0) 
			{
			$Bandwidth="Unlimited";
			
			$BandwidthPercent=1;
			}
			else
			{
			$Bandwidth=FormatSize($Row['Bandwidth']);
			
			$BandwidthPercent=floor($Row['BandwidthUsed']*100/$Row['Bandwidth']); ;
			}
		}
	}
		
	$Emails=RowCount("select * from Mail where Domain='{$_SESSION['SessionDomain']}'");
	$Emails=intval($Emails);
	$Addons=RowCount("select * from Addon where Domain='{$_SESSION['SessionDomain']}'");
	$Addons=intval($Addons);
	$SubDomaons=RowCount("select * from Subdomain where Domain='{$_SESSION['SessionDomain']}'");
	$SubDomaons=intval($SubDomaons);
	$Aliases=RowCount("select * from Alias where Domain='{$_SESSION['SessionDomain']}'");
	$Aliases=intval($Aliases);
	$FTPs=RowCount("select * from Ftp where Domain='{$_SESSION['SessionDomain']}'");
	$FTPs=intval($FTPs);
	$Databases=RowCount("select * from Mysql where Domain='{$_SESSION['SessionDomain']}'");
	$Databases=intval($Databases);

	$Sql = "select sum(Size) as MySQLSize from Mysql where Domain='{$_SESSION['SessionDomain']}'";
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {	
		$MySQLSize=FormatSize($Row['MySQLSize']);
	}

	$ServerInfo=SSH ("/go/serverinfo",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$ServerInfoArray=explode("|",$ServerInfo);
	$ServerDiskSpace=$ServerInfoArray[0];
	$ServerDiskUsed=$ServerInfoArray[1];
	$ServerDiskPercent=$ServerInfoArray[2];
	$Memory=$ServerInfoArray[3];
	$MemoryUsed=$ServerInfoArray[4];
	$MemoryPercent=$ServerInfoArray[5];
	$Cores=$ServerInfoArray[6];
	$CoresUsed=$ServerInfoArray[7];
	$CoresPercent=$ServerInfoArray[8];
	$ServerIP=$ServerInfoArray[9];
	$Hostname=$ServerInfoArray[10];
	$OS=trim($ServerInfoArray[11]);
	$OSVersion=trim($ServerInfoArray[12]);
	$WS=trim($ServerInfoArray[13]);
	$WSVersion=trim($ServerInfoArray[14]);
	$Machine=trim($ServerInfoArray[15]);
	$MariaDBVersion=$ServerInfoArray[16];
	$Architecture=$ServerInfoArray[17];
	$KernelVersion=trim($ServerInfoArray[18]);
	$Processor=trim($ServerInfoArray[19]);
	$StorageType=trim($ServerInfoArray[20]);
	
	if (strlen($Hostname)>30)
	{
	$Hostname=substr($Hostname,0,27)."...";
	}
		
	$Architecture=SSH ("uname -m",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$KernelVersion=SSH ("uname -r",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

echo "
<div class='DivView DivScroll'>

	<div class='ViewTitle'>
	<a href='index.php?View=Mobile'><img src='theme/{$_SESSION['SessionTheme']}/svg/x.svg' style='width:24px;height:24px;float:right'></a>
	General Information
	</div>
	
	<div class=ViewA>
	<span class='ViewB'>{$_SESSION['SessionUsername']}</span>
	Current User
	</div>
	
	";
	
	if ($_SESSION['SessionType']=="Website" and $_SESSION['SessionUsername']!="root")
	{

		echo "
		<div class=ViewA>
		<span class='ViewB'>{$_SESSION['SessionDomain']}</span>
		Primary Domain
		</div>

		<div class=ViewA>
		<span class='ViewB'>/home/{$_SESSION['SessionDomain']}</span>
		Home Directory
		</div>
		

		<div class=ViewA>
		<span class='ViewB'>$ExpiresOn</span>
		Hosting Expires On
		</div>

		";
		
		if (!stristr($DomainExpiresOn,"1970"))
		{
		echo "
		<div class=ViewA>
		<span class='ViewB'>$DomainExpiresOn</span>
		Domain Expires On
		</div>
		";
		}
		
		
		echo "
		<div class=ViewA>
		<span class='ViewB'>$ServerIP</span>
		Shared IP Address
		</div>
		";

		if ($StorageType!="")
		{
		echo "
		<div class=ViewA>
		<span class='ViewB'>$StorageType</span>
		Storage Type
		</div>
		";
		}

		echo "
		<div class=ViewA>
		<span class='ViewB'>$SpaceUsed / $DiskSpace</span>
		Disk Usage
		</div>

		<div class=ViewA>
		<span class='ViewB'>$BandwidthUsed / $Bandwidth</span>
		Bandwidth
		</div>

		<div class=ViewA>
		<span class='ViewB'>$MailSpaceUsed</span>
		Email Disk Usage
		</div>	


		<div class=ViewA>
		<span class='ViewB'>$MySQLSize</span>
		Database Disk Usage
		</div>	

		<div class=ViewA>
		<span class='ViewB'>$Addons / $AddonNo</span>
		Addon Domains
		</div>
		
		<div class=ViewA>
		<span class='ViewB'>$SubDomaons / $SubDomainNo</span>
		Subdomains
		</div>

		<div class=ViewA>
		<span class='ViewB'>$Aliases / $AliasNo</span>
		Alias Domains
		</div>
		
		<div class=ViewA>
		<span class='ViewB'>$FTPs / $FTPNo</span>
		FTP Accounts
		</div>

		<div class=ViewA>
		<span class='ViewB'>$Emails / $EmailNo</span>
		Email Accounts
		</div>
		
		<div class=ViewA>
		<span class='ViewB'>$Databases / $DatabaseNo</span>
		MariaDB Databases
		</div>
		";
	}
	
	echo "
	
		<div class=ViewA>
		<span class='ViewB'>$PHPVersion</span>
		PHP Version
		</div>	
	
	<div class='ViewTitle'>Server Information</div>

	";
	
	

	

	if ($Machine!="")
	{
	echo "
	<div class=ViewA>
	<span class='ViewB'>$Machine</span>
	Virtualization
	</div>
	";
	}
	
	
	if ($Hostname!="")
	{
	echo "
	<div class=ViewA title='$HostnameTitle'>
	<span class='ViewB'>$Hostname</span>
	Hostname
	</div>	
	";
	}
	
	echo "
	<div class=ViewA>
	<span class='ViewB'>$WS</span>
	Web Server
	</div>	

	";
	
	if ($WS=="Apache")
	{
	echo "
	<div class=ViewA>
	<span class='ViewB'>$WSVersion</span>
	Apache Version
	</div>
	";
	}

	if ($WS=="NGINX")
	{
		if ($WSVersion!="")
		{
		echo "
		<div class=ViewA>
		<span class='ViewB'>$WSVersion</span>
		NGINX Version
		</div>
		";
		}
	}
	
	echo "
	<div class=ViewA>
	<span class='ViewB'>$MariaDBVersion</span>
	MariaDB Version
	</div>	
	
	<div class=ViewA>
	<span class='ViewB'>$OS $OSVersion</span>
	Operating System
	</div>	
	";

	if ($_SESSION['SessionUsername']=="root")
	{
	echo "
	<div class=ViewA>
	<span class='ViewB'>{$ServerDiskUsed} / {$ServerDiskSpace}</span>
	Disk Usage
	</div>	
	";
	}

	echo "
	<div class=ViewA>
	<span class='ViewB'>$CoresUsed</span>
	Server Load
	</div>


	<div class=ViewA>
	<span class='ViewB'>$Cores</span>
	CPU Count
	</div>

	<div class=ViewA>
	<span class='ViewB'>{$MemoryPercent}%</span>
	Memory Used
	</div>
	";

	if ($Processor!="")
	{
	echo "
	<div class=ViewA>
	<span class='ViewB'>$Processor</span>
	Processor
	</div>	
	";
	}

	echo "
	<div class=ViewA>
	<span class='ViewB'>$Architecture</span>
	Architecture
	</div>	
	
	<div class=ViewA>
	<span class='ViewB'>$KernelVersion</span>
	Kernel Version
	</div>	

	
</div>	
";
	

?>