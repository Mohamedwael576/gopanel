<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_COMPILE_ERROR|E_RECOVERABLE_ERROR|E_ERROR|E_CORE_ERROR);

$ApiID=intval($_REQUEST['ApiID']);

include("../include/config/config.php");



$ApiID=intval($_REQUEST['ApiID']);
$ApiKey=$_REQUEST['ApiKey'];

$Start=intval($_REQUEST['Start']);
$Limit=intval($_REQUEST['Limit']);
$DESC=intval($_REQUEST['DESC']);
$OrderBy=$_REQUEST['OrderBy'];

$ApiKey=preg_replace("/[^A-Za-z0-9\_]/","", $ApiKey);
$OrderBy=preg_replace("/[^A-Za-z0-9\_]/","", $OrderBy);

$ApiExists=0;
$Sql = "select * from Api where ApiID='$ApiID' and ApiKey='$ApiKey'";
$Result = SQL($Sql);
foreach ($Result as $Row)
{
$ApiExists=1;

	$Name=$Row['Name'];
	$TableName=$Row['TableName'];
	$Columns=$Row['Columns'];
	$ApiKey=$Row['ApiKey'];
	$Domain=$Row['Domain'];

}

if ($ApiExists==0)
{
echo "Invalid API Key";
exit;
}

IF ($Name=="gopanel")
{
exit;
}

$Owner=0;
$Sql = "select * from Mysql where Name='$Name' and Domain='$Domain'";
$Result = SQL($Sql);
foreach ($Result as $Row)
{
$Owner=1;
}

if ($Owner==0)
{
echo "Invalid Database Owner.";
exit;
}

if ($Columns=="" or $Columns=="all")
{
$Columns="*";
}


if ($OrderBy!="")
{
	if ($DESC==1)
	{
	$OrderBySQL="order by $OrderBy DESC";
	}
	else
	{
	$OrderBySQL="order by $OrderBy";
	}
}


if ($Start==0 and $Limit>=1)
{
$Sql = "select $Columns from $Name.$TableName $OrderBySQL limit $Limit";
}
elseif ($Start>=1 and $Limit>=1)
{
$Sql = "select $Columns from $Name.$TableName $OrderBySQL limit $Start,$Limit";
}
else
{
$Sql = "select $Columns from $Name.$TableName $OrderBySQL";
}

$Result = SQL($Sql);
foreach ($Result as $Row)
{

        $Array[] = $Row;


}

echo json_encode($Array);


?>