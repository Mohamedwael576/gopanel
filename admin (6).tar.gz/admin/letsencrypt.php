<?php




include "navigator.php";

if ($_SESSION['SessionSSHUsername']=="root")
{
	if ($_REQUEST['Action']!="SSLAll")
	{
	$Buttons="<a href=\"javascript:Load('$CurrentFileName?Action=SSLAll&ControlID=$ControlID&Page=$Page','$ControlID')\" class='ButtonB {$Dir}ButtonB'>{$LNG['InstallSSLCertificateForAllDomains']}</a>";
	}
}

include "title.php";


if ($_REQUEST['Action']=="SSLAll")
{
	if ($_SESSION['SessionSSHUsername']=="root")
	{

	$Error=SSH ("screen -d -m bash -c '/go/ssl all'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	echo Error("Working on it...");

	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

	exit;
	}
}


if ($_REQUEST['Domain']!="")
{

	$Domain=ValidateDomain($_REQUEST['Domain']);
	$Type=$_REQUEST['Type'];


	include "access.php";

	$Error=SSH ("/go/ssl $Domain $Type",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);

	exit;
}


    
	
	Echo "
	<form name=Form method=POST onsubmit='return FreeSSL(this);' autocomplete='off' action='$CurrentFileName'>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}<br>
	";
	
	$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
	foreach ($Result as $Row)
	{
	$Domains[]=$Row['Domain'];
	}
	
	$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
	foreach ($Result as $Row)
	{
	$Domains[]=$Row['AddonDomain'];
	}
	
	if (is_array($Domains))
	{
		sort($Domains);
	}
	else
	{
		$Domains[]="";
	}
	
	echo "
	<select name='Domain' id='Domain' class=Select>
	";
	
	foreach ($Domains as &$Domain) 
	{
		if ($Domain==$_REQUEST['Domain'])
		{
		echo "<option value='$Domain' selected>$Domain</option>";
		}
		else
		{
		echo "<option value='$Domain'>$Domain</option>";
		}
	}

	echo "
	</select>
	
	</div>
	
	<div class='DivInput {$Dir}DivInput'>
	{$LNG['Type']}
	<br>
 
	<input type='radio' name=Type id=Type value='--letsencrypt' checked> Let's Encrypt <br />
	<input type='radio' name=Type id=Type value='--buypass'> BuyPass Go <br />
	</div>

	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['Install']}' Class=InputButton>
	</div>

	
</form>

";	

?>