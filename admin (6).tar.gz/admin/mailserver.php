<?php
include "nav.php";
$Buttons="";
include "title.php";




if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	Echo "
	Sorry, You Are Not Allowed to Access This Page
	";

exit;
}

if ($_REQUEST['Action']=="RestartMAIL")
{

	
	$Error=SSH ("/go/webmail restart",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	if ($Error=="")
	{
	echo Error("POSTFIX & DOVECOT Restarted Successfully.");
	}
	else
	{
	echo Error("$Error");
	}
	
	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

	
	exit;
	
}


	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;
	
	
	

?>
