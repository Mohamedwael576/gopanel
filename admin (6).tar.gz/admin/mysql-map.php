<?php

include "navigator.php";
$Buttons="
<a href=\"phpmyadmin.php\" target='_blank' class='ButtonB {$Dir}ButtonB'>phpMyAdmin</a>
";
include "title.php";

$mysqli=@new mysqli($DBHost,$DBUser,$DBPass,"mysql");
$mysqli->set_charset("utf8");mysqli_report(MYSQLI_REPORT_OFF);

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	Echo "
	Sorry, You Are Not Allowed to Access This Page
	";

exit;
}

if ($_REQUEST['Username']!="root")
{
$Username=ValidateUsername($_REQUEST['Username']);
}
$DatabaseName=ValidateDatabaseName($_REQUEST['DatabaseName']);
$PHPMyAdmin=intval($_REQUEST['PHPMyAdmin']);
$ChangeOwner=intval($_REQUEST['ChangeOwner']);
$Domain=ValidateDomain($_REQUEST['Domain']);

if ($PHPMyAdmin==1)
{

	
	$Result = SQL("select * from Mysql where MysqlID='$MysqlID'");
	foreach ($Result as $Row)
	{
	setcookie ("CookiesMySQLUsername",$Row[User],time() + (86400 * 30), "/");
	setcookie ("CookiesMySQLPassword",$Row[Pass],time() + (86400 * 30), "/");

	header("Location: /phpmyadmin");
	}

exit;
}


If ($Action=="ListOwner")
{
	echo "
	<div class='DivInput {$Dir}DivInput'>
	
		<div style='margin-bottom:10px'>Select a New Owner ($DatabaseName):</div>
		";


		$Result = SQL("select * from Site where SiteID>=1");
		foreach ($Result as $Row)
		{

			if ($Username==$Row['Username'])
			{
			echo "
			<label class=Label> {$Row['Username']}
				<input type='radio' checked>
				<span class='Radio'></span>
			</label>
			";
			}
			else
			{
			echo "
			<label class=Label onclick='Load(\"$CurrentFileName?ChangeOwner=1&Domain={$Row['Domain']}&Username={$Row['Username']}&DatabaseName=$DatabaseName&Page=$Page\")'> {$Row['Domain']}
				<input type='radio'>
				<span class='Radio'></span>
			</label>
			";			
			}
		
		}

		echo "

	</div>

	";
	
}
	
if ($ChangeOwner==1)
{
	$Exists=0;
	$Result = SQL("select MysqlID from Mysql where Name='$DatabaseName'");
	foreach ($Result as $Row)
	{
	$Exists=1;
	}

	if ($Exists==0)
	{
	$TimeStamp=time();
	$Sql = "INSERT INTO Mysql (Name,User,Pass,Username,TimeStamp) VALUES ('$DatabaseName','$DatabaseName','$Pass','$Username','$TimeStamp')";
	$Result = SQL($Sql);	
	}
	else
	{
	$Sql = "UPDATE Mysql set Domain='$Domain',Username='$Username' where Name='$DatabaseName'";
	$Result = SQL($Sql);
	}
	
	$Error=SSH ("/go/phpmyadmin $Username",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	

}

	
    $RecordsNo=$mysqli->query("SELECT table_schema AS DatabaseName, SUM(data_length + index_length) AS DatabaseSize FROM information_schema.TABLES where table_schema not in ('mysql','information_schema','performance_schema','horde','roundcube','sys') GROUP BY table_schema")->num_rows;

	include "search.php";
	
	Echo "
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing=0 width='100%' class=Table>

	<THEAD>
	
	<tr>
	
	<th width='2%'>

	</th>
	
	<th align='$DAlign' width='38%'>
	<a href=\"javascript:Load('$CurrentFileName?SortBy=DatabaseName')\">{$LNG['DatabaseName']}</a>
	</th>
	
	<th align='$DAlign' width='10%'>
	<a href=\"javascript:Load('$CurrentFileName?SortBy=data_length')\">{$LNG['Size']}</a>
	</th>
	
	<th align='$DAlign' width='20%'>
	{$LNG['Owner']}
	</th>
	
	<th width='30%'>

	</th>

	</tr>
	
	</THEAD>

	";

	if ($SortBy=="")
	{
		$SortBy="DatabaseName";
	}
	
	if ($Direction=="")
	{
		$Direction="ASC";
	}
	
	if ($Page=="")
	{
		$Page=1;
	}

	$FilterSql=str_replace("\'","'",$FilterSql);

	$FromRecord=($Page-1)*$PageNo;

	if ($FilterSql!="")
	{
		$Sql = "SELECT table_schema AS DatabaseName, SUM(data_length + index_length) AS DatabaseSize FROM information_schema.TABLES where table_schema not in ('mysql','information_schema','performance_schema','horde','roundcube','sys') GROUP BY table_schema order by $SortBy $SortDir LIMIT $FromRecord,$PageNo";
		$RowsNo=$mysqli->query("SELECT table_schema AS DatabaseName, SUM(data_length + index_length) AS DatabaseSize FROM information_schema.TABLES where table_schema not in ('mysql','information_schema','performance_schema','horde','roundcube','sys') GROUP BY table_schema")->num_rows;
	}
	elseif ($SearchFor=="")
	{
		$Sql = "SELECT table_schema AS DatabaseName, SUM(data_length + index_length) AS DatabaseSize FROM information_schema.TABLES where table_schema not in ('mysql','information_schema','performance_schema','horde','roundcube','sys') GROUP BY table_schema order by $SortBy $SortDir LIMIT $FromRecord,$PageNo";
		$RowsNo=$mysqli->query("SELECT table_schema AS DatabaseName, SUM(data_length + index_length) AS DatabaseSize FROM information_schema.TABLES where table_schema not in ('mysql','information_schema','performance_schema','horde','roundcube','sys') GROUP BY table_schema")->num_rows;
	}


	$X=0;
	$Result = $mysqli->query($Sql);
	while ($Row = $Result->fetch_assoc())
	{
		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}
		
		$SerialNo=(($Page-1)*$PageNo)+($X+1);
		
		$DatabaseSize=FormatSize($Row['DatabaseSize']);

		$Username="root";
		$SqlQ = "select Username from Mysql where Name='{$Row['DatabaseName']}'";
		$ResultQ = SQL($SqlQ);
		foreach ($ResultQ as $RowQ)
		{
			$Username=$RowQ['Username'];
		}

		echo "
		
		<tr class='$TDColor' divid=Find find='{$Row['DatabaseName']}-$Username'>

		<TD align='middle'>
		$SerialNo
		</TD>

		<TD align='$DAlign'><a  href='$CurrentFileName?MysqlID={$Row['MysqlID']}&PHPMyAdmin=1&ServiceControl=$ServiceControl' target='_blank'>{$Row['DatabaseName']}</a></TD>

		<TD align='$DAlign'>{$DatabaseSize}</TD>
		
		<TD align='$DAlign'>{$Username}</TD>

		<TD align='$OAlign'>
		
		<a href=\"javascript:Load('$CurrentFileName?Action=ListOwner&DatabaseName={$Row['DatabaseName']}&Username=$Username&ControlID=$ControlID&Page=$Page')\" class=Action>{$LNG['ChangeOwner']}</a>

		</TD>
		";
		
	$X++;
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "
	<TFOOT>

	<tr>


	<th align='$DAlign' colspan=3>
	Showing $X of $RowsNo records.
	</th>
	
	<th align='$OAlign' colspan=3>
	";
			
	include "pages.php";

	echo "
	</th>

	</tr>

	</TFOOT>

	</TABLE>
	</div>
	";
	
		
	



?>