<?php
include "nav.php";
$Buttons="";
include "title.php";


if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Blackhost Path";
	exit;
}


$Password=ValidatePassword($_REQUEST['Password']);

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	Echo "
	Sorry, You Are Not Allowed to Access This Page
	";

exit;
}


if ($Password!="")
{

	if ($DemoPassword!="")
	{
	echo Error("This functionality is not available in demo mode.");
	exit;
	}

	$Error=SSH ("/go/mysqlreset $Password",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	
	exit;
	
}

	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;

?>