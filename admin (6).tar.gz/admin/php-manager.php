<?php
include "navigator.php";
$Buttons="";
include "title.php";

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	Echo "
	Sorry, You Are Not Allowed to Access This Page
	";

exit;
}

if (intval($PageNo)==0) {$PageNo=20;}

if ($Action=="Default")
{
	$PHPVersion=ValidateVersion($_REQUEST['PHPVersion'],"Invalid PHP Version.");

	$Lock=SSH ("/go/lock",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Lock=trim($Lock);
	
	if ($Lock=="")
	{

		$Error=SSH ("screen -d -m bash -c '/go/defaultphp $PHPVersion'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("Working on it...");
	
	}
	else
	{
		echo Error("$Lock");
	}
	
	exit;
	
}

if ($Action=="Install")
{
	$PHPVersion=ValidateVersion($_REQUEST['PHPVersion'],"Invalid PHP Version.");


	$Lock=SSH ("/go/lock",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Lock=trim($Lock);
	
	if ($Lock=="")
	{

		$Error=SSH ("screen -d -m bash -c '/go/installphp $PHPVersion'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("Working on it...");
		
	}
	else
	{
		echo Error("$Lock");
	}
	
	exit;
	
	
	exit;
	
}

if ($Action=="Delete")
{
	$PHPVersion=ValidateVersion($_REQUEST['PHPVersion'],"Invalid PHP Version.");
	
	$Lock=SSH ("/go/lock",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Lock=trim($Lock);
	
	
	if ($Lock=="")
	{

		$Error=SSH ("screen -d -m bash -c '/go/removephp $PHPVersion'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("Working on it...");
		
	
	}
	else
	{
		echo Error("$Lock");
	}
	
	exit;
	
}

    
	
	$Installed=SSH ("/go/multiphp Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Installed=str_ireplace("php","",$Installed);
	$Installed=str_ireplace(".","",$Installed);

	
    Echo "
	<input type=hidden name=Action id=Action>
	
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

	<THEAD>
	
	<tr>
	
    <TH align='$DAlign' width='70%'>
    {$LNG['PHPVersion']}
    </TH>
	
    <TH width='20%'>
 
    </TH>

    <TH width='10%'>
 
    </TH>

	</tr>
	
	</THEAD>
	
	";
	

	$SortDir="ASC";

    if ($SortBy=="")
    {
    $SortBy="Domain";
    }

    if ($Page=="")
    {
    $Page=1;
    }


	$ListPHP=SSH ("/go/listphp",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	$CurrentPHPVersion=SSH ("/go/defaultphp",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$CurrentPHPVersion=str_ireplace("php","",$CurrentPHPVersion);

	$PHPArray = array("5.6","7.0","7.1","7.2","7.3","7.4","8.0","8.1","8.2","8.3","8.4","8.5","8.6","8.7","8.8","8.9","9.0","9.1","9.2","9.3","9.4","9.5","9.5","9.6","9.7","9.8","9.9","10.0");

	$X=0;
	foreach ($PHPArray as &$PHPVersion) 
    {
		if (stristr($ListPHP,$PHPVersion))
		{

			$PHPString=str_ireplace(".","",$PHPVersion);


			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
		
			ECHO "
			<tr class='$TDColor' divid=Find find=''>

			<TD>
			PHP $PHPVersion
			</td>
			
			<TD style='padding-top:15px'>
			";
			
			if (stristr($Installed,$PHPString))
			{
		
				if (stristr($CurrentPHPVersion,$PHPVersion))
				{
				echo "
				Default
				";
				}
				else
				{
				echo "
				<a href=\"javascript:Load('$CurrentFileName?Action=Default&PHPVersion=$PHPVersion&ControlID=$ControlID&Page=$Page')\">{$LNG['MakeDefault']}</a>
				";
				}

			}

			
			echo "
			</td>
		
			<TD>
			";
			
			if (stristr($Installed,$PHPString))
			{
				if ($PHPVersion!="8.2")
				{
				echo "<a href=\"javascript:Load('$CurrentFileName?Action=Delete&PHPVersion=$PHPVersion&ControlID=$ControlID&Page=$Page')\" class=ActionB>{$LNG['Remove']}</a>";
				}
			}
			else
			{
			echo "<a href=\"javascript:Load('$CurrentFileName?Action=Install&PHPVersion=$PHPVersion&ControlID=$ControlID&Page=$Page')\" class=Action>{$LNG['Install']}</a>";
			}
			
			echo "
			
			</td>
		
		
			</tr>
			";
		
			$X++;
			
		}
			
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "

	</TABLE>
	</div>
	";



	
?>