<?php
include "nav.php";
$Buttons="";
include "title.php";


if ($_REQUEST['Domain']!="")
{
$Domain=ValidateDomain($_REQUEST['Domain']);

	if (!function_exists("ssh2_connect"))
	{
		echo Error("SSH2 PHP extension is not available.");
		exit;
	}

	$Error=SSH ("ping -c 1 $Domain | gawk -F'[()]' '/PING/{print $2}'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("Ping: $Domain\n\n$Error");


exit;
}

	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;
?>