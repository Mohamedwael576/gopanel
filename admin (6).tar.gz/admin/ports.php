<?php
include "nav.php";

	if ($Action=="Sample")
	{
		$Buttons= "<a href=\"javascript:Load('$CurrentFileName?ControlID=$ControlID','$ControlID')\" class='ButtonB {$Dir}ButtonB'>{$LNG['MoreDetails']}</a>";
	}
	else
	{
		$Buttons= "<a href=\"javascript:Load('$CurrentFileName?ControlID=$ControlID&Action=Sample','$ControlID')\" class='ButtonB {$Dir}ButtonB'>{$LNG['SampleOutput']}</a>";
	}
	
include "title.php";



	if ($Action=="Sample")
	{
	$Error=SSH ("netstat -tulpn",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	else
	{
	$Error=SSH ("lsof -i -P -n | grep COMMAND && lsof -i -P -n | grep LISTEN",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	
	$Error=str_replace("(LISTEN)","",$Error);

	
	if ($DemoPassword!="")
	{
	$Error=str_replace("$SSHPort","22",$Error);
	}

		
	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;
	
	

?>