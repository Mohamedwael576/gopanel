<?php



include "navigator.php";
$Buttons="";
include "title.php";


		$Result = SQL("select * from Config where ConfigID=1");
		foreach ($Result as $Row)
		{
		$ResellerclubIP=$Row['ResellerclubIP'];
		$ResellerclubUserID=$Row['ResellerclubUserID'];
		$ResellerclubAPIKey=$Row['ResellerclubAPIKey'];
		}


		
			
			Echo "
			<form name=Form method=POST autocomplete='off' action='$CurrentFileName'>

			<div class='DivInput {$Dir}DivInput'>Whitelist IP<br>
			
			<input type='text' value='$ResellerclubIP' id='IP' onchange=\"Resellerclub('AccountID',encodeURI(document.getElementById('IP').value),'IP')\" class=InputText>
			
			</div>
		
	
			<div class='DivInput {$Dir}DivInput'>User ID<br>
			<input type='text' value='$ResellerclubUserID' id='UserID' onchange=\"Resellerclub('UserID',encodeURI(document.getElementById('UserID').value),'UserID')\" class=InputText>
			</div>

			<div class='DivInput {$Dir}DivInput'>API Key<br>
			<input type='text' value='$ResellerclubAPIKey' id='APIKey' onchange=\"Resellerclub('APIKey',encodeURI(document.getElementById('APIKey').value),'APIKey')\" class=InputText>
			</div>

			</form>
			


";

// End Scroll 
echo "
</div>
";


?>