<?php
include "nav.php";
$Buttons="";
include "title.php";



$Password=ValidatePassword($_REQUEST['Password']);

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	Echo "
	Sorry, You Are Not Allowed to Access This Page
	";

exit;
}


if ($_REQUEST['Password']!="")
{

	if ($DemoPassword!="")
	{
	echo Error($LNG['ThisFunctionalityNotAvailableDemoMode']);
	exit;
	}

	if ($_SESSION['SessionSSHUsername']=="root" and $_SESSION['SessionUsername']=="root")
	{
		$Error=SSH ("/go/root $Password",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error($Error);

		$_SESSION['SessionPassword']=$Password;
		$_SESSION['SessionSSHPassword']=$Password;
		SQL("UPDATE User SET Username='root',Password='".md5($Password)."' where UserID=1");
	}
	
	exit;
}


	$Content=DesignCode($Content,"ROOT Content");
	echo $Content;


?>
