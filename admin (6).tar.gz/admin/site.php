<?php
include "nav.php";
$Buttons="";



include "title.php";



if ($_SESSION['SessionUserID']>1)
{
	include "include/remain.php";
		
	echo "
	<div class=UnderTitle>
	Total Accounts: $TotalAccounts<br>
	Website Accounts: $WebsiteAccounts<br>
	Sub Reseller Accounts: $SubResellerAccounts<br>
	Remain Accounts : $RemainAccounts / $TotalAccounts
	</div>
	";
	
	if ($RemainAccounts<=0)
	{
	exit;
	}
	
}

	$Edit=$_REQUEST['Edit'];
	$CurrentDomain=trim($_REQUEST['CurrentDomain']);
	$CurrentUsername=trim($_REQUEST['CurrentUsername']);
	$Password=ValidatePassword($_REQUEST['Password']);
	$Email=trim($_REQUEST['Email']);
	$PHPVersion=ValidateVersion($_REQUEST['PHPVersion']);
	$PackageID=intval($_REQUEST['PackageID']);
	$DiskSpace=intval($_REQUEST['DiskSpace']);
	$Bandwidth=intval($_REQUEST['Bandwidth']);
	$FTPNo=intval($_REQUEST['FTPNo']);
	$EmailNo=intval($_REQUEST['EmailNo']);
	$DatabaseNo=intval($_REQUEST['DatabaseNo']);
	$SubDomainNo=intval($_REQUEST['SubDomainNo']);
	$AliasNo=intval($_REQUEST['AliasNo']);
	$AddonNo=intval($_REQUEST['AddonNo']);
	$Skeleton=trim($_REQUEST['Skeleton']); if ($Skeleton=="") {$Skeleton="n";}
	$SSLCertificate=intval($_REQUEST['SSLCertificate']); 
	$SSLRedirect=intval($_REQUEST['SSLRedirect']); 
	$FPM=intval($_REQUEST['FPM']);
	
	$ExpiresOn=substr($_REQUEST['ExpiresOn'],6,4)."-".substr($_REQUEST['ExpiresOn'],3,2)."-".substr($_REQUEST['ExpiresOn'],0,2);
	
	$Domain=ValidateDomain($_REQUEST['Domain']);
	$Username=ValidateUsername($_REQUEST['Username']);

	if (StartsWith($Domain,"www."))
	{
	$Domain = substr($Domain, 4);
	}

if ($Domain!="" and $Email!="")
{
	if ($Edit==1)
	{
	
		if ($DemoPassword!="" and $CurrentDomain=="demo.bbpanel.com")
		{
		echo Error("This functionality is not available in demo mode.");
		exit;
		}
	
		$Error=SSH ("/go/modify $CurrentDomain $Domain $Email $PHPVersion $PackageID $DiskSpace $Bandwidth $FTPNo $EmailNo $DatabaseNo $SubDomainNo $AliasNo $AddonNo $SSLCertificate $SSLRedirect $ExpiresOn",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");	
	}
	else
	{	
		if ($Username=="")
		{
		$Username=$Domain;
		}

		$Error=SSH ("/go/create -d $Domain -u $Username -p $Password -e $Email -v $PHPVersion -i $PackageID -q $DiskSpace -t $Bandwidth -f $FTPNo -m $EmailNo -b $DatabaseNo -o $SubDomainNo -a $AliasNo -n $AddonNo -k $Skeleton -s $SSLCertificate -r $SSLRedirect -g $FPM -x $ExpiresOn -h {$_SESSION['SessionUserID']}",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");

		if (stristr($Error,"correct"))
		{
		
		// Default PHPVersion as Last Website
		SQL("UPDATE Config set PHPVersion='$PHPVersion'");
		
		echo "

		<div class=DivTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

		<THEAD>
	
		<tr>	
		
		<th align='center' width='15%'>Type</th>
		<th align='center' width='15%'>Host</th>
		<th align='center' width='70%'>Value</th>
		
		</tr>
		
		</THEAD>
		
		<tr class=Td>

		<td align='center'>A</td>
		<td align='center'>@</td>
		<td align='center'><input type=text value='{$_SERVER['SERVER_ADDR']}' class=InputZC></td>
		
		</table>
		</div>
		
		<br>
		

		<div class=DivTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

		<THEAD>
	
		<tr>	
		
		<th align='center' width=15%>Type</th>
		<th align='center' width=15%>Host</th>
		<th align='center' width=70%>Value</th>
		
		</tr>
		
		</THEAD>
		
		<tr class=Td>

		<td align='center'>A</td>
		<td align='center'>*</td>
		<td align='center'><input type=text value='{$_SERVER['SERVER_ADDR']}' class=InputZC></td>
		
		</table>
		</div>
		
		
		<br>

		<div class=DivTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>
		<THEAD>
	
		<tr>	
		
		<TH width=15% align='center'>Type</TH>
		<TH width=15% align='center'>Host</TH>
		<TH width=70% align='center'>Value</TH>
		
		</tr>

		</THEAD>
		
		<tr class=Td>

		<td align='center'>CNAME</td>
		<td align='center'>www.$Domain</td>
		<td align='center'><input type=text value='$Domain' class=InputZC></td>
		
		</table>
		</div>
		
		
		

		<br>

		<div class=DivTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>
		<THEAD>
	
		<tr>	
		
		<TH width=15% align='center'>Type</TH>
		<TH width=15% align='center'>Host</TH>
		<TH width=70% align='center'>Value</TH>
		
		</tr>

		</THEAD>
		
		<tr class=Td>

		<td align='center'>CNAME</td>
		<td align='center'>webmail.$Domain</td>
		<td align='center'><input type=text value='$Domain' class=InputZC></td>
		
		</table>
		</div>

		<br>

		<div class=DivTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>
		<THEAD>
	
		<tr>	
		
		<TH width=15% align='center'>Type</TH>
		<TH width=15% align='center'>Host</TH>
		<TH width=70% align='center'>Value</TH>
		
		</tr>

		</THEAD>
		
		<tr class=Td>

		<td align='center'>CNAME</td>
		<td align='center'>gopanel.$Domain</td>
		<td align='center'><input type=text value='$Domain' class=InputZC></td>
		
		</table>
		</div>
		
		
		";
		}

	}

exit;
}

	$Domain="";
	$Username="";
	$PackageID="";
	$DiskSpace="";
	$Bandwidth="";
	$FTPNo=100;
	$EmailNo=100;
	$DatabaseNo=100;
	$SubDomainNo=100;
	$AliasNo=1;
	$AddonNo=0;
	$SSLCertificateChecked="checked";
	$SSLRedirectChecked="checked";
	$FPMChecked="checked";

	if($Edit==1)
	{
	
		$Sql = "select * from Site where Domain='{$_REQUEST['Domain']}'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		$Domain=$Row['Domain'];
		$Username=$Row['Username'];
		$Password=$Row['Password'];
		$Email=$Row['Email'];
		$DefaultPHPVersion=$Row['PHPVersion'];
		
		$PackageID=$Row['PackageID'];
		
		$DiskSpace=$Row['DiskSpace'];
		$Bandwidth=$Row['Bandwidth'];

				
		$FTPNo=$Row['FTPNo'];
		$EmailNo=$Row['EmailNo'];
		$DatabaseNo=$Row['DatabaseNo'];
		$SubDomainNo=$Row['SubDomainNo'];
		$AliasNo=$Row['AliasNo'];
		$AddonNo=$Row['AddonNo'];
		$Shell=$Row['Shell'];
		$Hostname=$Row['Hostname'];
		$Description=$Row['Description'];
		$Skeleton=$Row['Skeleton'];
		
		$ExpiresOn=substr($Row['ExpiresOn'],8,2)."/".substr($Row['ExpiresOn'],5,2)."/".substr($Row['ExpiresOn'],0,4);

			if ($Row['SSLCertificate']==1)
			{
				$SSLCertificateChecked="checked";
			}
			else
			{
				$SSLCertificateChecked="";
			}
			
			if ($Row['SSLRedirect']==1)
			{
				$SSLRedirectChecked="checked";
			}
			else
			{
				$SSLRedirectChecked="";
			}
		
			if ($Row['FPM']==1)
			{
				$FPMChecked="checked";
			}
			else
			{
				$FPMChecked="";
			}
		
		}
		
		
		if ($_SESSION['SessionPassword']=="demo")
		{
		$Password="********";
		}
		
	}
	else
	{
	$ExpiresOn=date('Y-m-d', strtotime('+1 year'));
	$ExpiresOn=substr($ExpiresOn,8,2)."/".substr($ExpiresOn,5,2)."/".substr($ExpiresOn,0,4);
	
	$AdminEmailEvent="onfocusout='AdminEmail()'";
	}

	if ($DiskSpace==0) {$DiskSpace="";}	else {$DiskSpace=intval($DiskSpace)/1048576;}
	if ($Bandwidth==0) {$Bandwidth="";}	else {$Bandwidth=intval($Bandwidth)/1048576;}


		$Output=SSH ("/go/multiphp Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

		if (stristr($Output,"|"))
		{
		$OutputArray=explode("|",$Output);
		}
		else
		{
		$OutputArray[]=$Output;
		}
		
		if ($DefaultPHPVersion=="")
		{

			$Result = SQL("select PHPVersion from Config where ConfigID='1'");
			foreach ($Result as $Row)
			{
			$DefaultPHPVersion=$Row['PHPVersion'];
			}
			
			if ($DefaultPHPVersion=="")
			{
			$DefaultPHPVersion=phpversion();
			}
			
			$DefaultPHPVersion=str_replace("php","",$DefaultPHPVersion);
			$DefaultPHPVersion=str_replace(".","",$DefaultPHPVersion);
			$DefaultPHPVersion=substr($DefaultPHPVersion,0,2);
		
		}
		
		foreach ($OutputArray as &$PHPVersion) 
		{
		
			$PHPVersion=trim($PHPVersion);
			$ShowPHPVersion=str_replace("php","",$PHPVersion);
			$ShowPHPVersion=str_replace(".","",$ShowPHPVersion);
			
			
			if (stristr($ShowPHPVersion,$DefaultPHPVersion))
			{
			$SelectPHPVersion.="
			<label class=Label>PHP ".substr($ShowPHPVersion,0,1).".".substr($ShowPHPVersion,1,1)."
				<input type='radio' name='PHPVersion' value='$PHPVersion' checked='checked'>
				<span class='Radio'></span>
			</label>
			";
			}
			else
			{
			$SelectPHPVersion.="
			<label class=Label>PHP ".substr($ShowPHPVersion,0,1).".".substr($ShowPHPVersion,1,1)."
				<input type='radio' name='PHPVersion' value='$PHPVersion'>
				<span class='Radio RadioRadius'></span>
			</label>
			";
			}
		
		}
	
		$SelectPHPVersion.="
		<label class=Label onclick=\"Load('php-manager.php')\">{$LNG['InstallAnotherVersion']}
			<input type='radio' name='PHPVersion' value='$PHPVersion'>
			<span class='Radio RadioRadius'></span>
		</label>
		";



		$SelectPackage.="<select id='PackageID' name='PackageID' onchange='PackageInfo()' class=Select><option value='0' selected>Default Package</option>";
		$Result = SQL("select * from Package where UserID='{$_SESSION['SessionUserID']}' order by Name");
		foreach ($Result as $Row)
		{
			if ($Row['PackageID']==$PackageID)
			{
			$SelectPackage.="<option value='{$Row['PackageID']}' selected>{$Row['Name']}</option>";
			}
			else
			{
			$SelectPackage.="<option value='{$Row['PackageID']}'>{$Row['Name']}</option>";
			}
		}
		$SelectPackage.="</select>";


	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;

?>