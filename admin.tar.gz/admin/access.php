<?php

$Access=0;

if ($_SESSION['SessionUserID']==1)
{
	$Access=1;
}

if ($_SESSION['SessionType']=="Website")
{

	if ($_SESSION['SessionDomain']!="")
	{

		if ($_SESSION['SessionDomain']==$Domain)
		{
			$Access=1;
		}

	}
	
	if ($_SESSION['SessionUsername']!="")
	{

		if ($_SESSION['SessionUsername']==$Username)
		{
			$Access=1;
		}
		
	}
		
}

if ($_SESSION['SessionType']=="Reseller")
{
	$Sql = "select * from Site where UserID='{$_SESSION['SessionUserID']}' and Username='$Username'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$Access=1;
	}
}

if ($Access==0)
{
	echo Error("Sorry, You are not allowed to access this page");
	exit;
}

?>