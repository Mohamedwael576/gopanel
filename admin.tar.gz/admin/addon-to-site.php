<?php



include "navigator.php";
$Buttons="";
include "title.php";

$AddonID=intval($_REQUEST['AddonID']);
$CheckList=$_REQUEST['CheckList'];

	if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
	{

		if ($_SESSION['SessionResellerUsername']=="")
		{
		echo "
		Sorry, You Are Not Allowed to Access This Page
		";

		exit;
		}
	}


If ($Action=="Convert")
{
	$Domain=ValidateDomain($_REQUEST['Domain']);
	$AddonDomain=$_REQUEST['AddonDomain'];

	include "access.php";
		
	$Error=SSH ("/go/addon $AddonDomain $Domain AnyPassword Convert",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	Echo Error($Error);
	
	exit;
	
}


If ($Action=="BulkConvert")
{
	$CountCheckList=count($CheckList);

	for ($i=0 ;$i<$CountCheckList ; $i++)
	{
	
		$Result = SQL("select * from Addon where AddonID='{$CheckList[$i]}'");
		foreach ($Result as $Row)
		{

			$Domain=$Row['Domain'];
			$AddonDomain=$Row['AddonDomain'];
			
			$Error=SSH ("/go/addon $AddonDomain $Domain AnyPassword BulkConvert",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
			Echo Error($Error);
		}
	}

	$Error=SSH ("/go/httpd",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	Echo Error($Error);

}
    
	echo "
	
	<form name=CheckForm id=CheckForm action='$CurrentFileName'></form>
	<input type=hidden name=Action id=Action>
	

	<div class=DivXTable>
	<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

	<THEAD>
	
	<tr>
	
	
    <TH align=$DAlign width='3%'>
    <input type=checkbox name=AllCheckList id=AllCheckList onclick='CheckAll()'>
    </TH>
	
    <TH align='center' width='2%'>
    </TH>
	
    <TH align=$DAlign width='25%'>
    {$LNG['AddonDomain']}
    </TH>

    <TH align=$DAlign width='25%'>
    {$LNG['Domain']}
    </TH>
	

    <TH align=$DAlign width='25%'>
    {$LNG['CreatedDate']}
    </TH>

    <TH align={$LNG['OAlign']} width='20%'>
 
    </TH>
	
	</tr>
	
	</THEAD>
	";
	
	

	$Table="Addon";$Field="RecycleBin=0";
	$DefaultSortBy="AddonDomain";
	$DefaultDirection=="ASC";
	include "include/sql.php";

	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$AddonID=$Row['AddonID'];
	$Domain=$Row['Domain'];
	$AddonDomain=$Row['AddonDomain'];
		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}

	$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

	echo "
	<tr class='$TDColor' divid=Find find='{$Row['AddonDomain']}-{$Row['Domain']}'>

    <TD><input onclick=\"ColorRow(R$i,$i,'$BGColorLine')\" type=checkbox name=CheckList[] id=CheckList[] value='{$Row['AddonID']}'></TD>
    <TD align='center'>$Information</TD>

    <TD>
    {$Row['AddonDomain']}
    </TD>

	<TD>
    {$Row['Domain']}
    </TD>

	<TD>
    $CreatedDate
    </TD>

	<TD align='$OAlign'>

	<a href=\"javascript:Load('$CurrentFileName?Action=Convert&Domain=$Domain&AddonDomain=$AddonDomain')\" class=Action>{$LNG['ConvertNow']}</a>

    </TD>
    
	</tr>
	";
	
	$X++;
	}

	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "
	
	<TFOOT>

    <tr>

		<th align='$DAlign' colspan=3>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=3>
		";
				
		include "pages.php";

		echo "
		</th>



    </tr>

	</TFOOT>
	
    </TABLE>
    </div>
	</form>
	";

?>