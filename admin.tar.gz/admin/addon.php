<?php



include "navigator.php";
$Buttons="";
include "title.php";

$AddonID=$_REQUEST['AddonID'];
$Password=ValidatePassword($_REQUEST['Password']);
$Directory=ValidateDirectory($_REQUEST['Directory']);
$AddonDomain=ValidateDomain($_REQUEST['AddonDomain']);
$Domain=ValidateDomain($_REQUEST['Domain']);

if (intval($PageNo)==0) {$PageNo=20;}

If ($Delete==1 and $Step==1)
{

	echo Error("Delete \"{$_REQUEST['AddonDomain']}\" ? <a href=\"javascript:Load('$CurrentFileName?Delete=1&AddonDomain={$_REQUEST['AddonDomain']}&Step=2')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName?ControlID=$ControlID')\" class=Action>No</a>");
	exit;
	
}

if ($Delete==1 and $Step==2)
{
	$AddonDomain=$_REQUEST['AddonDomain'];

	$Error=SSH ("/go/addon $AddonDomain AnyDomain AnyPassword delete",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
	
	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");
	
	exit;
	
}

if ($_REQUEST['AddonDomain']!="")
{
$Domain=ValidateDomain($_REQUEST['Domain']);
$Domain=strtolower($Domain);

	$Sql = "select AddonNo from Site where Domain='$Domain'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		if ($Row['AddonNo']==-1)
		{
		echo "<div class='UnderTitle'>This feature has been disabled by your administrator.</div>";
		exit;
		}
	
	}

include "access.php";

	if ($Password=="") {$Password=time();}
	
	$Error=SSH ("/go/addon $AddonDomain {$_REQUEST['Domain']} $Password",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");

	

}



	Echo "
	<form name=Form method=POST onsubmit='return Addon(this);' autocomplete='off' action='$CurrentFileName'><input type=hidden name=ServiceControl value='$ServiceControl'>
	<input type=hidden name=Edit value='$Edit'><input type=hidden name=ServiceControl value='$ServiceControl'>
	<input type=hidden name=AddonID value='$AddonID'>

	
	<div class='DivInput {$Dir}DivInput'>{$LNG['DomainAddon']}<br>
	<input type='text' name='AddonDomain' maxlength=100 class=InputText size=40>
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}<br>
	<select name='Domain' class=Select>
	";
	
	$Sql = "select * from Site where RecycleBin=0 $SearchSql order by Domain";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	echo "
	<option value='{$Row['Domain']}'>{$Row['Domain']}</option>
	";
	}
	
	echo "
	</select>
	</div>
	
	<div class='DivInput {$Dir}DivInput'>{$LNG['PasswordOptional']}<br>
	<input type='text' name='Password' maxlength=100 class=InputText size=40>
	</div>
	
	<div id=DivSubmit class=DivSubmit>
	";


	if ($Edit==1)
	{
		echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
	}
	else
	{
		echo "<input type=submit value='{$LNG['Save']}' Class=InputButton>";
	}

	Echo "
	</div>

</form>

	
";

	if($Edit!=1)
	{
	

		include "search.php";

		Echo "
	
		<div class=DivXTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

		<THEAD>
		
		<tr>
		
		<th  width='2%' height=40>

		</th>
		
		<th align='$DAlign' width='25%'>
		{$LNG['Addon']}
		</th>
		
		<th align='$DAlign' width='25%'>
		{$LNG['Domain']}
		</TD>
		
		<th align='$DAlign' width='25%'>
		{$LNG['CreatedDate']}
		</th>

		<th width='23%'>
	
		</TD>

		</THEAD>
		";


		$Table="Addon";$Field="RecycleBin=0";
		$DefaultSortBy="AddonDomain";
		$DefaultDirection=="ASC";
		include "include/sql.php";


		$X=0;
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$SerialNo=(($Page-1)*$PageNo)+($X+1);
			
			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

			echo "
			<tr class='$TDColor' divid=Find find='{$Row['Domain']}-{$Row['AddonDomain']}'>

			<TD align='middle' height=40>
			$SerialNo
			</TD>
			
			<TD><a  href='http://{$Row['AddonDomain']}' target='_blank'>{$Row['AddonDomain']}</a></td>

			<TD>{$Row['Domain']}</td>
			

			<TD>$CreatedDate</td>
			
			<TD align='$OAlign'>
			
			<a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=1&AddonDomain={$Row['AddonDomain']}')\" class=Action>Dlete</a>

			</TD>
			";
			
		$X++;
		}
		
		if ($X!=0)
		{
		echo "</TBODY>";
		}

		echo "
		<TFOOT>

		<tr>

		<th align='$DAlign' colspan=2>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=3>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>

		</TABLE>
		</div>
		";
		
	}

	
	
?>