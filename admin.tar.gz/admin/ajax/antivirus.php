<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";



$Domain=ValidateDomain($_REQUEST['Domain']);
$N=$_REQUEST['N'];


if ($Domain!="")
{

	if ($N==1)
	{
	$Error=SSH ("echo '' > /panel/{$Domain}.av",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Error=SSH ("screen -d -m bash -c 'clamscan --infected --remove --recursive /home/$Domain>/panel/{$Domain}.av'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	echo "";
	}
	else
	{
	$Content=@file_get_contents("/panel/{$Domain}.av");
	$Content=trim($Content);
	$Content=str_replace("\n","<br>",$Content);
	echo $Content;
	}
	
}


?>