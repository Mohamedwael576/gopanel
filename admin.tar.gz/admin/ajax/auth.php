<?php
session_start();


$Username=$_REQUEST['Username'];

include("/panel/admin/include/function/function.php");
include("/panel/include/config/config.php");

$Username=ValidateUsername($_REQUEST['Username']);

$Result = SQL("select * from Auth where AuthUser='$Username'");
foreach ($Result as $Row)
{
echo "1";
}

?>