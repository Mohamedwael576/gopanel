<?php
header('Content-Type: text/html; charset=UTF-8'); 

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";




$Username=ValidateUsername($_REQUEST['Username']);


if ($Username!="")
{

	
	$Result = SQL("select * from Site where Username='$Username'");
	foreach ($Result as $Row)
	{
	echo $Row['DocumentRoot'];
	}

}


?>