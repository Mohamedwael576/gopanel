<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";


$Domain=ValidateDomain($_REQUEST['Domain']);

if ($Domain!="")
{

	$Output=SSH ("grep '^@$Domain ' /etc/postfix/vmail_aliases",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	if (stristr($Output," "))
	{
	$OutputArray=explode(" ",$Output);

	$Email=$OutputArray[1];
	}

}

echo $Email;

?>