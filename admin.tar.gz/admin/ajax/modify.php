<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 


include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";






if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	echo "Sorry, You Are Not Allowed to Access This Page";
	exit;
}

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Blackhost Path";
	exit;
}

// Input ID
$ID=$_REQUEST['ID'];

$SiteID=$_REQUEST['SiteID'];
$Value=$_REQUEST['Value'];

if (stristr($ID,"DiskSpace"))
{

	$DiskSpace=$Value*1048576;
	SQL("UPDATE Site set DiskSpace='$DiskSpace' where SiteID='$SiteID'");
	if ($DiskSpace==0) 
	{
	$DiskSpace="Unlimited";
	}
	else
	{
	$DiskSpace=FormatSize($DiskSpace);
	}
	echo $DiskSpace;

}


if (stristr($ID,"Bandwidth"))
{

	$Bandwidth=$Value*1048576;
	SQL("UPDATE Site set Bandwidth='$Bandwidth' where SiteID='$SiteID'");
	if ($Bandwidth==0) 
	{
	$Bandwidth="Unlimited";
	}
	else
	{
	$Bandwidth=FormatSize($Bandwidth);
	}
	echo $Bandwidth;

}


if (stristr($ID,"FTPNo"))
{

	$FTPNo=intval($Value);
	SQL("UPDATE Site set FTPNo='$FTPNo' where SiteID='$SiteID'");
	if ($FTPNo==0) 
	{
	$FTPNo="Unlimited";
	}
	elseif ($FTPNo==-1) 
	{
	$FTPNo="Disabled";
	}
	echo $FTPNo;

}



if (stristr($ID,"EmailNo"))
{

	$EmailNo=intval($Value);
	SQL("UPDATE Site set EmailNo='$EmailNo' where SiteID='$SiteID'");
	if ($EmailNo==0) 
	{
	$EmailNo="Unlimited";
	}
	elseif ($EmailNo==-1) 
	{
	$EmailNo="Disabled";
	}
	echo $EmailNo;

}



if (stristr($ID,"DatabaseNo"))
{

	$DatabaseNo=intval($Value);
	SQL("UPDATE Site set DatabaseNo='$DatabaseNo' where SiteID='$SiteID'");
	if ($DatabaseNo==0) 
	{
	$DatabaseNo="Unlimited";
	}
	elseif ($DatabaseNo==-1) 
	{
	$DatabaseNo="Disabled";
	}
	echo $DatabaseNo;

}

if (stristr($ID,"SubDomainNo"))
{

	$SubDomainNo=intval($Value);
	SQL("UPDATE Site set SubDomainNo='$SubDomainNo' where SiteID='$SiteID'");
	if ($SubDomainNo==0) 
	{
	$SubDomainNo="Unlimited";
	}
	elseif ($SubDomainNo==-1) 
	{
	$SubDomainNo="Disabled";
	}
	echo $SubDomainNo;

}

if (stristr($ID,"AliasNo"))
{

	$AliasNo=intval($Value);
	SQL("UPDATE Site set AliasNo='$AliasNo' where SiteID='$SiteID'");
	if ($AliasNo==0) 
	{
	$AliasNo="Unlimited";
	}
	elseif ($AliasNo==-1) 
	{
	$AliasNo="Disabled";
	}
	echo $AliasNo;

}


if (stristr($ID,"AddonNo"))
{

	$AddonNo=intval($Value);
	SQL("UPDATE Site set AddonNo='$AddonNo' where SiteID='$SiteID'");
	if ($AddonNo==0) 
	{
	$AddonNo="Unlimited";
	}
	elseif ($AddonNo==-1) 
	{
	$AddonNo="Disabled";
	}
	echo $AddonNo;

}

?>