<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";


$PackageID=intval($_REQUEST['PackageID']);


if ($PackageID!="")
{

		
		$Result=SQL("select * from Package where PackageID='$PackageID'");
		foreach ($Result as $Row)
		{ 
	
			$DiskSpace=$Row['DiskSpace'];
			$Bandwidth=$Row['Bandwidth'];
			$FTPNo=$Row['FTPNo'];
			$EmailNo=$Row['EmailNo'];
			$DatabaseNo=$Row['DatabaseNo'];
			$SubDomainNo=$Row['SubDomainNo'];
			$AliasNo=$Row['AliasNo'];
			$AddonNo=$Row['AddonNo'];


			echo "$DiskSpace|$Bandwidth|$FTPNo|$EmailNo|$DatabaseNo|$SubDomainNo|$AliasNo|$AddonNo";
			

		}

}



?>