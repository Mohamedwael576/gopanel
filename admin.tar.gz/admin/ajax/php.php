<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";


if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	echo "Sorry, You Are Not Allowed to Access This Page";
	exit;
}

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Blackhost Path";
	exit;
}

$Command=$_REQUEST['Command'];
$Value=$_REQUEST['Value'];

if (stristr($Command,"memorylimit"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<=0)
	{
	$Value="-1";
	}
	elseif ($Value>0 and $Value<=32)
	{
	$Value="32M";
	}
	elseif ($Value>0 and $Value<=512)
	{
	$Value="{$Value}M";
	}
	
	if ($Value>512)
	{
	$Value="512M";
	}


}
elseif (stristr($Command,"disablefunctions"))
{
$Value.=",exec,shell_exec,system";
$Value=str_replace(" ",",",$Value);
$Value=str_replace(";",",",$Value);

$Array=explode(",",$Value);

	if (is_array($Array))
	{
		sort ($Array);
		$Array = array_unique($Array);

		$Disabled = ini_get('disable_functions');

		$Value="";
		foreach ($Array as &$Function) 
		{
		
			if (function_exists("$Function") or stristr(",$Disabled,",",$Function,"))
			{
			
				if ($Value=="")
				{
				$Value=$Function;
				}
				else
				{
				$Value.=",".$Function;
				}
			
			}	
		}
	}
	elseif (function_exists("$Value"))
	{
	
	}
	else
	{
	$Value="";
	}

}
elseif (stristr($Command,"maxexecutiontime"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<15)
	{
	$Value="30";
	}
	elseif ($Value>1800)
	{
	$Value="1800";
	}
	else
	{
	$Value=trim($Value);
	}

}
elseif (stristr($Command,"maxinputtime"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<0)
	{
	$Value="-1";
	}
	elseif ($Value<30)
	{
	$Value="60";
	}

}
elseif (stristr($Command,"maxinputvars"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<500)
	{
	$Value=500;
	}

}
elseif (stristr($Command,"postmaxsize"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<=0)
	{
	$Value="16M";
	}
	else
	{
	$Value="{$Value}M";
	}
	

}
elseif (stristr($Command,"uploadmaxfilesize"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<=0)
	{
	$Value="16M";
	}
	else
	{
	$Value="{$Value}M";
	}
	

}
elseif (stristr($Command,"sessiongcmaxlifetime"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<=0)
	{
	$Value="1440";
	}
}
elseif (stristr($Command,"errorreporting"))
{
$Value=trim($Value);

	if ($Value=="")
	{
	$Value="E_ERROR|E_PARSE";
	}
}
elseif (stristr($Command,"allowurlfopen") or stristr($Command,"enabledl") or stristr($Command,"zliboutputcompression"))
{

	if ($Value=="0" or stristr($Value,"f"))
	{
	$Value="Off";
	}
	else
	{
	$Value="On";
	}
}
elseif (stristr($Command,"/allowurlinclude") or stristr($Command,"/displayerrors") or stristr($Command,"/displaystartuperrors") or stristr($Command,"/fileuploads"))
{

	if ($Value=="1" or stristr($Value,"n"))
	{
	$Value="On";
	}
	else
	{
	$Value="Off";
	}
}
elseif (stristr($Command,"maxfileuploads"))
{
$Value=preg_replace("/[^0-9\-]/","", $Value);
$Value=intval($Value);

	if ($Value<=0)
	{
	$Value="20";
	}
}
else
{
exit;
}

if (trim($Value)!="")
{
	if (stristr($Value,"|"))
	{
	$BValue=str_replace("|","VerticalBar",$Value);
	$Error=SSH ("$Command $BValue",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	else
	{
	$Error=SSH ("$Command $Value",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
}

if (stristr($Error,"!"))
{
echo $Error;
}
else
{
echo $Value;
}

?>