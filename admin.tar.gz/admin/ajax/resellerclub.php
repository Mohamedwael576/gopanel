<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 


include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";



if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	echo "Sorry, You Are Not Allowed to Access This Page";
	exit;
}

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Go Panel Path";
	exit;
}

// Input ID
$ID=$_REQUEST['ID'];
$SiteID=$_REQUEST['SiteID'];
$Value=$_REQUEST['Value'];
$Value=str_replace('"','',$Value);
$Value=str_replace("'","",$Value);

if ($ID=="IP")
{
SQL("UPDATE Config SET ResellerclubIP='$Value'");
}
elseif ($ID=="UserID")
{
SQL("UPDATE Config SET ResellerclubUserID='$Value'");
}
elseif ($ID=="APIKey")
{
SQL("UPDATE Config SET ResellerclubAPIKey='$Value'");
}

echo $Value;

?>