<?php
session_start();
header('Content-Type: text/html; charset=UTF-8'); 

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	echo "Sorry, You Are Not Allowed to Access This Page";
	exit;
}

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Blackhost Path";
	exit;
}

$SMTPID=$_REQUEST['SMTPID'];
$Value=$_REQUEST['Value'];

if ($SMTPID=="SMTPHostname")
{

	$Value=trim($Value);


	if( preg_match( "/^(?:[-A-Za-z0-9]+\.)+[A-Za-z]{2,12}$/", $Value))
	{
	
	}
	elseif (filter_var($Value, FILTER_VALIDATE_IP)) 
	{
	
	}
	else
	{
	$Value="localhost";
	}
	
	
	SQL("update Config set SMTPHostname='$Value' where ConfigID=1");

	echo $Value;

}

if ($SMTPID=="SMTPPort")
{

	$Value=intval($Value);

	if($Value==0 or $Value>65535 or $Value<0)
	{
	$Value="587";
	}
	
	SQL("update Config set SMTPPort='$Value' where ConfigID=1");

	if ($Value=="993")
	{
	SQL("update Config set SMTPSecure='SSL' where ConfigID=1");
	}

	echo $Value;

}

if ($SMTPID=="SMTPUsername")
{

	$Value=trim($Value);

	SQL("update Config set SMTPUsername='$Value' where ConfigID=1");

	echo $Value;

}

if ($SMTPID=="SMTPPassword")
{

	$Value=trim($Value);

	SQL("update Config set SMTPPassword='$Value' where ConfigID=1");

	echo $Value;

}

?>