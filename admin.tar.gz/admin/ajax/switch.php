<?php
session_start();

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";


$Username=$_REQUEST['Username'];
$Password=$_REQUEST['Password'];

if ($DemoPassword!="")
{
	$Password=$DemoPassword;
}

if (stristr($Username,"'") or stristr($Username," and ")  or stristr($Username," or ") or stristr($Password,"'") or stristr($Password," and ")  or stristr($Password," or "))
{
	echo Error("Access denied");
	exit;
}

if (StartsWith(getcwd(),"/panel"))
{
	
	// Login to User Using root Password
	$Connect = ssh2_connect("localhost", $SSHPort);
	if (@ssh2_auth_password($Connect,$_SESSION['SessionSwitchUsername'],$_SESSION['SessionSwitchPassword']))
	{
		
		if ($Username=="root")
		{
		

			$Result = SQL("select * from User where UserID=1");
			foreach ($Result as $Row)
			{
				
				$_SESSION['SessionUserID']=$Row['UserID'];
				$_SESSION['SessionUsername']=$Row['Username'];
				$_SESSION['SessionSwitchUsername']=$Row['Username'];
				$_SESSION['SessionFullName']=$Row['FullName'];
				
				$_SESSION['SessionPassword']=$_SESSION['SessionSwitchPassword'];

				$_SESSION['SessionSSHPassword']=$_SESSION['SessionSwitchPassword'];
				
				
				$_SESSION['SessionUserGroup']=$Row['UserGroup'];
				

				echo "1";
				

				
			}
		
		}
		else
		{

			$Result = SQL("select * from Site where Username='$Username'");
			foreach ($Result as $Row)
			{
				$Success=1;
				
				$SessionAdminDomain=$_SERVER['HTTP_HOST'];
				$SessionAdminDomain=str_replace("www.","",$SessionAdminDomain);
				
				$_SESSION['SessionType']="Website";
				$_SESSION['SessionUsername']=$Row['Username'];
				$_SESSION['SessionDomain']=$Row['Domain'];
				$_SESSION['SessionFullName']=$Row['FullName'];
				
				$_SESSION['SessionPassword']=$Row['Password'];
				$_SESSION['SessionSalt']=$Row['Salt'];
				
				$_SESSION['SessionUserGroup']=5;
				
				echo "1";
				
			}
			
		}
		

		
	}
	
	
	
	
}
else
{
	echo "Invalid Gekk Panel Path";
	exit;
}

?>