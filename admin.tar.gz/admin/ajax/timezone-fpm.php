<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');

include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";


$Domain=ValidateDomain($_REQUEST['Domain']);

if ($Domain!="")
{

	$Sql = "select Timezone from Site where Domain='$Domain'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		$Timezone=trim($Row['Timezone']);
	}

	
	date_default_timezone_set($Timezone);
	
}

echo "$Timezone|&nbsp;Current Time: ".date ("D j M Y g:i a");

?>