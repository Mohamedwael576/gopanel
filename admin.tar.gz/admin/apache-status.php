<?php
include "nav.php";
$Buttons="<a href=\"javascript:Load('httplog.php')\" class='ButtonB {$Dir}ButtonB'>{$LNG['HTTPLogs']}</a>";
include "title.php";



	
		$OS=@file_get_contents("/panel/linux/os.db");
		$OS=trim($OS);
		if ($OS=="CentOS" or $OS=="Fedora" or $OS=="AlmaLinux" or $OS=="Rocky" or $OS=="RockyLinux")
		{
		$Error=SSH ("apachectl status",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}
		else
		{
		$Error=SSH ("sudo systemctl status apache2",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}
		
	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;

?>