<?php

include "nav.php";
$Buttons="<a href=\"javascript:Load('$CurrentFileName?Action=RestoreApacheConfiguration&ControlID=$ControlID&Page=$Page','$ControlID')\" class='ButtonB {$Dir}ButtonB'>{$LNG['RestoreDefault']}</a>";
include "title.php";

if ($_REQUEST['Action']=="RestoreApacheConfiguration")
{


	$OS=@file_get_contents("/panel/linux/os.db");
	$OS=trim($OS);
	if ($OS=="CentOS" or $OS=="Fedora")
	{
	$Error=SSH ("yes|cp -rf /etc/httpd/conf/httpd.bak /etc/httpd/conf/httpd.conf && /go/httpd",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	else
	{
	$Error=SSH ("yes|cp -rf /etc/apache2/apache2.bak /etc/apache2/apache2.conf && yes|cp -rf /etc/apache2/mods-enabled/dir.bak /etc/apache2/mods-enabled/dir.conf && /go/httpd",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	



	echo Error ("Restore default, Please wait...");
	
exit;
}



		$DirectoryIndex = SSH ("/go/directoryindex Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		
		$MaxKeepAliveRequests = SSH ("/go/maxkeepaliverequests Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		if (trim($MaxKeepAliveRequests)=="")
		{
		// 0 = Unlimited (Defalt Value)
		$MaxKeepAliveRequests=0;
		SSH ("/go/maxkeepaliverequests $MaxKeepAliveRequests",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}
				
		$KeepAliveTimeout = SSH ("/go/keepalivetimeout Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		if (trim($KeepAliveTimeout)=="")
		{
		// The recommended KeepAliveTimeout can be between 1 to 5.
		$KeepAliveTimeout=5;
		SSH ("/go/keepalivetimeout $KeepAliveTimeout",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}

		$KeepAlive = SSH ("/go/keepalive Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		if (trim($KeepAlive)=="")
		{
		// 
		$KeepAlive="On";
		SSH ("/go/keepalive $KeepAlive",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}
		

$Content=DesignCode($Content,"$Control (Content)");
echo $Content;

?>