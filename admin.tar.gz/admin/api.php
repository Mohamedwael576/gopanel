<?php

header('Content-Type: text/html; charset=UTF-8');




include("include/function/function.php");
include("../include/config/config.php");

$Action=$_REQUEST['Action'];
$ApiKey=$_REQUEST['ApiKey'];
$Email=trim($_REQUEST['Email']);
$Password=trim($_REQUEST['Password']);

if ($Action=="Renew")
{
	RenewVPS();
	exit;
}



$Sql = "select * from Config where ConfigID=1";
$Result = SQL($Sql);
foreach ($Result as $Row)
{
	$SSHPassword=$Row['SSHPassword'];
}

$Success=0;
$Sql = "select ApiKey from Api where ApiKey='$ApiKey'";
$Result = SQL($Sql);
foreach ($Result as $Row)
{

	$Success=1;
	
}

if ($Success!=1)
{

echo "Invalid API Key.";
exit;
}

if ($Action=="CreateAccount" or $Action=="ModifyAccount")
{

	$Edit=$_REQUEST['Edit'];
	$CurrentDomain=trim($_REQUEST['CurrentDomain']);
	$Password=ValidatePassword($_REQUEST['Password']);
	$Email=trim($_REQUEST['Email']);
	$PHPVersion=ValidateVersion($_REQUEST['PHPVersion']);
	$PackageID=intval($_REQUEST['PackageID']);
	$DiskSpace=intval($_REQUEST['DiskSpace']);
	$Bandwidth=intval($_REQUEST['Bandwidth']);
	$FTPNo=intval($_REQUEST['FTPNo']);
	$EmailNo=intval($_REQUEST['EmailNo']);
	$DatabaseNo=intval($_REQUEST['DatabaseNo']);
	$SubDomainNo=intval($_REQUEST['SubDomainNo']);
	$AliasNo=intval($_REQUEST['AliasNo']);
	$AddonNo=intval($_REQUEST['AddonNo']);
	$Skeleton=trim($_REQUEST['Skeleton']); if ($Skeleton=="") {$Skeleton="n";}
	$SSLCertificate=intval($_REQUEST['SSLCertificate']);
	$SSLRedirect=intval($_REQUEST['SSLRedirect']);
	$ExpiresOn=trim($_REQUEST['ExpiresOn']);
	
	
	$Domain=ValidateDomain($_REQUEST['Domain']);
	$Username=ValidateUsername($_REQUEST['Username']);
	$Domain=strtolower($Domain);
	$Domain=trim($Domain);

	if (StartsWith($Domain,"www."))
	{
	$Domain = substr($Domain, 4);
	}
	
	$Error=SSH ("/go/create -d $Domain -u $Username -p $Password -e $Email -v $PHPVersion -i $PackageID -q $DiskSpace -t $Bandwidth -f $FTPNo -m $EmailNo -b $DatabaseNo -o $SubDomainNo -a $AliasNo -n $AddonNo -k $Skeleton -s $SSLCertificate -r $SSLRedirect -g $FPM -x $ExpiresOn -h {$_SESSION['SessionUserID']}",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	echo $Error;
	

}








if ($Action=="Terminate")
{
	$Domain=ValidateDomain($_REQUEST['Domain']);
	$Domain=strtolower($Domain);
	$Domain=trim($Domain);


	$Error=SSH ("/go/terminate $Domain",$SSHUsername,$SSHPassword);
	echo $Error;

}

if ($Action=="Delete" or $Action=="delete")
{
	$Username=ValidateUsername($_REQUEST['Username']);
	$Username=trim($Username);


	$Error=SSH ("/go/delete $Username",$SSHUsername,$SSHPassword);
	echo $Error;

}

if ($Action=="ModifyPassword")
{
	$Domain=ValidateDomain($_REQUEST['Domain']);
	$Password=ValidatePassword($_REQUEST['Password']);

	$Error=SSH ("/go/password $Domain $Password",$SSHUsername,$SSHPassword);
	echo $Error;

}

if ($Action=="Suspend")
{

	$Domain=ValidateDomain($_REQUEST['Domain']);

	$Error=SSH ("/go/suspend $Domain suspend",$SSHUsername,$SSHPassword);
	echo $Error;

}

if ($Action=="Unsuspend")
{

	$Domain=ValidateDomain($_REQUEST['Domain']);

	$Error=SSH ("/go/suspend $Domain unsuspend",$SSHUsername,$SSHPassword);
	echo $Error;

}

if ($Action=="CreateEmail")
{
	$EmailArray=explode("@",$Email);
	$Domain=$EmailArray[1];

	$Sql = "select Email from Mail where Email='$Email'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{ 
	echo "Email $Email already exists.";
	exit;
	}


	$Error=SSH ("/go/mail $Email $Password $Domain add",$SSHUsername,$SSHPassword);
	echo $Error;

}


if ($Action=="ModifyEmail")
{
	$EmailArray=explode("@",$Email);
	$Domain=$EmailArray[1];

	$Exists=0;
	$Sql = "select Email from Mail where Email='$Email'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$Exists=1;
	}

	IF ($Exists==0)
	{
	echo "Email $Email not exists.";
	exit;
	}

	$Error=SSH ("/go/mail $Email $Password $Domain edit",$SSHUsername,$SSHPassword);
	echo $Error;

}










?>