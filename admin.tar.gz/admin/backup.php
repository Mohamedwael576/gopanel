<?php

include "navigator.php";

if (file_exists("/home/{$_SESSION['SessionUsername']}/www/backup"))
{
$Buttons="<a href=\"javascript:Load('history.php','0')\" class='ButtonB {$Dir}ButtonB'>{$LNG['BackupHistory']}</a>";
}

include "title.php";


if ($_REQUEST['Username']!="")
{
$Username=ValidateUsername($_REQUEST['Username']);

include "access.php";

$Destination=trim($_REQUEST['Destination']);
$Type=trim($_REQUEST['Type']);
$RemoteServer=trim($_REQUEST['RemoteServer']);
$RemoteUser=trim($_REQUEST['RemoteUser']);
$RemotePassword=trim($_REQUEST['RemotePassword']);
$RemoteDir=trim($_REQUEST['RemoteDir']);
$Email=trim($_REQUEST['Email']);
	

	if ($Type=="") {$Type="full";}
	
	$Error=SSH ("screen -d -m bash -c '/go/backup $Username $Type $Destination $RemoteServer $RemoteUser $RemotePassword $RemoteDir $Email'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	if ($Destination=="URL")
	{
	echo Error("{$LNG['GeneratingTemporaryDownloadURLPleaseWait']}...");
	}
	elseif ($Type=="full")
	{
	echo Error("{$LNG['FullBackupProgress']}...");
	}
	else
	{
	echo Error("{$LNG['WorkingOnIt']}...");
	}
	
	exit;

}

	echo "
	<form name=Form method=POST onsubmit='return Backup(this);' autocomplete='off' action='$CurrentFileName'>
	<input type=hidden name=ControlID value='$ControlID'>
	<input type=hidden name=Type value='{$_REQUEST['Type']}'>


	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}<br>

	";


		$Sql = "select * from Site where RecycleBin=0 $SearchSql";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		$Account['Domain'][]=$Row['Domain'];
		$Account['Username'][]=$Row['Username'];
		}
		
		array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);

		echo "<select name='Username' id='Username' class=Select>";
		
		for ($E=0;$E<count($Account['Domain']);$E++)
		{
			if ($Account['Domain'][$E]==$_REQUEST['Domain'])
			{
			echo "<option value='{$Account['Username'][$E]}' selected>{$Account['Domain'][$E]}</option>";
			}
			else
			{
			echo "<option value='{$Account['Username'][$E]}'>{$Account['Domain'][$E]}</option>";
			}
		}

		echo "</select>";
		

	
	echo "
	
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Destination']}<br>

	<select name='Destination' class=Select onchange='BackupDestination()'>
	<option value='HOMEDIR'>{$LNG['HomeDirectory']}</option>
	<option value='BACKUP'>{$LNG['BackupDirectory']}</option>
	<option value='URL'>{$LNG['TemporaryURL']}</option>
	<option value='FTP'>{$LNG['RemoteFTPServer']}</option>
	<option value='PASSIVEFTP'>{$LNG['RemoteFTPServerPassive']}</option>
	<option value='SCP'>{$LNG['SecureCopySCP']}</option>	
	</select>
	</div>
	
	<div class='DivInput {$Dir}DivInput'>{$LNG['Email']}<br>
	<input type='text' name='Email' maxlength=100 class=InputText>
	</div>


	<div class=DivInput style='display:none' id=RemoteServer>{$LNG['RemoteServer']}<br>
	<input type='text' name='RemoteServer' maxlength=100 class=InputText size=40>
	</div>

	<div class=DivInput style='display:none' id=RemoteUser>{$LNG['RemoteUser']}<br>
	<input type='text' name='RemoteUser' maxlength=100 class=InputText> 
	</div>

	<div class=DivInput style='display:none' id=RemotePassword>{$LNG['RemotePassword']}<br>
	<input type='text' name='RemotePassword' maxlength=100 class=InputText>
	</div>

	<div class=DivInput style='display:none' id=RemoteDir>{$LNG['RemoteDir']}<br>
	<input type='text' name='RemoteDir' maxlength=100 class=InputText size=40>
	</div>

	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['GenerateBackup']}' Class=InputButton>
	</div>

</form>
";

	
	
?>