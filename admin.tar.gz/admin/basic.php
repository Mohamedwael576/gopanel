<?php

include "nav.php";
$Buttons="";
include "title.php";

$AdminEmail=$_REQUEST['AdminEmail'];
$AlternativeAdminEmail=$_REQUEST['AlternativeAdminEmail'];
$AdminMobile=$_REQUEST['AdminMobile'];
$AlternativeAdminMobile=$_REQUEST['AlternativeAdminMobile'];
$ConfigPassword=trim($_REQUEST['ConfigPassword']);
$QueueNo=intval($_REQUEST['QueueNo']);

$WAInstanceID=$_REQUEST['WAInstanceID'];
$WAAPIKey=$_REQUEST['WAAPIKey'];

$SSHAlert=intval($_REQUEST['SSHAlert']);
$IMAPAlert=intval($_REQUEST['IMAPAlert']);
$Junk=intval($_REQUEST['Junk']);
$Welcome=intval($_REQUEST['Welcome']);

	if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
	{

		Echo "
		Sorry, You Are Not Allowed to Access This Page
		";

		exit;
	}


if ($_REQUEST['AdminEmail']!="")
{
	
	SQL("UPDATE Config SET AdminEmail='$AdminEmail',AlternativeAdminEmail='$AlternativeAdminEmail',AdminMobile='$AdminMobile',AlternativeAdminMobile='$AlternativeAdminMobile',QueueNo='$QueueNo',WAInstanceID='$WAInstanceID',WAAPIKey='$WAAPIKey',SSHAlert='$SSHAlert',IMAPAlert='$IMAPAlert',Junk='$Junk',Welcome='$Welcome'");
	
	$Error=SSH ("/go/basic $ConfigPassword",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	echo Error("$Error");
	
}

	$Result = SQL("select * from Config where ConfigID='1'");
	foreach ($Result as $Row)
	{
		$AdminEmail=$Row['AdminEmail'];
		$AlternativeAdminEmail=$Row['AlternativeAdminEmail'];
		$AdminMobile=$Row['AdminMobile'];
		$AlternativeAdminMobile=$Row['AlternativeAdminMobile'];
		$QueueNo=$Row['QueueNo'];
		
		$WAInstanceID=$Row['WAInstanceID'];
		$WAAPIKey=$Row['WAAPIKey'];

		if ($Row['SSHAlert']==1)
		{
		$SSHAlertChecked="checked";
		}
		
		if ($Row['IMAPAlert']==1)
		{
		$IMAPAlertChecked="checked";
		}
		
		if ($Row['Junk']==1)
		{
		$JunkChecked="checked";
		}
		
		if ($Row['Welcome']==1)
		{
		$WelcomeChecked="checked";
		}
		
	}

	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;

?>