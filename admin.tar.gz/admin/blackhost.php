<?php
include "navigator.php";
$Buttons="";
include "title.php";

$FullName=trim($_REQUEST['FullName']);
$MobNo=trim($_REQUEST['MobNo']);
$Email=trim($_REQUEST['Email']);

if ($Email!="")
{
	
	SQL("UPDATE Site SET FullName='$FullName',MobNo='$MobNo',Email='$Email' where Domain='{$_SESSION['SessionUsername']}'");

	echo Error("Your contact information and preferences have been updated.");
	
	
	exit;
}

$Result = SQL("select * from Site where Domain='{$_SESSION['SessionUsername']}'");
foreach ($Result as $Row)
{
	$FullName=$Row['FullName'];
	$MobNo=$Row['MobNo'];
	$Email=$Row['Email'];
}

Echo "

<div class=UnderTitle>
You may use an email address on a domain that this server hosts. However, we do not recommend this, because you may fail to receive messages when the server encounters problems. For example, if your mailbox exceeds its quota, you will not receive any new email, including notices.
</div>

<form name=Form method=POST onsubmit='return  ContactInformation(this);' autocomplete='off' action='$CurrentFileName'>

<div class='TitleB {$Dir}TitleB'>
Contact Information
</div>

<div class='DivInput {$Dir}DivInput'>Name<br>
<input type='text' name='FullName' id='FullName' value='$FullName' maxlength=100 class=InputText>
</div>

<div class='DivInput {$Dir}DivInput'>Mobile<br>
<input type='text' name='MobNo' id='MobNo' value='$MobNo' maxlength=100 class=InputText>
</div>

<div class='DivInput {$Dir}DivInput'>Email<br>
<input type='text' name='Email' id='Email' value='$Email' maxlength=100 class=InputText>
</div>

<div id=DivSubmit class=DivSubmit>
<input type=submit value='Save Changes' Class=InputButton>
</div>

</form>
";
?>