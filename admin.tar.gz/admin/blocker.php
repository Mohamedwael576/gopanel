<?php
include "navigator.php";
$Buttons="";
include "title.php";

if ($_REQUEST['Action']=="Export")
{
header("Content-Disposition: attachment; filename=parked-domain.txt");
header("Pragma: no-cache");
header("Expires: 0");

	$Sql = "select * from Blocker where BlockerID>=1 order by Blocker ASC";
	$Result = $PDO->query($Sql)->fetchAll();
	foreach ($Result as $Row)
	{
	echo "{$Row['Blocker']}\n";
	}


exit;
}



if (intval($PageNo)==0) {$PageNo=20;}


$IP=trim($_REQUEST['IP']);
$Username=ValidateUsername($_REQUEST['Username']);

if ($Delete==1)
{
include "access.php";

	$Error=SSH ("/gp/blocker $IP $Username delete",$_SESSION['SessionBlackhostUsername'],$_SESSION['SessionBlackhostPassword']);
	if (stristr($Error,"success"))
	{
	echo Error("The following IP address is now able to access your site: $IP");
	}
	else
	{
	echo Error($Error);
	}

}
elseif ($_REQUEST['IP']!="")
{
include "access.php";

	$Error=SSH ("/gp/blocker $IP $Username add",$_SESSION['SessionBlackhostUsername'],$_SESSION['SessionBlackhostPassword']);
	if (stristr($Error,"success"))
	{
	echo Error("Users from the IP address(es) $IP will not be able to access your site.");
	}
	else
	{
	echo Error($Error);
	}
	
}



	
	echo "

	<form name=Form method=POST onsubmit='return BlockIP(this);' autocomplete='off' action='$CurrentFileName'>
	<input type=hidden name=Edit value='$Edit'>
	<input type=hidden name=BlockerID value='$BlockerID'>


	
	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}<br>
	";

		$Sql = "select * from Site where RecycleBin=0 $SearchSql";
		$Result = $PDO->query($Sql)->fetchAll();
		foreach ($Result as $Row)
		{
		$Account['Domain'][]=$Row['Domain'];
		$Account['Username'][]=$Row['Username'];
		}
		
		$Sql = "select * from Addon where AddonID>=1 $SearchSql";
		$Result = $PDO->query($Sql)->fetchAll();
		foreach ($Result as $Row)
		{
		$Account['Domain'][]=$Row['Domain'];
		$Account['Username'][]=$Row['Username'];
		}
		
		array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);

		echo "<select name='Username' id='Username' class=Select>";
		
		for ($E=0;$E<count($Account['Domain']);$E++)
		{
			if ($Account['Domain'][$E]==$_REQUEST['Domain'])
			{
			echo "<option value='{$Account['Username'][$E]}' selected>{$Account['Domain'][$E]}</option>";
			}
			else
			{
			echo "<option value='{$Account['Username'][$E]}'>{$Account['Domain'][$E]}</option>";
			}
		}

		echo "</select>";
	
	echo "
	</div>

	
	<div class='DivInput {$Dir}DivInput'>{$LNG['IP']}<br>
	
	<input type='text' name='IP' maxlength=100 class=InputText size=40>
	
	</div>
	

	<div id=DivSubmit class=DivSubmit>
	";
	
	if ($Edit==1)
	{
		Echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
	}
	else
	{
		Echo "<input type=submit value='{$LNG['Block']}' Class=InputButton>";
	}

	Echo "
	</div>

</form>


	<div <div class='TitleB {$Dir}TitleB'>
	{$LNG['CurrentlBlockedIPAddresses']}
	</div>
	";
	

	include "search.php";
	
	echo "
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing=0 width=100% class=Table>

	<THEAD>
	
	<tr>
	
	<th width='2%' height=40>

	</th>
	
	<th align='$DAlign' width='30%'>
	{$LNG['IP']}
	</th>
	
	<th align='$DAlign' width='13%'>
	{$LNG['Username']}
	</th>
	
	<th align='$DAlign' width='10%'>
	{$LNG['Country']}
	</th>

	<th align='$DAlign' width='15%'>
	{$LNG['CreatedDate']}
	</th>

	<th align='$OAlign' width='20%'>

	</th>

	</tr>
	
	</THEAD>
	
	";



	$Table="Blocker";$Field="BlockerID>=1";
	$DefaultSortBy="Username";
	$DefaultDirection=="ASC";
	include "include/sql.php";

	$X=0;
	$Result = $PDO->query($Sql)->fetchAll();
	foreach ($Result as $Row)
	{
	
	
		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}

		
		$SerialNo=(($Page-1)*$PageNo)+$x;
		
		$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

		Echo "
		<tr class='$TDColor' divid=Find find='{$Row['IP']}-{$Row['Domain']}-{$Row['Country']}'>

		<TD width='2%' height=40>
		$SerialNo
		</TD>
		
		<TD><a href='http://{$Row['IP']}' target='_blank'>{$Row['IP']}</a></TD>

		<TD> {$Row['Username']} </TD>
		<TD> {$Row['Country']} </TD>
		
		<TD> $CreatedDate </TD>

		<TD align='$OAlign'>
		
		<a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=1&IP={$Row['IP']}&Username={$Row['Username']}')\" class=Action>Delete</a>

		</TD>
		"; 
		
	$X++;
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}




	echo "
	<TFOOT>

    <tr>

	<th align='$DAlign' colspan=3>
	Showing $X of $RowsNo records.
	</th>
	
	<th align='$OAlign' colspan=4>
	";
			
	include "pages.php";

	echo "
	</th>

    </tr>

	</TFOOT>
	

	
    </TABLE>
	</form>

	";




?>