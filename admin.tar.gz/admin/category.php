<?php
include "navigator.php";
$Buttons="";
include "title.php";

$Category=$_REQUEST['Category'];
$ControlMenu=$_REQUEST['ControlMenu'];



$X=0;
$Y=0;

if ($_SESSION['SessionUsername']=="root")
{
$ServiceSql = "and Service like '%Root%'";
}
elseif ($_SESSION['SessionType']=="Website")
{
$ServiceSql = "and Service like '%Website%'";
}
else
{
$ServiceSql = "and Service like '%Reseller%'";
}

echo "
<div class=DivIcon>
";


$Result = SQL("select * from Control where ServiceControl='Panel' and ControlMenu='$ControlMenu' $ServiceSql order by Sort");
foreach ($Result as $Row)
{
$X++;

	$ControlID=$Row['ControlID'];
	
	$Control=$LNG[$Row['Control']];
	$ControlMenu=$LNG[$Row['ControlMenu']];
	$ControlImage=$Row['ControlImage'];
	
	
	$ControlUrl=$Row['ControlUrl'];
	
	$ControlUrl=str_replace("[Service]",$Service,$ControlUrl);
	$ControlUrl=str_replace("[ServiceControl]",$ServiceControl,$ControlUrl);
	$ControlUrl=str_replace("[ModuleName]",$ModuleName,$ControlUrl);
	$ControlUrl=str_replace("[CTabNo]",$CTabNo,$ControlUrl);
	$ControlUrl=str_replace("[ControlID]",$ControlID,$ControlUrl);
	
	$ControlTarget=$Row['ControlTarget'];
	
	if ($ControlTarget=="")
	{
	echo "
	<a href='javascript:Load(\"$ControlUrl\",\"$ControlID\")' class='Main {$Dir}Main'>
	<div class=Icon>
	<img src='theme/{$_SESSION['SessionTheme']}/svg/$ControlImage' height=48 style='margin:5px'>
	<br>
	$Control	
	</div>
	</a>
	";
	}
	else
	{
	echo "
	<a href='$ControlUrl' target='$ControlTarget' class='Main {$Dir}Main'>
	<div class=Icon>
	<img src='theme/{$_SESSION['SessionTheme']}/svg/$ControlImage' height=48 style='margin:5px'>
	<br>
	$Control
	</div>
	</a>
	";
	}

	

	$CloseTable=0;
	if ($i%5==0)
	{
	$CloseTable=1;
	}
	
	$LastControlMenu=$ControlMenu;
	
}

echo "
</div>
";

?>