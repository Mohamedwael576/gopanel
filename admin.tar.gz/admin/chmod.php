<?php
include "navigator.php";
$Buttons="";
include "title.php";

$Domain=ValidateDomain($_REQUEST['Domain']);
$Permission=ValidateUsername($_REQUEST['Permission']);

if (intval($PageNo)==0) {$PageNo=20;}

	if ($Action=="Enable")
	{
		$Result = SQL("select * from Site where Domain='$Domain'");
		foreach ($Result as $Row)
		{
		$PHPVersion=$Row['PHPVersion'];
		}

	
		SQL("UPDATE Site set FPM='1' where Domain='$Domain'");
	
		$Error=SSH ("/go/apache $Domain $PHPVersion",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	elseif ($Action=="Disable")
	{
		$Result = SQL("select * from Site where Domain='$Domain'");
		foreach ($Result as $Row)
		{
		$PHPVersion=$Row['PHPVersion'];
		}

		SQL("UPDATE Site set FPM='0' where Domain='$Domain'");
	
		$Error=SSH ("/go/apache $Domain $PHPVersion",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	elseif ($Domain!="")		
	{
	include "access.php";

		$Error=SSH ("screen -d -m bash -c '/go/fix $Domain $Permission'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("File and folder permissions for $Domain has been changed [$Permission].");

	}
    
	include "search.php";
	
    Echo "
	<form name=CheckForm id=CheckForm action='$CurrentFileName'>
	<input type=hidden name=Action id=Action>
	
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

	<THEAD>
	
	<tr>
	
    <TH align='$DAlign' width='50%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=Domain')\">Domain</a>
    </TH>
	
    <TH align='center' width='10%'>
	FPM
    </TH>
	
    <TH width='40%'>
 
    </TH>
	
	</tr>
	
	</THEAD>
	
	";
	
	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";

   
	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	
	$FPM=$Row['FPM'];
	$Domain=$Row['Domain'];
	
		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}
		
		if ($FPM==1)
		{	
		$FPMCode="
		<label class='switch' onclick=\"Load('$CurrentFileName?Action=Disable&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
		<input type='checkbox' checked>
		<span class='slider round'></span>
		</label>
		";
		}
		else
		{
		$FPMCode="
		<label class='switch' onclick=\"Load('$CurrentFileName?Action=Enable&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
		<input type='checkbox'>
		<span class='slider round'></span>
		</label>
		";
		}


    ECHO "
	<tr class='$TDColor' divid=Find find='{$Row['Domain']}-{$Row['Email']}'>

    <TD>
    <a href=\"http://{$Row['Domain']}\" target='_blank'>{$Row['Domain']}</a>
    </td>

	<TD align='center'>
	$FPMCode
	</td>
	
	<TD align='$OAlign'>
	";
		if ($FPM==1)
		{
		echo "
		<a href=\"javascript:Load('$CurrentFileName?Domain=$Domain&Permission=777')\" class=Action>777</a>
		<a href=\"javascript:Load('$CurrentFileName?Domain=$Domain&Permission=755')\" class=Action>755</a>
		<a href=\"javascript:Load('$CurrentFileName?Domain=$Domain&Permission=555')\" class=Action>555</a>
		";
		}
		

	echo "
	</td>
    
	</tr>
	";
	
	$X++;
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "
	<TFOOT>

	<tr class=TdDown>

	<th align='$DAlign' colspan=6>
	Showing $X of $RowsNo records.
	</th>

	</tr>

	</TFOOT>

	</TABLE>
	</div>
	</form>
	";
	
	include "pages.php";


	
?>