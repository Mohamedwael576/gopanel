<?php
include "nav.php";
$Buttons="";
include "title.php";

if ($_REQUEST['Action']=="Export")
{
header("Content-Disposition: attachment; filename=parked-domain.txt");
header("Pragma: no-cache");
header("Expires: 0");

	$Sql = "select * from Site where SiteID>=1 order by Domain ASC";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	echo "{$Row['Domain']}\n";
	}


exit;
}



if (intval($PageNo)==0) {$PageNo=20;}


if ($_REQUEST['Action']=="Reset")
{

	$Sql = "UPDATE Site SET VisitorNo=0,RefererUrl='',TargetUrl=''";
	$Result = SQL($Sql);
	
}


if ($_REQUEST['Domain']!="")
{
$Domain=ValidateDomain($_REQUEST['Domain']);
$Domain=strtolower($Domain);


		if (!function_exists("ssh2_connect"))
		{
			echo Error("SSH2 PHP extension is not available.");
			exit;
		}


		$Error=SSH ("dig +noall +answer -t cname $Domain",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("<pre>CNAME Record(s): $Domain\n$Error</pre>");
		
exit;

}



	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;

	


?>