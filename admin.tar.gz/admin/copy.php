<?php

try {$PDOAddon = new PDO("sqlite:/geekpanel/database/addon.db");$PDOAddon->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);} catch (Exception $E) {echo $E->getMessage(); exit;}

include "navigator.php";

	echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionAdminTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['CopyFilesTitle']}</div>";


$Buttons="";
include "title.php";

if ($_REQUEST['To']!="")
{
	$From=ValidateDomain($_REQUEST['From']);
	$To=ValidateDomain($_REQUEST['To']);

	include "access.php";

	if (file_exists("/home/$To/www/index.php") or file_exists("/home/$To/www/index.html") or file_exists("/home/$To/www/index.htm")) 
	{
	echo Error("{$LNG['UnableCopyFilesTheDirectory']} /home/$To/www {$LNG['IsNotEmpty']}");
	}
	else
	{
	$Error=SSH ("screen -d -m bash -c '/gp/copy $From $To'",$_SESSION['SessionGeekpanelUsername'],$_SESSION['SessionGeekpanelPassword']);
	echo Error("{$LNG['TransferringFilesFrom']} $From {$LNG['To']} $To...");
	}


}



	Echo "
	


	
	<form name=Form method=POST onsubmit='return CopyFiles(this);' autocomplete='off' action='$CurrentFileName'>

	<div class='DivInput {$Dir}DivInput'>{$LNG['CopyFrom']}<br>
	";



		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['Domain'];
		}
		
		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['AddonDomain'];
		}
		
		sort($Domains);
		
		echo "
		<select name='From' id='From' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{
			if ($Domain==$_REQUEST['Domain'])
			{
			echo "<option value='$Domain' selected>$Domain</option>";
			}
			else
			{
			echo "<option value='$Domain'>$Domain</option>";
			}
		}

		echo "</select>

	</div>



	<div class='DivInput {$Dir}DivInput'>{$LNG['CopyTo']}<br>

		<select name='To' id='To' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{
			if ($Domain==$_REQUEST['Domain'])
			{
			echo "<option value='$Domain' selected>$Domain</option>";
			}
			else
			{
			echo "<option value='$Domain'>$Domain</option>";
			}
		}

		echo "
		</select>

	</div>


	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['Copy']}' Class=InputButton>
	</div>

	
</form>

	";


?>