</TD><?php
include "navigator.php";
$Buttons="";
include "title.php";



if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Blackhost Path";
	exit;
}

$Username=ValidateUsername($_REQUEST['Username']);

$Name=ValidateDatabaseName($_REQUEST['Name']);
$User=ValidateUsername($_REQUEST['User']);
$Pass=ValidatePassword($_REQUEST['Pass']);
$Source=ValidateDatabaseName($_REQUEST['Source']);


if ($_REQUEST['Username']!="")
{
	include "access.php";

	$Error=SSH ("/go/copydb $Username $Name $User $Pass $Source",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");	
	

	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

exit;
}


	Echo "
	<form name=Form method=POST onsubmit='return CopyMySQL(this);' autocomplete='off' action='$CurrentFileName'>

	<div <div class='TitleB {$Dir}TitleB'>{$LNG['CopyFrom']}</div>
	
	<div class='DivInput {$Dir}DivInput'>{$LNG['MySQLDatabase']}<br>

		<select name='Source' class=Select>
		";
		
		$Sql = "select * from Mysql where MysqlID>=1 order by Name";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
			echo "<option value='{$Row['Name']}'>{$Row['Name']} ({$Row['Username']})</option>";
		}
		
		echo "
		</select>
	
	</div>

	<div <div class='TitleB {$Dir}TitleB'>{$LNG['CopyTo']}</div>
	
	<div class='DivInput {$Dir}DivInput'>{$LNG['Username']}<br>

		<select name='Username' class=Select>
		";
		
		$Sql = "select * from Site where RecycleBin=0 $SearchSql order by Username";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
			if ($Row['Username']==$Username)
			{
			echo "<option value='{$Row['Username']}' selected>{$Row['Username']}</option>";
			}
			else
			{
			echo "<option value='{$Row['Username']}'>{$Row['Username']}</option>";
			}
		}
		
		echo "
		</select>
	
	</div>
	
	<div class='DivInput {$Dir}DivInput'>{$LNG['DatabaseName']}<br>
	<input type='Text' name='Name' value='$Name' maxlength=100 class=InputText>
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['DatabaseUsername']}<br>
	<input type='Text' name='User' value='$User' maxlength=100 class=InputText>
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Password']}<br>
	<input type='password' name='Pass' id='Password' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}' title='Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters' required maxlength=100 class=InputText>
	</div>
	
	<div id='message'>
	  <p id='letter' class='invalid'>A <b>lowercase</b> letter</p>
	  <p id='capital' class='invalid'>A <b>capital (uppercase)</b> letter</p>
	  <p id='number' class='invalid'>A <b>number</b></p>
	  <p id='length' class='invalid'>Minimum <b>8 characters</b></p>
	</div>

	<div id=DivSubmit class=DivSubmit>
	";
	
		if ($Edit==1)
		{
			echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
		}
		else
		{
			echo "<input type=submit value='{$LNG['Copy']}' Class=InputButton>";
		
		}
		
	echo "
	</div>

</form>
";





?>