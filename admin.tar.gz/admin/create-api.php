</TD><?php



include "navigator.php";
$Buttons="
<a href=\"phpmyadmin.php\" target='_blank' class='ButtonB {$Dir}ButtonB'>phpMyAdmin</a>
";
include "title.php";

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Blackhost Path";
	exit;
}


$Edit=$_REQUEST['Edit'];
$Reset=$_REQUEST['Reset'];
$ApiKey=$_REQUEST['ApiKey'];
$Domain=ValidateDomain($_REQUEST['Domain']);
$ApiID=$_REQUEST['ApiID'];

If ($Delete==1 and $Step==1)
{
	echo Error("Delete \"{$Name}\" ? <a href=\"javascript:Load('$CurrentFileName?Delete=1&ControlID=$ServiceID&ApiID=$ApiID&Name=$Name&Step=2','$ControlID')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName?ControlID=$ControlID','$ControlID')\" class=Action>No</a>");
	
	exit;
}

if ($Delete==1 and $Step==2)
{

	$Sql = "DELETE from Api where ApiID='$ApiID'";
	$Result = SQL($Sql);
	If ($Result)
	{
		echo Error("API $ApiKey ($ApiID) has been deleted.");
	}

}
elseif ($_REQUEST['IP']!="" or $_REQUEST['ApiKey']!="")
{

	if ($Reset==1)
	{
		$ApiKey=GeneratePassword(50);

		$Sql = "UPDATE Api SET ApiKey='$ApiKey' where ApiID='$ApiID'";
		$Result = SQL($Sql);
		If ($Result)
		{
		echo Error("API $ApiKey ($ApiID) updated successfully.");
		}
	
	$Edit="";
	}
	else
	{
		$TimeStamp=time();
		
		$ApiKey=GeneratePassword(50);
		
		$Sql = "INSERT INTO Api (ApiKey,Permission,IP,TimeStamp) VALUES ('$ApiKey','$Permission','$IP','$TimeStamp')";
		$Result = SQL($Sql);
		If ($Result)
		{
		echo Error("API $ApiKey created successfully.");
		}
	}
}

	$IP="";
	if ($Edit==1)
	{
		$Sql = "select * from Api where ApiID='$ApiID'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{ 
	
			$IP=$Row['IP'];

		}
				
	}


	Echo "
	<form name=Form method=POST onsubmit='return Api(this);' autocomplete='off' action='$CurrentFileName'><input type=hidden name=ServiceControl value='$ServiceControl'>
	<input type=hidden name=Edit value='$Edit'>
	<input type=hidden name=ApiID value='$ApiID'>

	<div class='DivInput {$Dir}DivInput'>IP<br>
	<input type='Text' name='IP' value='$IP' maxlength=100 class=InputText>
	</div>
	
	<div id=DivSubmit class=DivSubmit>
	";
	
		if ($Edit==1)
		{
			echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
		}
		else
		{
			echo "<input type=submit value='{$LNG['Create']}' Class=InputButton>";
		
		}
		
	echo "
	</div>

</form>
";



	if($Edit!=1)
	{

		include "search.php";
		
		Echo "
		<div class=DivTable>
		<table cellPadding='8' cellSpacing=0 width='100%' class=Table>

		<THEAD>
		
		<tr>
		
		<th width='2%'>

		</th>
		
		<th align='$DAlign' width='50%'>
		<a href=\"javascript:Load('$CurrentFileName?SortBy=Name')\">{$LNG['APIKey']}</a>
		</th>
				
		<th align='$DAlign' width='18%'>
		<a href=\"javascript:Load('$CurrentFileName?SortBy=TimeStamp')\">{$LNG['CreatedDate']}</a>
		</th>
		
		<th width='30%'>
	
		</th>

		</tr>
		
		</THEAD>

		";


		$Table="Api";$Field="ApiID>=1";
		$DefaultSortBy="ApiID";
		$DefaultDirection=="DESC";
		include "include/sql.php";
		
		$X=0;
		SQL($Sql);
		foreach ($Result as $Row)
		{
		
			$ApiID=$Row['ApiID'];
			
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$SerialNo=(($Page-1)*$PageNo)+($X+1);
			
			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

			echo "
			
			<tr class='$TDColor' divid=Find find='{$Row['Name']}-{$Row['TableName']}-{$Row['Columns']}-{$Row['Domain']}'>

			<TD align='middle'>
			$SerialNo
			</TD>

			<TD align='$DAlign'><a href=\"javascript:Load('$CurrentFileName?Edit=1&ApiID={$Row['ApiID']}&ApiKey={$Row['ApiKey']}&ControlID=$ControlID&Page=$Page')\">{$Row['ApiKey']}</a></TD>

						
			<TD align='$DAlign'>$CreatedDate</TD>

			<TD align='$OAlign'>
			
			<a href=\"javascript:Load('$CurrentFileName?Reset=1&ApiID={$Row['ApiID']}&ApiKey={$Row['ApiKey']}&ControlID=$ControlID&Page=$Page')\" class=Action>Reset API Key</a>
			
			<a href=\"javascript:Load('$CurrentFileName?Edit=1&ApiID={$Row['ApiID']}&ApiKey={$Row['ApiKey']}&ControlID=$ControlID&Page=$Page')\" class=Action>Edit</a>
			
			<a href=\"javascript:Load('$CurrentFileName?Delete=1&ApiID={$Row['ApiID']}&Step=1&ApiKey={$Row['ApiKey']}&ControlID=$ControlID&Page=$Page')\" class=Action>Delete</a>

			</TD>
			";
			
		$X++;
		}
		
		if ($X!=0)
		{
		echo "</TBODY>";
		}

		echo "
		<TFOOT>

		<tr>


		<th align='$DAlign' colspan=3>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=3>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>

		</TABLE>
		</div>
		";
		
		
	}



?>