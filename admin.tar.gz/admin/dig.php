<?php
include "nav.php";
$Buttons="";
include "title.php";

$SiteID=$_REQUEST['SiteID'];
$Password=ValidatePassword($_REQUEST['Password']);
$TXTRecord=$_REQUEST['TXTRecord'];


if ($_REQUEST['Domain']!="")
{
$Domain=ValidateDomain($_REQUEST['Domain']);
$Domain=strtolower($Domain);


		if (!function_exists("ssh2_connect"))
		{
			echo Error("SSH2 PHP extension is not available.");
			exit;
		}


		

		$Error=SSH ("dig +noall +answer $Domain",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("<pre>Track DNS: $Domain\n$Error</pre>");
		


exit;

}


	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;

?>