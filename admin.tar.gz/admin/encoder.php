<?php



include "navigator.php";
$Buttons="";
include "title.php";

if ($_REQUEST['Password']!="")
{
$Domain=ValidateUsername($_REQUEST['Domain']);
$Type=ValidateUsername($_REQUEST['Type']);
$Password=ValidatePassword($_REQUEST['Password']);

include "access.php";


	$Error=SSH ("screen -d -m bash -c '/go/encoder $Domain $Password'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("Website $Domain Successfully Encrypted.");
	
	$_SESSION['SessionPassword']=md5($Password);

}

	Echo "
	<form name=Form method=POST onsubmit='return Encoder(this);' autocomplete='off' action='$CurrentFileName'>

	<div class='DivInput {$Dir}DivInput'>
	Website
	<br>
	";

		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Account['Domain'][]=$Row['Domain'];
		$Account['Username'][]=$Row['Username'];
		}
		

		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Account['Domain'][]=$Row['Domain'];
		$Account['Username'][]=$Row['Username'];
		}
		
		array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);

		echo "<select name='Domain' id='Domain' class=Select>";
		
		for ($E=0;$E<count($Account['Domain']);$E++)
		{
			if ($Account['Domain'][$E]==$_REQUEST['Domain'])
			{
			echo "<option value='{$Account['Domain'][$E]}' selected>{$Account['Domain'][$E]}</option>";
			}
			else
			{
			echo "<option value='{$Account['Domain'][$E]}'>{$Account['Domain'][$E]}</option>";
			}
		}

		echo "</select>";
		
		
	echo "
	</div>

	<div class='DivInput {$Dir}DivInput'>
	{$LNG['EncryptionType']}
	
		<div style='padding-top:8px'>
		
			<label class=Label> {$LNG['Internal']}
			<input type='radio' name='Type' value='internal' checked>
			<span class='Radio'></span>
			</label>

			<label class=Label> {$LNG['External']}
			<input type='radio' name='Type' value='external'>
			<span class='Radio'></span>
			</label>
			
		</div>

	</div>

	<div class='DivInput {$Dir}DivInput'>
	{$LNG['EncryptionKey']}
	<br>
	<input type='text' name='Password' id='Password' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}' title='Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters' required maxlength=100 class=InputText>
	</div>
	
	<div id='message'>
	  <p id='letter' class='invalid'>A <b>lowercase</b> letter</p>
	  <p id='capital' class='invalid'>A <b>capital (uppercase)</b> letter</p>
	  <p id='number' class='invalid'>A <b>number</b></p>
	  <p id='length' class='invalid'>Minimum <b>8 characters</b></p>
	</div>

	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['EnctreptPHPCode']}' Class=InputButton>
	</div>

	
</form>

	";


?>