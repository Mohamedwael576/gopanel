<?php



include "navigator.php";
$Buttons="";
include "title.php";

$SiteID=intval($_REQUEST['SiteID']);

	$Result = SQL("select * from Site where SiteID='$SiteID'");
	foreach ($Result as $Row)
	{
	$Domain=$Row['Domain'];
	$FullName=$Row['FullName'];
	$MobNo=$Row['MobNo'];
	$Email=$Row['Email'];
	$Description=$Row['Description'];
	$ExpiresOn=substr($Row['ExpiresOn'],8,2)."/".substr($Row['ExpiresOn'],5,2)."/".substr($Row['ExpiresOn'],0,4);
	}

	Echo "
	<form name=Form method=POST onsubmit='return Expiration(this);' autocomplete='off' action='$CurrentFileName'>
	<input type=hidden name=SiteID value='$SiteID'>
	<input type=hidden name=ControlID value='$ControlID'>
	
	<div class='TitleB {$Dir}TitleB'>
	Client Profile
	</div>

	<div class='DivInput {$Dir}DivInput'>Domain<br>
	<input type='text' name='Domain' value='$Domain' readonly maxlength=100 class=InputText>
	</div>

	<div class='DivInput {$Dir}DivInput'>Name<br>
	<input type='text' name='FullName' id='FullName' value='$FullName' maxlength=100 class=InputText>
	</div>

	<div class='DivInput {$Dir}DivInput'>Mobile<br>
	<input type='text' name='MobNo' id='MobNo' value='$MobNo' maxlength=100 class=InputText>
	</div>

	<div class='DivInput {$Dir}DivInput'>Email<br>
	<input type='text' name='Email' id='Email' value='$Email' maxlength=100 class=InputText>
	</div>

	<div class='DivInput {$Dir}DivInput'>Expires On<br>
	<input type='text' name='ExpiresOn' id='ExpiresOn' value='$ExpiresOn' maxlength=100 class=InputText>
	</div>

	<div class='DivInput {$Dir}DivInput'>Description<br>
	<textarea name='Description' rows=7 id='Description' class='TextArea DivScroll'>$Description</textarea>
	</div>

	<div id=DivSubmit class=DivSubmit>
	";
	
		if ($Edit==1)
		{
		Echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
		}
		else
		{
		Echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
		}
		
	Echo "
	</div>

</form>
";
?>