<?php
session_start();

if (stristr($_SESSION['SessionDomain'],"."))
{

    header("Location: {$_SESSION['SessionDomain']}/");


}
else
{
echo "Please Login.";
exit;
}

?>