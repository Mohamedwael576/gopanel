<?php
include "/panel/include/config/config.php";
include "/panel/admin/include/function/function.php";

if ($DBHost=="")
{
echo "Database connection failed";
exit;
}

$Action=trim($_REQUEST['Action']);

// header("Content-Type: text/html; charset=UTF-8");
header("Content-Type: text/plain; charset=UTF-8");

$IP=trim($_REQUEST['IP']);
$ServerIP=trim($_REQUEST['ServerIP']);
$Type=trim($_REQUEST['Type']);

$Hostname=trim($_REQUEST['Hostname']);
$Name=trim($_REQUEST['Name']);
$Value=trim($_REQUEST['Value']);
$Password=trim($_REQUEST['Password']);

if ($Action=="Blacklist")
{

	if ($Type=="")
	{
    $Result = SQL("SELECT * FROM Blacklist where Visits>=3 ORDER BY SubnetNo DESC,Visits DESC");
	}
	else
	{
    $Result = SQL("SELECT * FROM Blacklist where Type='$Type' and Visits>=3 ORDER BY SubnetNo DESC,Visits DESC");
	}
    foreach ($Result as $Row)
    {
		if ($Row['SubnetNo']==256)
		{
		echo $Row['Subnet']."\n";
		}
		else
		{
		echo $Row['IP']."\n";
		}
	}

exit;
}

if ($Action=="Unblock")
{
	SQL("DELETE FROM Blacklist where IP='$IP'");	
	exit;
}

if ($IP!="" and $Hostname!="" and $ServerIP!="" and $Type!="")
{
	if (filter_var($IP, FILTER_VALIDATE_IP)) 
	{
		$Subnet=preg_replace('/\.[0-9]+$/', '.0/24', $IP);
		$SubnetNo=SQL("SELECT count(*) FROM Blacklist WHERE Subnet='$Subnet'");

		$TimeStamp=time();

		$SubnetExists=SQL("SELECT count(*) FROM Blacklist WHERE Subnet='$Subnet' and SubnetNo=256");
		if ($SubnetExists==0)
		{
			if ($SubnetNo>=5)
			{
			$SubnetNo="256";
			SQL("DELETE FROM Blacklist where Subnet='$Subnet'");	
			}
			
			SQL("INSERT OR IGNORE INTO Blacklist (IP,Subnet,SubnetNo,Hostname,ServerIP,Type,TimeStamp) VALUES ('$IP','$Subnet','$SubnetNo','$Hostname','$ServerIP','$Type','$TimeStamp')");
		
		}
		else
		{
			SQL("UPDATE Blacklist SET Visits=Visits+1,TimeStamp='$TimeStamp' where Subnet='$Subnet'");
		}
		
		SQL("UPDATE Blacklist SET Visits=Visits+1,TimeStamp='$TimeStamp' where IP='$IP'");	

	}
	
	exit;
}

if ($Value!="" and $Password!="")
{
// Save

	$Sql = "Delete from File where Hostname='$Hostname' and Name='$Name'";
	$Result = SQL($Sql);

	$TimeStamp=time();
	$Sql = "INSERT INTO File (Hostname,Name,Value,Password,TimeStamp) VALUES ('$Hostname','$Name','$Value','$Password','$TimeStamp')";
	$Result = SQL($Sql);

}
elseif ($Password!="")
{
// Open

    $Result = SQL("SELECT * FROM File where Hostname='$Hostname' and Name='$Name' and Password='$Password' ORDER BY FileID DESC LIMIT 1");
    foreach ($Result as $Row)
    {
		echo $Row['Value'];
	}

}

?>