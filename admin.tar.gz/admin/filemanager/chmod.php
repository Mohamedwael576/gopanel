<?php
include("verify.php");

echo "
<body bgcolor='#000000' style='padding:0px;margin:0px;'>
<title>Change Permissions</title>
";

$Permissions=ValidateNumber($_REQUEST['Permissions']);
$Path=ValidateDirectory($_REQUEST['Path']);


if ($_SERVER['REQUEST_METHOD']=="POST")
{
$Error=SSH ("chmod $Permissions $Path",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
echo "<script>window.close();</script>";
}

$Permissions = @substr(sprintf("%o", fileperms($Path)), -3);





echo "


	<form name=Form method=POST onsubmit='return Save(this);' action='chmod.php'>
	<input type=hidden name=Path value='{$_REQUEST['Path']}'>
	
	
	<table  cellPadding='0' cellSpacing=0 bgcolor=#888888 width='100%'>

	<TD bgcolor='#ECE9D8' width='100%'>
	<span style='font-family:Arial;font-size:12px;color:#888888;'>
	&nbsp;File(s) {$_REQUEST['Path']}
	</span>
	</TD>
	
	</table>

	<table  cellPadding='5' cellSpacing=5 width='100%'>

	
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	Owner Permissions:
	
	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	
	<input type='checkbox' id=OwnerRead onclick='Permission()'> Read
	<input type='checkbox' id=OwnerWrite onclick='Permission()'> Write
	<input type='checkbox' id=OwnerExecute onclick='Permission()'> Execute
	
	</td>
	
	<tr>
	
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	Group Permissions:

	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	<input type='checkbox' id=GroupRead onclick='Permission()'> Read
	<input type='checkbox' id=GroupWrite onclick='Permission()'> Write
	<input type='checkbox' id=GroupExecute onclick='Permission()'> Execute
	
	</td>
	
	<tr>
	
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>

	Public Permissions:

	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	<input type='checkbox' id=PublicRead onclick='Permission()'> Read
	<input type='checkbox' id=PublicWrite onclick='Permission()'> Write
	<input type='checkbox' id=PublicExecute onclick='Permission()'> Execute
	
	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	

	<input type=text id=Permissions name=Permissions value='$Permissions' onkeyup='CBox()' maxlength=3>
	</TD>
	
	<tr>
	
	
	<TD bgcolor='#ECE9D8' align='right' width='100%'>
	<input type=submit value='Change Permissions'>
	</TD>	


	</TABLE>

</form>


	<script type='text/javascript'>
	function Save()
	{
	

	
	}
	
	var OwnerRead=0;
	var OwnerWrite=0;
	var OwnerExecute=0;
	
	var GroupRead=0;
	var GroupWrite=0;
	var GroupExecute=0;

	var PublicRead=0;
	var PublicWrite=0;
	var PublicExecute=0;
	

	function Permission()
	{
		OwnerRead=0;
		if (document.getElementById('OwnerRead').checked==true)
		{
		OwnerRead=4;
		}
	
		OwnerWrite=0;
		if (document.getElementById('OwnerWrite').checked==true)
		{
		OwnerWrite=2;
		}
		
		OwnerExecute=0;
		if (document.getElementById('OwnerExecute').checked==true)
		{
		OwnerExecute=1;
		}
		
		OwnerPermissions=OwnerRead+OwnerWrite+OwnerExecute;
		
		//
		
		GroupRead=0;
		if (document.getElementById('GroupRead').checked==true)
		{
		GroupRead=4;
		}
	
		GroupWrite=0;
		if (document.getElementById('GroupWrite').checked==true)
		{
		GroupWrite=2;
		}
		
		GroupExecute=0;
		if (document.getElementById('GroupExecute').checked==true)
		{
		GroupExecute=1;
		}
		
		GroupPermissions=GroupRead+GroupWrite+GroupExecute;
		
		//
		
		//
		
		PublicRead=0;
		if (document.getElementById('PublicRead').checked==true)
		{
		PublicRead=4;
		}
	
		PublicWrite=0;
		if (document.getElementById('PublicWrite').checked==true)
		{
		PublicWrite=2;
		}
		
		PublicExecute=0;
		if (document.getElementById('PublicExecute').checked==true)
		{
		PublicExecute=1;
		}
		
		PublicPermissions=PublicRead+PublicWrite+PublicExecute;
		
		
		document.getElementById('Permissions').value=OwnerPermissions+''+GroupPermissions+''+PublicPermissions;
		
	
	}
	
	function CBox()
	{
	
		N=document.getElementById('Permissions').value;
	
		N1=N.substring(0,1);
		N2=N.substring(1,2);
		N3=N.substring(2);
	
		if (N1==0)
		{
		document.getElementById('OwnerRead').checked=false;
		document.getElementById('OwnerWrite').checked=false;
		document.getElementById('OwnerExecute').checked=false;
		}
		
		if (N2==0)
		{
		document.getElementById('GroupRead').checked=false;
		document.getElementById('GroupWrite').checked=false;
		document.getElementById('GroupExecute').checked=false;
		}
		
		if (N3==0)
		{
		document.getElementById('PublicRead').checked=false;
		document.getElementById('PublicWrite').checked=false;
		document.getElementById('PublicExecute').checked=false;
		}
		
		// 
		
		if (N1==1)
		{
		document.getElementById('OwnerRead').checked=false;
		document.getElementById('OwnerWrite').checked=false;
		}
		
		if (N2==1)
		{
		document.getElementById('GroupRead').checked=false;
		document.getElementById('GroupWrite').checked=false;
		}
		
		if (N3==1)
		{
		document.getElementById('PublicRead').checked=false;
		document.getElementById('PublicWrite').checked=false;
		}
		
		// 
		if (N1==2)
		{
		document.getElementById('OwnerRead').checked=false;
		document.getElementById('OwnerExecute').checked=false;
		}
		
		if (N2==2)
		{
		document.getElementById('GroupRead').checked=false;
		document.getElementById('GroupExecute').checked=false;
		}
		
		if (N3==2)
		{
		document.getElementById('PublicRead').checked=false;
		document.getElementById('PublicExecute').checked=false;
		}
		
		//
		
		if (N1==3)
		{
		document.getElementById('OwnerRead').checked=false;
		}
		
		if (N2==3)
		{
		document.getElementById('GroupRead').checked=false;
		}
		
		if (N3==3)
		{
		document.getElementById('PublicRead').checked=false;
		}
		
		//
		
		if (N1==4)
		{
		document.getElementById('OwnerWrite').checked=false;
		document.getElementById('OwnerExecute').checked=false;
		}
		
		if (N2==4)
		{
		document.getElementById('GroupWrite').checked=false;
		document.getElementById('GroupExecute').checked=false;
		}
		
		if (N3==4)
		{
		document.getElementById('PublicWrite').checked=false;
		document.getElementById('PublicExecute').checked=false;
		}
		
		//
		
		if (N1==5)
		{
		document.getElementById('OwnerWrite').checked=false;
		}
		
		if (N2==5)
		{
		document.getElementById('GroupWrite').checked=false;
		}
		
		if (N3==5)
		{
		document.getElementById('PublicWrite').checked=false;
		}
		
		//
		
		if (N1==6)
		{
		document.getElementById('OwnerExecute').checked=false;
		}
		
		if (N2==6)
		{
		document.getElementById('GroupExecute').checked=false;
		}
		
		if (N3==6)
		{
		document.getElementById('PublicExecute').checked=false;
		}
		
		//
		
		if (N1==1 | N1==3 | N1==5 | N1==7)
		{
		document.getElementById('OwnerExecute').checked=true;
		}
		
		if (N2==1 | N2==3 | N2==5 | N2==7)
		{
		document.getElementById('GroupExecute').checked=true;
		}
		
		if (N3==1 | N3==3 | N3==5 | N3==7)
		{
		document.getElementById('PublicExecute').checked=true;
		}	
		
		//
		
		if (N1==2 | N1==3 | N1==6 | N1==7)
		{
		document.getElementById('OwnerWrite').checked=true;
		}
		
		if (N2==2 | N2==3 | N2==6 | N2==7)
		{
		document.getElementById('GroupWrite').checked=true;
		}
		
		if (N3==2 | N3==3 | N3==6 | N3==7)
		{
		document.getElementById('PublicWrite').checked=true;
		}
		
		//
		
		if (N1==4 | N1==5 | N1==6 | N1==7)
		{
		document.getElementById('OwnerRead').checked=true;
		}
		
		if (N2==4 | N2==5 | N2==6 | N2==7)
		{
		document.getElementById('GroupRead').checked=true;
		}
		
		if (N3==4 | N3==5 | N3==6 | N3==7)
		{
		document.getElementById('PublicRead').checked=true;
		}
	
	}
	
	X=CBox();
	</script>
	";
	


?>