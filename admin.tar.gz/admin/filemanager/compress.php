<?php
include("verify.php");


echo "

<body bgcolor=#000000 style='padding:0px;margin:0px;'>
<title>Compress</title>

";

$Path=ValidateDirectory($_REQUEST['Path']);
$Type=ValidateDirectory($_REQUEST['Type']);
$ToFolder=ValidateDirectory($_REQUEST['ToFolder']);




if ($_SERVER['REQUEST_METHOD']=="POST")
{
	if ($Type=="TAR.GZ")
	{
		$ToFolderArray=explode("/",$ToFolder);
		$File=end($ToFolderArray);
		$WFile=str_replace(".tar.gz","",$File);
		$Directory=str_replace("/$File","",$ToFolder);



		$PathArray=explode("/",$Path);
		$PFile=end($PathArray);
		$Directory=str_replace("/$PFile","",$Path);


		$Error=SSH ("screen -d -m bash -c 'cd $Directory && tar -cpzf $File $WFile'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	
	if ($Type=="TAR.BZ2")
	{
		$ToFolderArray=explode("/",$ToFolder);
		$File=end($ToFolderArray);
		$WFile=str_replace(".tar.bz2","",$File);
		$Directory=str_replace("/$File","",$ToFolder);



		$PathArray=explode("/",$Path);
		$PFile=end($PathArray);
		$Directory=str_replace("/$PFile","",$Path);

		echo "cd $Directory && tar -jcf $File $WFile";

		$Error=SSH ("screen -d -m bash -c 'cd $Directory && tar -jcf $File $WFile'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	}
	
	if ($Type=="ZIP")
	{
		$ToFolderArray=explode("/",$ToFolder);
		$File=end($ToFolderArray);
		$WFile=str_replace(".zip","",$File);
		$Directory=str_replace("/$File","",$ToFolder);



		$PathArray=explode("/",$Path);
		$PFile=end($PathArray);
		$Directory=str_replace("/$PFile","",$Path);

		$Error=SSH ("screen -d -m bash -c 'cd $Directory && zip -r $File $WFile'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	
	}
	
	
	if ($Type=="TAR")
	{
		$ToFolderArray=explode("/",$ToFolder);
		$File=end($ToFolderArray);
		$WFile=str_replace(".tar","",$File);
		$Directory=str_replace("/$File","",$ToFolder);



		$PathArray=explode("/",$Path);
		$PFile=end($PathArray);
		$Directory=str_replace("/$PFile","",$Path);


	
		$Error=SSH ("screen -d -m bash -c 'cd $Directory && tar -cf $File $WFile'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	}
	

	echo "
<script>
window.opener.location='index.php?Path=$Directory';
window.close();
</script>
	";

	
	exit;
	
}

$PathArray=explode("/",$Path);
$ToFolder=$Path.".zip";

$File=end($PathArray);
$Directory=str_replace("/$File","",$Path);


echo "


	<form name=Form method=POST onsubmit='return Save(this);' action='compress.php'>
	<input type=hidden name=Path value='{$_REQUEST['Path']}'>
	
	


	<table  cellPadding='5' cellSpacing=5 width='100%'>

	
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	Compression Type:
	
	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	
	
	<input type='radio' name=Type value='ZIP' onclick=\"CompressType('zip')\" checked> ZIP Archive
	<br>
	<input type='radio' name=Type value='TAR.GZ' onclick=\"CompressType('tar.gz')\"> TAR.GZ Archive
	<br>
	<input type='radio' name=Type value='TAR' onclick=\"CompressType('tar')\"> TAR Archive
	<br>
	<input type='radio' name=Type value='TAR.BZ2' onclick=\"CompressType('tar.bz2')\"> TAR.BZ2 Archive
	
	</td>

	<tr>
	
	<TD align='center' width='100%'>
	
	<span style='font-family:Arial;font-size:12px;color:#888888;'>
	Files to compress:
	<br>
	
	
	
	<br>
	<br>
	Enter the name of the compressed archive and click Compress:
	<br>

	<input type=text id=ToFolder name=ToFolder value='$ToFolder'>
	</TD>
	
	<tr>
	
	
	<TD bgcolor='#ECE9D8' align='right' width='100%'>

	<input type=submit value='Compress'>
	</TD>


	</TABLE>

</form>


	<script type='text/javascript'>
	function Save()
	{
	

	
	}
	
	var File='$File';
	var Directory='$Directory';

	function CompressType(T)
	{

		
		document.getElementById('ToFolder').value=Directory+'/'+File+'.'+T;
		
	
	}
	
	</script>
	";
	


?>