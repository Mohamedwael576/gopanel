<?php
include("verify.php");

echo "

<body bgcolor=#ECE9D8 style='padding:0px;margin:0px;'>

";

$Code=$_REQUEST['Code'];
$Path=ValidateDirectory($_REQUEST['Path']);

if ($_SERVER['REQUEST_METHOD']=="POST")
{

	$Error=SSH ("echo '$Code' > $Path",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);


}

$Code=file_get_contents($_REQUEST['Path']);

echo "
<script type=\"text/javascript\" src=\"../include/js/editarea/edit_area_full.js\"></script>
<script type=\"text/javascript\">

editAreaLoader.init({
	id : \"Code\"		// textarea id
	,syntax: \"html\"			// syntax to be uses for highgliting
	,allow_toggle: false
	,toolbar: \"search, go_to_line, |, undo, redo, |, highlight, reset_highlight\"
	,start_highlight: true		// to display with highlight mode on start-up
});
</script>

	<form name=Form method=POST onsubmit='return Save(this);' action='edit.php'>
	<input type=hidden name=Path value='{$_REQUEST['Path']}'>
	<input type=hidden name=Permissions value='$Permissions'>
	
	<table  cellPadding='0' cellSpacing=0 bgcolor=#888888 width='100%'>

	<TD bgcolor='#ECE9D8' width='70%' style='border-left:1px solid #888888;border-right:1px solid #888888'>
	<span style='font-family:Arial;font-size:12px;color:#888888;'>
	&nbsp;Editing {$_REQUEST['Path']}
	</span>
	</TD>
	
	<TD bgcolor='#ECE9D8' align='right' width='30%'>
	<input type=submit value='Save Changes' style='font-family:Arial;font-size:12px;background:#888888;border:1px solid #888888;COLOR:#ECE9D8;margin:1px'>
	</TD>
	
	<tr>
	

	<TD bgcolor='#FFFFFF' colspan=2 align='center' width='100%'>
	<textarea rows='35' name='Code' id='Code' cols=112 style='width:100%;'>$Code</Textarea>
	</TD>


	</TABLE>

</form>

	
	

	<script type='text/javascript'>
	function Save()
	{
	
	}


	</script>
	";
	


?>