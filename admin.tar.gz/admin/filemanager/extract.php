<?php
include("verify.php");

$Domain=$_SESSION['SessionDomain'];

echo "

<body bgcolor=#000000 style='padding:0px;margin:0px;'>
<title>Extract</title>

";

$Path=ValidateDirectory($_REQUEST['Path']);
$Directory=ValidateDirectory($_REQUEST['Directory']);




if ($Directory!="")
{
	if (!StartsWith($Directory,"/home/{$_SESSION['SessionDomain']}"))
	{
	echo "Invalid Directory $Directory";
	exit;
	}
}


if ($_SERVER['REQUEST_METHOD']=="POST")
{
	if (EndsWith($Path,".tar.gz"))
	{

		$PathArray=explode("/",$Path);
		$File=end($PathArray);
		$Folder=str_replace("/$File","",$Path);

	$Error=SSH ("mkdir $Directory",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Error=SSH ("screen -d -m bash -c 'cd $Folder && tar -xzf $File -C $Directory && /aws/fix $Domain'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	}
	
	
	if (EndsWith($Path,".zip"))
	{

		$PathArray=explode("/",$Path);
		$File=end($PathArray);
		$Folder=str_replace("/$File","",$Path);
	
	$Error=SSH ("mkdir $Directory",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Error=SSH ("screen -d -m bash -c 'cd $Folder && unzip $File -d $Directory && /aws/fix $Domain'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	
	
	if (EndsWith($Path,".tar"))
	{

		$PathArray=explode("/",$Path);
		$File=end($PathArray);
		$Folder=str_replace("/$File","",$Path);

	$Error=SSH ("mkdir $Directory",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	$Error=SSH ("screen -d -m bash -c 'cd $Folder && tar -xf $File -C $Directory && /aws/fix $Domain'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	}
	
	if (EndsWith($Path,".tar.bz2"))
	{

		$PathArray=explode("/",$Path);
		$File=end($PathArray);
		$Folder=str_replace("/$File","",$Path);

	$Error=SSH ("mkdir $Directory",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Error=SSH ("screen -d -m bash -c 'cd $Folder && tar -jxf $File -C $Directory && /aws/fix $Domain'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	

	if (EndsWith($Path,".rar"))
	{

		$PathArray=explode("/",$Path);
		$File=end($PathArray);
		$Folder=str_replace("/$File","",$Path);

	$Error=SSH ("mkdir $Directory",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	$Error=SSH ("screen -d -m bash -c 'cd $Folder && unrar x $File $Directory && /aws/fix $Domain'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	}

	echo "
<script>
window.opener.location='index.php?Path=$Directory';
window.close();
</script>
	";

	exit;
	
}

$PathArray=explode("/",$Path);

$File=end($PathArray);
$Directory=str_replace("/$File","",$Path);

echo "
	<form name=Form method=POST onsubmit='return Save(this);' action='extract.php'>
	<input type=hidden name=Path value='{$_REQUEST['Path']}'>
	
	<table  cellPadding='5' cellSpacing=5 width='100%'>
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	Files to extract:
:
	
	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	$Path
	</td>

	<tr>
	
	<TD align='center' width='100%'>
	
	<span style='font-family:Arial;font-size:12px;color:#888888;'>
	Enter the path you wish to extract the files to (if you enter a directory that does not exist it will be created, and the archive extracted in the new directory) and click Extract:
	<br>
	

	<input type=text id=Directory name=Directory value='$Directory'>
	</TD>
	
	<tr>
	
	
	<TD bgcolor='#ECE9D8' align='right' width='100%'>

	<input type=submit value='Extract'>
	</TD>


	</TABLE>

</form>


	<script type='text/javascript'>
	function Save()
	{
	

	
	}
	
	var File='$File';
	var Directory='$Directory';

	function CompressType(T)
	{

		
		document.getElementById('ToFolder').value=Directory+'/'+File+'.'+T;
		
	
	}
	
	</script>
	";
	


?>