<?php
include("verify.php");

echo "

<body bgcolor=#000000 style='padding:0px;margin:0px;'>
<title>Rename</title>

";

$Path=ValidateDirectory($_REQUEST['Path']);
$File=ValidateDirectory($_REQUEST['File']);




if ($_SERVER['REQUEST_METHOD']=="POST")
{

	if (filetype($Path)=="file")
	{
	$PathArray=explode("/",$Path);
	$FileName=end($PathArray);
	$Directory=str_replace("/$FileName","",$Path);
	}
	else
	{
	$Directory=$Path;
	}

	if (!StartsWith($Directory,"/home/{$_SESSION['SessionDomain']}"))
	{
	echo "Invalid Directory $Directory";
	exit;
	}


	if (file_exists("$Directory/$File"))
	{
	echo "File $Directory/$File already exists";
	}
	else
	{
	$Error=SSH ("echo '' > $Directory/$File",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	
	


	echo "
<script>
window.opener.location='index.php?Path=$Directory';
window.close();
</script>
	";
	
	exit;
	
}

$PathArray=explode("/",$Path);
$File=end($PathArray);
$Directory=str_replace("/$File","",$Path);


echo "


	<form name=Form method=POST onsubmit='return Save(this);' action='file.php'>
	<input type=hidden name=Path value='{$_REQUEST['Path']}'>
	
	


	<table  cellPadding='5' cellSpacing=5 width='100%'>

	
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	New file will be created in:
	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	$Path
	</td>

	<tr>
	
	<TD align='center' width='100%'>
	
	New File Name:
	<br>
	

	<input type=text id=File name=File value=''>
	</TD>
	
	<tr>
	
	
	<TD bgcolor='#ECE9D8' align='right' width='100%'>

	<input type=submit value='Create New File'>
	<input type=button value='Cancel' onclick='window.close()'>
	</TD>


	</TABLE>

</form>


	<script type='text/javascript'>
	function Save()
	{
	

	
	}
	

	
	</script>
	";
	


?>