<?php
include("verify.php");


echo "

<body bgcolor=#000000 style='padding:0px;margin:0px;'>
<title>Rename</title>

";

$Path=ValidateDirectory($_REQUEST['Path']);
$Folder=ValidateDirectory($_REQUEST['Folder']);


if ($_SERVER['REQUEST_METHOD']=="POST")
{

	if (filetype($Path)=="file")
	{
	$PathArray=explode("/",$Path);
	$FileName=end($PathArray);
	$Directory=str_replace("/$FileName","",$Path);
	}
	else
	{
	$Directory=$Path;
	}


	if (!StartsWith($Directory,"/home/{$_SESSION['SessionDomain']}"))
	{
	echo "Invalid Directory $Directory";
	exit;
	}

	$Error=SSH ("mkdir $Directory/$Folder",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	
	

	echo "
<script>
window.opener.location='index.php?Path=$Directory/$Folder';
window.close();
</script>
	";
	
	exit;
	
}

$PathArray=explode("/",$Path);
$File=end($PathArray);
$Directory=str_replace("/$File","",$Path);


echo "


	<form name=Form method=POST onsubmit='return Save(this);' action='folder.php'>
	<input type=hidden name=Path value='{$_REQUEST['Path']}'>
	
	


	<table  cellPadding='5' cellSpacing=5 width='100%'>

	
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	New Folder will be created in:
	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	$Path
	</td>

	<tr>
	
	<TD align='center' width='100%'>
	
	New Folder Name:
	<br>
	

	<input type=text id=Folder name=Folder value=''>
	</TD>
	
	<tr>
	
	
	<TD bgcolor='#ECE9D8' align='right' width='100%'>

	<input type=submit value='Create New Folder'>
	<input type=button value='Cancel' onclick='window.close()'>
	</TD>


	</TABLE>

</form>


	<script type='text/javascript'>
	function Save()
	{
	

	
	}
	

	
	</script>
	";
	


?>