<?php
include("verify.php");

echo "

<body bgcolor=#000000 style='padding:0px;margin:0px;'>
<title>Rename</title>

";

$Path=ValidateDirectory($_REQUEST['Path']);
$File=ValidateDirectory($_REQUEST['File']);

if ($_SERVER['REQUEST_METHOD']=="POST")
{

$PathArray=explode("/",$Path);
$FileName=end($PathArray);
$Directory=str_replace("/$FileName","",$Path);

	if (filetype($Path)=="dir")
	{
	$Type="dir";
	
		$N=0;
		foreach ($PathArray as &$D) 
		{
		$N++;
		
			if ($P=="")
			{
			$P="{$D}";
			}
			else
			{
			$P.="/{$D}";
			}
			
			if (count($PathArray)!=$N)
			{
			$BackPath="/$P";
			}
		}
	}	
	
	
	if (!StartsWith($Directory,"/home/{$_SESSION['SessionDomain']}"))
	{
	echo "Invalid Directory $Directory";
	exit;
	}
	
	$Error=SSH ("mv $Path $Directory/$File",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	
	
	if ($Type="dir")
	{
	
	
	echo "
<script>
window.opener.location='index.php?Path=$BackPath';
window.close();
</script>
	";
	
	}
	else
	{
	echo "
	<script>
   //  window.onunload = refreshParent;
    function refreshParent() 
	{
        window.opener.location.reload();
		window.close();
    }
	</script>
	";
	
	}
	
	exit;
	
}

$PathArray=explode("/",$Path);
$File=end($PathArray);
$Directory=str_replace("/$File","",$Path);


echo "


	<form name=Form method=POST onsubmit='return Save(this);' action='rename.php'>
	<input type=hidden name=Path value='{$_REQUEST['Path']}'>
	
	


	<table  cellPadding='5' cellSpacing=5 width='100%'>

	
	<TD width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	Old file name:

	
	
	</td>
	
	<tr>
	
	<TD align='center' width='100%'>
	<span style='font-family:Arial;font-size:15px;color:#FFFFFF'>
	$Path
	</td>

	<tr>
	
	<TD align='center' width='100%'>
	
	<span style='font-family:Arial;font-size:12px;color:#888888;'>
	New file name:
	<br>
	

	<input type=text id=File name=File value='$File'>
	</TD>
	
	<tr>
	
	
	<TD bgcolor='#ECE9D8' align='right' width='100%'>

	<input type=submit value='Rename'>
	</TD>


	</TABLE>

</form>


	<script type='text/javascript'>
	function Save()
	{
	

	
	}
	

	
	</script>
	";
	


?>