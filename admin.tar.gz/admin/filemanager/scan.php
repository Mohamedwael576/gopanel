<?php
session_start();



function StartsWith($Haystack, $Needle)
{
    return $Needle === "" || strpos($Haystack, $Needle) === 0;
}

if ($_REQUEST['Path']=="")
{
$Path = "/home/{$_SESSION['SessionDomain']}/www";
}
else
{

	if (StartsWith($_REQUEST['Path'],"/home/{$_SESSION['SessionDomain']}"))
	{
	$Path=$_REQUEST['Path'];
	}
	else
	{
	$Path = "/home/{$_SESSION['SessionDomain']}/www";	
	}


}



$PathArray=explode("/",$Path);
$name=end($PathArray);

// Run the recursive function 

$response = scan($Path);


// This function scans the files folder recursively, and builds a large array

function scan($Path){

	$files = array();

	// Is there actually such a folder/file?

	if(file_exists($Path))
	{
	
		foreach(scandir($Path) as $f) 
		{
		
			if($f == '.' || $f == '..') 
			{
				continue; 
			}

			if(is_dir($Path . '/' . $f)) {

				// The path is a folder

				//$files[] = array(
				//	"name" => $f,
				//	"type" => "folder",
				//	"path" => $Path . '/' . $f,
				//	"items" => scan($Path . '/' . $f) // Recursively get the contents of the folder
				//);
				
				$files[] = array(
					"name" => $f,
					"type" => "folder",
					"path" => $Path . '/' . $f,
					"items" => ""
				);
				
			}
			
			else {

				// It is a file

				$files[] = array(
					"name" => $f,
					"type" => "file",
					"path" => $Path . '/' . $f,
					"size" => filesize($Path . '/' . $f) // Gets the size of this file
				);
			}
		}
	
	}

	return $files;
}



// Output the directory listing as JSON

header('Content-type: application/json');

echo json_encode(array(
	"name" => $name,
	"type" => "folder",
	"path" => $Path,
	"items" => $response
));
