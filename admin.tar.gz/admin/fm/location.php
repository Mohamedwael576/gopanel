<?php
session_start();

include "/panel/admin/include/function/function.php";
include "/panel/include/config/config.php";

if (stristr($_SESSION['SessionDomain'],"."))
{

	$Error=SSH ("screen -d -m bash -c '/go/fm {$_SESSION['SessionDomain']} login'",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
    header("Location: {$_SESSION['SessionDomain']}/");


}
else
{
echo "Please Login.";
exit;
}

?>