<?php




include "navigator.php";
$Buttons="";
include "title.php";

if (intval($PageNo)==0) {$PageNo=20;}

	
$ForwardID=$_REQUEST['ForwardID'];
$Username=ValidateUsername($_REQUEST['Username']);
$Domain=ValidateDomain($_REQUEST['Domain']);
$Email=ValidateEmail($_REQUEST['Email']);
$ForwardTo=$_REQUEST['ForwardTo'];
$KeepCopy=$_REQUEST['KeepCopy'];
$Reject=$_REQUEST['Reject'];
$RejectMessage=$_REQUEST['RejectMessage'];

If ($Delete==1 and $Step==1)
{
	echo Error("Are you sure you want to delete the email forwarder \"{$Email}\" ? <a href=\"javascript:Load('$CurrentFileName?Delete=1&Domain=$Domain&Email=$Email&Step=2')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName')\" class=Action>No</a>");
	
	exit;
}

if ($Delete==1 and $Step==2)
{
include "access.php";

	$Error=SSH ("/go/forward $Email - - delete",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
}

if ($_REQUEST['Username']!="")
{
include "access.php";

$Email=$Username."@".$Domain;

	if ($Reject==1)
	{
	$Error=SSH ("/go/reject $Email $Domain $RejectMessage",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
	}
	else
	{
		if ($KeepCopy==1)
		{
		$Error=SSH ("/go/forward $Email $Email,$ForwardTo $Domain",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
		}
		else
		{
		$Error=SSH ("/go/forward $Email $ForwardTo $Domain",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");	
		}
	}
	
}


	if ($Edit==1)
	{
		$Sql = "select * from Forward where Email='$Email'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
			$EmailArray=explode("@",$Row['Email']);
			$Username=$EmailArray[0];
			$Domain=$EmailArray[1];
			
			$ForwardTo=$Row['ForwardTo'];
			$ForwardTo=str_replace("{$Row['Email']},","",$ForwardTo);
			
			if (stristr($Row['ForwardTo'],"{$Row['Email']},"))
			{
			$KeepCopyChecked="checked";
			}
			
			$RejectMessage=$Row['RejectMessage'];
		}
	}

	echo "	
	<form name=Form method=POST onsubmit='return Forwarders(this);' autocomplete='off' action='$CurrentFileName'>
	<input type=hidden name=Edit value='$Edit'>
	<input type=hidden name=ForwardID value='$ForwardID'>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Email']}<br>
	";
	
	if ($Edit==1)
	{
		echo "
		
		<input type='hidden' name='Username' value='$Username'>
		<input type='hidden' name='Domain' value='$Domain'>
		$Username@$Domain
		";
	}
	else
	{
		Echo "
		<input type='Text' name='Username' value='$Username' maxlength=100 class=InputText30>
		@
		";
		

		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['Domain'];
		}
		
		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['AddonDomain'];
		}
		
		if (is_array($Domains))
		{
			sort($Domains);
		}
		else
		{
			$Domains[]="";
		}
		
		echo "
		<select name='Domain' id='Domain' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{

			if ($PlaceHolderDomain=="")
			{
			$PlaceHolderDomain=$Domain;
			}
		
			if ($Domain==$EmailArray[1])
			{
			echo "<option value='$Domain' selected>$Domain</option>";
			}
			else
			{
			echo "<option value='$Domain'>$Domain</option>";
			}

		}

		echo "</select>";
	}
	
	Echo "</div>

	<div class=DivInput id=ForwardTo>{$LNG['ForwardTo']}<br>
	<input type='text' name='ForwardTo' value='$ForwardTo' placeholder='example1@$PlaceHolderDomain,example2@gmail.com' maxlength=100 class=InputText size=40>
	</div>
	
	<div class=DivInput id=KeepCopy>
	<input type='checkbox' name='KeepCopy' id='KeepCopy' value='1' $KeepCopyChecked> {$LNG['KeepCopy']}
	</div>

	<div class=DivInput id=KeepCopyTr2>
	";
	
		if ($Edit==1 and $ForwardTo=="")
		{
		$RejectChecked="checked";
		}

	Echo "
	<input type='checkbox' name='Reject' id='Reject' value='1' onclick=\"SwitchReject()\" $RejectChecked> {$LNG['DiscardAndSendErrorToTheSender']}
	</div>

	<div class=DivInput id=RejectMessage style='display:none'>Failure Message<br>
	
	";
	
	if ($RejectMessage=="")
	{
	$RejectMessage="No such person at this address.";
	}
	
	echo "
	<input type='text' name='RejectMessage' value='$RejectMessage' class=InputText maxlength=255> Seen by Sender
	</div>

	
	<div id=DivSubmit class=DivSubmit>
	";

	if ($Edit==1)
	{
		Echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
	}
	else
	{
		Echo "<input type=submit value='{$LNG['AddForwarder']}' Class=InputButton>";
	}
		
	Echo "
	</div>

</form>
";
	
	if($Edit!=1)
	{
	

		include "search.php";

		Echo "
		<div class=DivTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

		<THEAD>
		
		<th width='2%'>

		</th>
		
		
		<th align='$DAlign' width='20%'>
		{$LNG['Email']}
		</th>
		
		<th align='$DAlign' width='15%'>
		{$LNG['ForwardTo']}
		</th>
		
		<th align='$DAlign' class='UnderBar' width='15%'>
		{$LNG['Username']}
		</th>

		<th align='$DAlign' class='UnderBar' width='8%'>
		{$LNG['KeepCopy']}
		</th>
		
		<th align=='$LNG[DAlign]' width='8%'>
		{$LNG['Discard']}
		</th>
		
		<th align='$OAlign' width='20%'>
	
		</th>

		</tr>
		
		</THEAD>

		";
		

		$Table="Forward";$Field="ForwardID>=1";
		$DefaultSortBy="Email";
		$DefaultDirection=="ASC";
		include "include/sql.php";
		

		$X=0;
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}

			$SerialNo=(($Page-1)*$PageNo)+$x;
			
			$ForwardTo=str_replace ("{$Row['Email']},","",$Row['ForwardTo']);

			if ($ForwardTo=="")
			{
			$ForwardTo="Discard: {$Row['RejectMessage']}";
			}
			
			if (stristr($Row['ForwardTo'],$Row['Email']))
			{
			$KeepCopyIcon="<img src='image/true.svg' style='width:24px;height:24px;'>";
			}
			else
			{
			$KeepCopyIcon="";
			}
			
			if ($Row['RejectMessage']!="")
			{
			$DiscardIcon="<img src='image/true.svg' style='width:24px;height:24px;'>";
			}
			else
			{
			$DiscardIcon="";
			}
			
			Echo "
			<tr name=R$i id=R$i divid=Find find='{$Row['Domain']}-{$Row['Date']}-{$Row['Time']}-{$Row['IP']}-{$Row['Country']}-{$Row['Descr']}-{$Row['Organization']}-{$Row['FileName']}-{$Row['Mode']}-{$Row['Operation']}-{$Row['Direction']}-{$Row['AccessMode']}-{$Row['Completed']}' class='$TDColor'>

			<TD align='middle' class='UnderBar' width='2%' height=40>
			
			$SerialNo
			</span>
			</TD>

			
			<TD>{$Row['Email']}</TD>

			<TD>$ForwardTo</TD>
			
			<TD>{$Row['Username']}</TD>

			<TD align='center'>$KeepCopyIcon</TD>
			
			<TD align='center'>$DiscardIcon</TD>
			
			<TD align='$OAlign'>
			
			<a href=\"javascript:Load('$CurrentFileName?Edit=1&ForwardID={$Row['ForwardID']}$&Domain={$Row['Domain']}&Email={$Row['Email']}')\" class=Action>Edit</a>
			<a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=1&Domain={$Row['Domain']}&Email={$Row['Email']}')\" class=Action>Delete</a>
			</TD>
			"; 
		
		$X++;
		}
		
		if ($X!=0)
		{
		echo "</TBODY>";
		}

		echo "
		<TFOOT>

		<tr>

		<th align='$DAlign' colspan=3>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=4>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>

		</TABLE>
		</div>
		";
	
	}

?>