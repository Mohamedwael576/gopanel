<?php
include "navigator.php";
$Buttons="";
include "title.php";

$SiteID=intval($_REQUEST['SiteID']);
$Domain=ValidateDomain($_REQUEST['Domain']);

if (intval($PageNo)==0) {$PageNo=20;}

if ($_SESSION['SessionSSHUsername']!="root")
{

	
	echo "
	Sorry, You Are Not Allowed to Access This Page
	";

	exit;
	
}



if ($Action!="")
{
include "access.php";


	
    $Result = SQL("select * from Site where Domain='$Domain'");
    foreach ($Result as $Row)
    {
	$PHPVersion=$Row['PHPVersion'];
	}

	if ($Action=="Enable")
	{
		SQL("UPDATE Site set FPM='1' where Domain='$Domain'");
	
		$Error=SSH ("/go/apache $Domain $PHPVersion",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	else
	{
	
		SQL("UPDATE Site set FPM='0' where Domain='$Domain'");
	
		$Error=SSH ("/go/apache $Domain $PHPVersion",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	
}



    
	include "search.php";
	
    Echo "
	<form name=CheckForm id=CheckForm action='$CurrentFileName'>
	<input type=hidden name=Action id=Action>
	
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

	<THEAD>
	
	<tr>
	
    <TH align='$DAlign' width='60%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=Domain')\">{$LNG['Domain']}</a>
    </TH>

    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=FPM')\">{$LNG['FPMStatus']}</a>
    </TH>
	
    <TH width='20%'>
 
    </TH>
	
	</tr>
	
	</THEAD>
	
	";
	
	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";    

	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	
	$Domain=$Row['Domain'];
	
	$FPM=$Row['FPM'];
		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}


		if ($FPM==1)
		{
		$FPMStatusCode="✔";
		}
		else
		{
		$FPMStatusCode="✖";
		}
	

    ECHO "
	<tr class='$TDColor' divid=Find find='{$Row['Domain']}-{$Row['Email']}'>

    <TD>
    <a href=\"http://{$Row['Domain']}\" target='_blank'>{$Row['Domain']}</a>
    </td>

	<TD>
    $FPMStatusCode
    </td>
	
	<TD align='$OAlign'>
	";
	
	if ($FPM==1)
	{	
	echo "
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=Disable&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox' checked>
	<span class='slider round'></span>
	</label>
	";
	}
	else
	{
	echo "
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=Enable&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox'>
	<span class='slider round'></span>
	</label>
	";
	
	}
	
	echo "
	</td>
    
	</tr>
	";
	
	$X++;
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "
	<TFOOT>

	<tr class=TdDown>

	<th align='$DAlign' colspan=6>
	Showing $X of $RowsNo records.
	</th>

	</tr>

	</TFOOT>

	</TABLE>
	</div>
	</form>
	";
	
	include "pages.php";


	
?>