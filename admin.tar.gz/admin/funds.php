<?php

try {$PDOCustomer=new PDO("sqlite:/geekpanel/database/customer.db");$PDOCustomer->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);} catch (Exception $E) {echo $E->getMessage();exit;}

include "navigator.php";
$Buttons="";
include "title.php";

$Edit=$_REQUEST['Edit'];
$ID=intval($_REQUEST['ID']);
$VPSID=intval($_REQUEST['VPSID']);

$ServerIP=trim($_REQUEST['ServerIP']);
$IP=trim($_REQUEST['IP']);
$MAC=trim($_REQUEST['MAC']);
$Hostname=trim($_REQUEST['Hostname']);
$CustomerID=intval($_REQUEST['CustomerID']);
$File=trim($_REQUEST['File']);
$DiskSpace=intval($_REQUEST['DiskSpace']);
$Cores=intval($_REQUEST['Cores']);
$Memory=intval($_REQUEST['Memory']);
$Hostname=trim($_REQUEST['Hostname']);
$VPSName=trim($_REQUEST['VPSName']);
$PlanName=trim($_REQUEST['PlanName']);
$Price=trim($_REQUEST['Price']);
$ExpiresOn=substr($_REQUEST['ExpiresOn'],6,4)."-".substr($_REQUEST['ExpiresOn'],3,2)."-".substr($_REQUEST['ExpiresOn'],0,2);


	if ($Edit==1)
	{
	

		$HostnameExists=0;
		$Sql = "select Hostname from VPS where Hostname='$Hostname' and VPSID!='$VPSID'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{ 
			$HostnameExists=1;
		}

		$IPExists=0;
		$Sql = "select Hostname from VPS where IP='$IP' and VPSID!='$VPSID'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{ 
			$IPExists=1;
		}
		
		$IDExists=0;
		$Sql = "select ID from VPS where ServerIP='$ServerIP' and ID='$ID' and VPSID!='$VPSID'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{ 
			$IDExists=1;
		}

		$MACExists=0;
		$Sql = "select MAC from VPS where MAC='$MAC' and VPSID!='$VPSID'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{ 
			$MACExists=1;
		}

		if ($IDExists==0)
		{

			if ($IPExists==0)
			{

				if ($MACExists==0)
				{

					if ($HostnameExists==0)
					{

						SQL("UPDATE VPS SET ID='$ID',ServerIP='$ServerIP',IP='$IP',MAC='$MAC',CustomerID='$CustomerID',File='$File',DiskSpace='$DiskSpace',Cores='$Cores',Memory='$Memory',Hostname='$Hostname',VPSName='$VPSName',PlanName='$PlanName',Price='$Price',ExpiresOn='$ExpiresOn' where VPSID='$VPSID'");
						echo Error("VPS IP $IP updated successfully.");
					
						$Edit="";
									
						$CustomerID="";
						$ServerIP="";
						$ID="";
						$IP="";
						$MAC="";
						$Hostname="";
						$VPSName="";
						$PlanName="";
						$DiskType="";
						$DiskSpace="";
						$Cores="";
						$Memory="";
						$Price="";
						$ExpiresOn="";
					
					}
					else
					{
					echo Error("Sorry, Hostname $Hostname already exists.");
					}
				}
				else
				{
				echo Error("Sorry, MAC $MAC already exists.");
				}
				
			}
			else
			{
			echo Error("Sorry, IP $IP already exists.");
			}
		
		}
		else
		{
		echo Error("Sorry, Container ID $ID already exists.");
		}
		
	}
	
	$Result = SQL("SELECT * FROM Customer where CustomerID>=1");
	foreach ($Result as $Row)
	{
	$Customer['CustomerID'][]=$Row['CustomerID'];
	$Customer['Email'][]=$Row['Email'];
	}
	

	if (is_array($Customer['CustomerID']))
	{
		array_multisort($Customer['Email'], SORT_ASC, SORT_STRING,$Customer['CustomerID'], SORT_NUMERIC, SORT_DESC);
		array_multisort($Server['ServerName'], SORT_ASC, SORT_STRING,$Server['ServerIP'], SORT_NUMERIC, SORT_DESC);

		Echo "
		<form name=Form method=POST onsubmit='return VPS(this);' autocomplete='off' action='$CurrentFileName'>
		<input type=hidden name=VPSID value='$VPSID'>
		<input type=hidden name=Edit value='$Edit'>

		<div class='DivInput {$Dir}DivInput'>
		{$LNG['CustomerID']}
		<br>

		<select name='CustomerID' id='CustomerID' class=Select>
		<option value='0' selected>Select Customer ID</option>
		";
		
		for ($E=0;$E<count($Customer['CustomerID']);$E++)
		{
			if ($Customer['CustomerID'][$E]==$CustomerID)
			{
			echo "<option value='{$Customer['CustomerID'][$E]}' selected>{$Customer['CustomerID'][$E]} | {$Customer['Email'][$E]}</option>";
			}
			else
			{
			echo "<option value='{$Customer['CustomerID'][$E]}'>{$Customer['CustomerID'][$E]} | {$Customer['Email'][$E]}</option>";
			}
		}

		echo "
		</select>
			
		</div>
		
		<div class='DivInput {$Dir}DivInput'>{$LNG['ContainerID']}<br>
		<input type='text' name='CurrentBalance' id='CurrentBalance' value='$CurrentBalance' maxlength=10 class=InputText>
		</div>

		<div class='DivInput {$Dir}DivInput'>
		{$LNG['Funds']}<br>
		<input type='text' name='Funds' value='$Funds' maxlength=100 class=InputText>
		</div>
		
		<div id=DivSubmit class=DivSubmit>

		<input type=submit value='{$LNG['AddFunds']}' Class=InputButton>

		</div>

		</form>

		";

	}
	else
	{
	
		echo Error("There are no customers. <a href=\"javascript:Load('customer.php')\" class=Action>{$LNG['AddModifyCustomers']}</a>");
		exit;
	
	}

	if($Edit!=1)
	{
	
		include "search.php";

		Echo "
		<div class=DivXTable>
		
		<table cellPadding='8' cellSpacing=0 width=100% class=Table>

		<THEAD>
		
		<tr>
		
		<th align='$DAlign' width='20%'>
		<a href=\"javascript:Load('$CurrentFileName?&SortBy=ServerIP')\">{$LNG['ServerIP']}</a>
		</th>
		
		<th align='$DAlign' width='20%'>
		<a href=\"javascript:Load('$CurrentFileName?&SortBy=IP')\">{$LNG['ContainerIP']}</a>
		</th>

		<th align='$DAlign' width='20%'>
		<a href=\"javascript:Load('$CurrentFileName?&SortBy=MAC')\">{$LNG['MACAddress']}</a>
		</th>

		<th align='$DAlign' width='20%'>
		<a href=\"javascript:Load('$CurrentFileName?&SortBy=PlanName')\">{$LNG['PlanName']}</a>
		</th>


		<th width='20%'>
		
		</span>
		</th>

		</tr>
		
		</THEAD>

		";

		$Table="VPS";$Field="VPSID>=1";
		$DefaultSortBy="ServerIP";
		$DefaultDirection=="ASC";
		include "include/sql.php";  

		$X=0;
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
			
			$VPSID=$Row['VPSID'];
			$CustomerID=$Row['CustomerID'];
		
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);
			
			Echo "
			<tr name=R$i id=R$i divid=Find find='{$Row['CustomerID']}' class='$TDColor'>

			<TD>{$Row['ServerIP']}</TD>

			<TD>{$Row['IP']}</TD>
			
			<TD>{$Row['MAC']}</TD>
			
			<TD>{$Row['PlanName']}</TD>
			
			<TD align='$OAlign'>
			
			<a href=\"javascript:Load('$CurrentFileName?Edit=1&Action=Edit&VPSID={$Row['VPSID']}&IP={$Row['IP']}')\" class=Action>Edit</a>&nbsp;
			<a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=1&VPSID={$Row['VPSID']}&IP={$Row['IP']}')\" class=Action>Delete</a>&nbsp;

			</TD>
			";
			
		$X++;
		}
		

		if ($X!=0)
		{
		echo "</TBODY>";
		}

		echo "
		<TFOOT>

		<tr>

		<th align='$DAlign' colspan=2>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=2>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>

		</TABLE>
		</div>
		</form>
		";
		
	}


echo "
</div>
";

	
?>