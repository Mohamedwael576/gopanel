<?php
include "navigator.php";

	$ServerInfo=SSH ("/go/serverinfo",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$ServerInfoArray=explode("|",$ServerInfo);
	$ServerDiskSpace=$ServerInfoArray[0];
	$ServerDiskUsed=$ServerInfoArray[1];
	$ServerDiskPercent=$ServerInfoArray[2];
	$Memory=$ServerInfoArray[3];
	$MemoryUsed=$ServerInfoArray[4];
	$MemoryPercent=$ServerInfoArray[5];
	$Cores=$ServerInfoArray[6];
	$CoresUsed=$ServerInfoArray[7];
	$CoresPercent=$ServerInfoArray[8];
	$ServerIP=$ServerInfoArray[9];	
	$Hostname=$ServerInfoArray[10];
	$OS=trim($ServerInfoArray[11]);
	$OSVersion=trim($ServerInfoArray[12]);
	$WS=trim($ServerInfoArray[13]);
	$WSVersion=trim($ServerInfoArray[14]);
	$Machine=trim($ServerInfoArray[15]);
	$MariaDBVersion=$ServerInfoArray[16];
	$Architecture=$ServerInfoArray[17];
	$KernelVersion=trim($ServerInfoArray[18]);
	$Processor=trim($ServerInfoArray[19]);
	$StorageType=trim($ServerInfoArray[20]);
	
$Buttons="";

$Category=$_REQUEST['Category'];
$ControlMenu=$_REQUEST['ControlMenu'];



if ($_SESSION['SessionUsername']=="root")
{

	
	$Result = SQL("select * from Config where ConfigID='1'");
	foreach ($Result as $Row)
	{
	$Version=intval($Row['Version']);
	$LoginNo=$Row['LoginNo'];
	}
	
	$Latest=0;
	if ($_SESSION['SessionLatest']!=1)
	{
	$_SESSION['SessionLatest']=1;
	$Latest=intval(Content("https://mohamedwael576.github.io/gopanel/latest.txt",3));
	}

	if ($Version!=$Latest and $Latest!=0)
	{
		$NewVersion=Version($Latest);
		if (stristr($NewVersion,"."))
		{
		echo "<div class=UnderNavigator id=Update><img src='theme/{$_SESSION['SessionTheme']}/image/update.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['ANewVersion']} $NewVersion {$LNG['IsAvailable']}. <a href='javascript:Update();' class=Action>{$LNG['UpdateNow']}</a></div>";
		}
	}
	elseif ($_SESSION['SessionTIP']!=1)
	{
		$_SESSION['SessionTIP']=1;

		$TIP=SSH ("/go/tip",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$TIP=str_replace("\n","",$TIP);
		$TIP=str_replace("\r","",$TIP);
		
		if ($TIP!="")
		{
		
			if (stristr($TIP,"Hostname is not valid"))
			{
			$TIP=Lang($TIP).". <a href=\"javascript:Load('hostname.php')\" class=Action>{$LNG['SetupHostname']}</a>";
			}
			elseif (stristr($TIP,"Not Resolving To"))
			{
			$TIP=Lang($TIP).". <a href=\"javascript:Load('hostname.php')\" class=Action>{$LNG['CorrectHostname']}</a>";
			}
			elseif (stristr($TIP,"Enter administrator email"))
			{
			$TIP=Lang($TIP).". <a href=\"javascript:Load('basic.php')\" class=Action>{$LNG['BasicawsPanelSetup']}</a>";
			}
			elseif (stristr($TIP,"Nameserver"))
			{
			$TIP=Lang($TIP).". <a href=\"javascript:Load('nameservers.php')\" class=Action>{$LNG['SetupNameservers']}</a>";
			}
			elseif (stristr($TIP,"Schedule") and stristr($TIP,"password"))
			{										
			$TIP=Lang($TIP).". <a href=\"javascript:Load('schedule.php')\" class=Action>{$LNG['CorrectRemoteServerInfo']}</a>";
			}
			elseif (stristr($TIP,"Schedule") and stristr($TIP,"daily"))
			{										
			$TIP=Lang($TIP).". <a href=\"javascript:Load('schedule.php')\" class=Action>{$LNG['CreateScheduledBackup']}</a>";
			}
			else
			{										
			$TIP=Lang($TIP);
			}

			echo "<div class=UnderNavigator id=Update><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>$TIP</div>";		
		}
	
	
	}

	echo "<div class=UNavigator>Hostname: $Hostname &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; OS: $OS $OSVersion &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <span title='Click to Copy' onclick=\"Copy('$ServerIP')\">Server IP: $ServerIP</span></div>";		
	


}
elseif ($_SESSION['SessionType']=="Website")
{
	$DomainArray=explode(".",$_SESSION['SessionDomain']);

	// $RegisterDomain=SSH ("/go/domain {$DomainArray[0]}",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	if (trim($RegisterDomain)!="")
	{
	echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>$RegisterDomain is available. Unlimited Web Hosting with Free Domain &nbsp;&nbsp;&nbsp; <a href='https://www.almutahida-ip.com/index.php?Domain=$RegisterDomain' target='_blank' class=Action>Get started on Blackhost now.</a></div>";
	}
}

if ($_SESSION['SessionUsername']=="root")
{
$ServiceSql = "Service like '%Root%'";
}
elseif ($_SESSION['SessionType']=="Website")
{
$ServiceSql = "Service like '%Website%'";
}
else
{
$ServiceSql = "Service like '%Reseller%'";
}


if ($_SESSION['SessionView']!="User" and $_SESSION['SessionView']!="Mobile")
{

	echo "
	<div class=DivIcon>
	";

	$X=0;
	
	$Result = SQL("select * from Control where $ServiceSql group by ControlMenu order by Sort");
	foreach ($Result as $Row)
	{
	$X++;


		$ControlMenu=$LNG[$Row['ControlMenu']];
		$ControlMenuImage=$Row['ControlMenuImage'];
		
		echo "
		<a href='javascript:Load(\"category.php?ControlMenu={$Row['ControlMenu']}\")' class='Main {$Dir}Main'>
		<div class='Icon {Dir}Icon'>
		<img src='theme/{$_SESSION['SessionTheme']}/svg/$ControlMenuImage' width=48 height=48 style='margin:5px'>
		<br>
		$ControlMenu
		</div>
		</a>
		";


		
	}

	echo "
	</div>
	";
}
else
{


	echo "
	
	<div class=DivIcon>
	";

	$X=0;
	$Result = SQL("select * from Control where $ServiceSql order by Sort");
	foreach ($Result as $Row)
	{
	$X++;

		$ControlID=$Row['ControlID'];
		
		$ControlMenu=$LNG[$Row['ControlMenu']];
		$ControlMenuImage=$Row['ControlMenuImage'];

		$Control=$LNG[$Row['Control']];
		$ControlImage=$Row['ControlImage'];

		$ControlUrl=$Row['ControlUrl'];
		$ControlUrl=str_replace("[Service]",$Service,$ControlUrl);
		$ControlUrl=str_replace("[ServiceControl]",$ServiceControl,$ControlUrl);
		$ControlUrl=str_replace("[ModuleName]",$ModuleName,$ControlUrl);
		$ControlUrl=str_replace("[CTabNo]",$CTabNo,$ControlUrl);
		$ControlUrl=str_replace("[ControlID]",$ControlID,$ControlUrl);
		
		$ControlTarget=$Row['ControlTarget'];
		
		$ControlText=$LNG[$Row['Control']];
		$ControlFind="$ControlText {$LNG[$Row['ControlMenu']]} {$Row['SubFiles']}";
	
		if ($LastControlMenu!=$ControlMenu)
		{
		
			if ($i!=1)
			{
			// Close Expand Content
			echo "
			</div>
			";
			}
		
			$ControlTitle="";
			$MenuControlFind="";


			$ResultQ = SQL("select * from Control where ControlMenu='{$Row['ControlMenu']}' ORDER BY Sort");
			foreach ($ResultQ as $RowQ)
			{
			
				$BControlFind="{$LNG[$RowQ['Control']]} {$LNG[$RowQ['ControlMenu']]} {$LNG[$RowQ['SubFiles']]}";
				
				$MenuControlFind.="-$BControlFind-";

			}
				
		
		
			echo "
			<div divid='Find' find='$MenuControlFind' class='Expanded'>
			$ControlMenu
			</div>
			
			<div divid='Find' find='$MenuControlFind' class='ExpandedContent'>
			";
		}

		if ($ControlTarget=="")
		{
				echo "
				<a href='javascript:Load(\"$ControlUrl\",\"$ControlID\")' class='Main {$Dir}Main'>
				<div divid='Find' name=Collapse"."$CollapseControlMenu id='C{$ControlID}' find='$ControlFind' class=Icon>
				<img src='theme/{$_SESSION['SessionTheme']}/svg/$ControlImage' height=48 style='margin:5px'>
				<br>
				$Control
				</div>
				</a>	
				";
		}
		else
		{
				echo "
				<a href='$ControlUrl' target='$ControlTarget' class='Main {$Dir}Main'>
				<div class=Icon>
				<img src='theme/{$_SESSION['SessionTheme']}/svg/$ControlImage' height=48 style='margin:5px'>
				<br>
				$Control
				</div>
				</a>
				";
		}


		$LastControlMenu=$ControlMenu;
	}
			// Close Last Expand Content
			echo "
			</div>
			";

	echo "
	</div>
	";


}




if ($_SESSION['SessionUsername']=="root")
{

	echo "
	<div class=DivChart>
	
		<div class=Chart> 
		
		<span class=ChartTitle>{$LNG['DiskUsage']}</span>
		<br>
			<center>
			<div class='progress-circle progress-$ServerDiskPercent'><span>$ServerDiskPercent</span></div>  
			<br>
			$ServerDiskUsed / $ServerDiskSpace ($StorageType)
			</center>
		  
		</div>

		<div class=Chart> 
		
		<span class=ChartTitle>{$LNG['MemoryUsage']}</span>
		<br>
			<center>
		
			<div class='progress-circle progress-$MemoryPercent'><span>$MemoryPercent</span></div>
		  
			<br>
		  
			$MemoryUsed / $Memory
			
			</center>
		  
		</div>
		
		
		
		<div class=Chart> 
		
		<span class=ChartTitle>{$LNG['ServerLoad']}</span>
		<br>
			<center>
		
			<div class='progress-circle progress-$CoresPercent'><span>$CoresPercent</span></div>  
		  
			<br>
			$CoresUsed / $Cores
			</center>
		  
		</div>
	
	</div>
	";
	
}
elseif ($_SESSION['SessionType']=="Website")
{


    $Result = SQL("select * from Site where Username='{$_SESSION['SessionUsername']}'");
    foreach ($Result as $Row)
    {	
		$ExpiresOn = date("D j M Y", strtotime($Row['ExpiresOn']));
		$DomainExpiresOn = date("D j M Y", strtotime($Row['DomainExpiresOn']));

		$AddonNo=$Row['AddonNo'];
		$SubDomainNo=$Row['SubDomainNo'];
		$AliasNo=$Row['AliasNo'];
		$EmailNo=$Row['EmailNo'];
		$FTPNo=$Row['FTPNo'];
		$DatabaseNo=$Row['DatabaseNo'];
		$PHPVersion=$Row['PHPVersion'];


		$SpaceUsed=FormatSize($Row['SpaceUsed']);
		
		if ($Row['DiskSpace']==0) 
		{
		$DiskSpace="Unlimited";
		
		$DiskSpacePercent=1;
		}
		else
		{
		$DiskSpace=FormatSize($Row['DiskSpace']);
		
		$DiskSpacePercent=floor($Row['SpaceUsed']*100/$Row['DiskSpace']); 
		}
		
			
		$BandwidthUsed=FormatSize($Row['BandwidthUsed']);
		
		if ($Row['Bandwidth']==0) 
		{
		$Bandwidth="Unlimited";
		
		$BandwidthPercent=1;
		}
		else
		{
		$Bandwidth=FormatSize($Row['Bandwidth']);
		
		$BandwidthPercent=floor($Row['BandwidthUsed']*100/$Row['Bandwidth']); ;
		}
		
		

	}
	
	$Emails=RowCount("select * from Mail where Username='{$_SESSION['SessionUsername']}'");
	$Addons=RowCount("select * from Addon where Username='{$_SESSION['SessionUsername']}'");
	$SubDomaons=RowCount("select * from Subdomain where Username='{$_SESSION['SessionUsername']}'");
	$Aliases=RowCount("select * from Alias where Username='{$_SESSION['SessionUsername']}'");
	$FTPs=RowCount("select * from Ftp where Username='{$_SESSION['SessionUsername']}'");
	$Databases=RowCount("select * from Mysql where Username='{$_SESSION['SessionUsername']}'");

    $Result = SQL("select sum(Size) as MySQLSize from Mysql where Username='{$_SESSION['SessionUsername']}'");
    foreach ($Result as $Row)
    {	
		$MySQLSize=FormatSize($Row['MySQLSize']);
	}
	

	$ShowDomain=$_SESSION['SessionDomain'];
	$ShowDomainTitle=$ShowDomain;
	if (strlen($ShowDomain)>20)
	{
	$ShowDomain=substr($ShowDomain,0,20)."...";
	}
	
	$HomeDirectory="/home/{$_SESSION['SessionDomain']}";
	$HomeDirectoryTitle=$HomeDirectory;
	if (strlen($HomeDirectory)>20)
	{
	$HomeDirectory=substr($HomeDirectory,0,20)."...";
	}
	
	echo "
	<div class=DivChart>
	

		<div class='Chart'>
			
			<div class=DivScroll style='height:100%;overflow-y:scroll'>
			
				<div class=ChartA>Domain</div>
				<div class=ChartB title='$ShowDomainTitle'>$ShowDomain</div>
				
				<div class=ChartA>Home Directory</div>
				<div class=ChartB title='$HomeDirectoryTitle'>$HomeDirectory</div>
				
				<div class=ChartA>Hosting Expires On</div>
				<div class=ChartB>$ExpiresOn</div>
				";
				
				if (!stristr($DomainExpiresOn,"1970"))
				{
				echo "
				<div class=ChartA>Domain Expires On</div>
				<div class=ChartB>$DomainExpiresOn</div>
				";
				}
				
				echo "
				<div class=ChartA>Shared IP Address</div>
				<div class=ChartB>$ServerIP</div>
					
				<div class=ChartA>Addon Domains</div>
				<div class=ChartB>$Addons / $AddonNo</div>
					
				<div class=ChartA>Subdomains</div>
				<div class=ChartB>$SubDomaons / $SubDomainNo</div>
						
				<div class=ChartA>Alias Domains</div>
				<div class=ChartB>$Aliases / $AliasNo</div>
					
				
				<div class=ChartA>FTP Accounts</div>
				<div class=ChartB>$FTPs / $FTPNo</div>
					
					
				<div class=ChartA>Email Accounts</div>
				<div class=ChartB>$Emails / $EmailNo</div>
					
				<div class=ChartA>MySQL Databases</div>
				<div class=ChartB>$Databases / $DatabaseNo</div>
					
				<div class=ChartA>MySQL Disk Usage</div>
				<div class=ChartB>$MySQLSize</div>
					
				<div class=ChartA>PHP Version</div>
				<div class=ChartB>$PHPVersion</div>
			
			</div>
		  
		</div>

		<div class=Chart> 
		
		<span class=ChartTitle>{$LNG['DiskUsage']}</span>
		<br>
			<center>
			<div class='progress-circle progress-$DiskSpacePercent'><span>$DiskSpacePercent</span></div>  
			<br>
			$SpaceUsed / $DiskSpace
			</center>
		  
		</div>



		<div class=Chart> 
		
		<span class=ChartTitle>Bandwidth</span>
		<br>
			<center>
		
			<div class='progress-circle progress-$BandwidthPercent'><span>$BandwidthPercent</span></div>  
		  
			<br>
		  
			$BandwidthUsed / $Bandwidth
			
			</center>
		  
		</div>
		
	
	</div>
	";

}


?>