<?php

include "nav.php";
if (file_exists("/etc/hostname.bak"))
{
$Buttons="<a href=\"javascript:Load('$CurrentFileName?Action=Restore&ControlID=$ControlID&Page=$Page','$ControlID')\" class='ButtonB {$Dir}ButtonB'>{$LNG['RestoreDefault']}</a>";
}
include "title.php";

echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['HostnameTitle']}</div>";

$Hostname=$_REQUEST['Hostname'];
$IMAPHostname=$_REQUEST['IMAPHostname'];

	if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
	{

		Echo "
		Sorry, You Are Not Allowed to Access This Page
		";

	exit;
	}

if ($_REQUEST['Action']=="Restore")
{

	$Error=SSH ("/go/hostname restore",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	
exit;
}


if ($_REQUEST['Hostname']!="")
{
	$Error=SSH ("/go/hostname $Hostname $IMAPHostname",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Error=Error($Error);
}

$Hostname=gethostname();

$IMAPHostname=@file_get_contents("/etc/imap");

$ServerIP=SSH ("wget -qO- checkip.amazonaws.com",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
$Reverse=SSH ("host $ServerIP",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
$ReverseArray=explode(" ",$Reverse);
$ReverseDNS=trim($ReverseArray[4]);
$ReverseDNS=trim($ReverseDNS,".");

if ($ReverseDNS!=$Hostname)
{
$HostnameError="<br><span class='IError'>Reverse DNS Mismatch ($ReverseDNS)</span>";
}



$Content=DesignCode($Content,"$Control (Content)");
echo $Content;

?>