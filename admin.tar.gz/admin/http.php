<?php
include "nav.php";
$Buttons="";
include "title.php";




if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	Echo "
	Sorry, You Are Not Allowed to Access This Page
	";

exit;
}


if ($_REQUEST['Action']!="")
{

	$WS=@file_get_contents("/panel/linux/ws.db");
	$WS=trim($WS);

	$Connect = ssh2_connect("localhost", $SSHPort);
	if (ssh2_auth_password($Connect,$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']))
	{
	
		if ($_REQUEST['Action']=="StatusHTTP")
		{
		$Stream = ssh2_exec($Connect, "cat /panel/http.status");
		
		stream_set_blocking($Stream, true);
		$Output = ssh2_fetch_stream($Stream, SSH2_STREAM_STDIO);
		$Content=stream_get_contents($Output);
		
			if (trim($Content)=="")
			{
			
				if ($WS=="NGINX")
				{
				$Content="NGINX restarted successfully.";
				}
				else
				{
				$Content="Apache restarted successfully.";
				}
			
			}
		
			echo Error("$Content");
			
			echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

			
		}
		else
		{
			
		
			if ($WS=="NGINX")
			{
			echo Error("Restarting NGINX Web Server, Please wait...");
			}
			else
			{
			echo Error("Restarting Apache Web Server, Please wait...");
			}
		
			$Stream = ssh2_exec($Connect, "/go/http");
			
			stream_set_blocking($Stream, true);
			$Output = ssh2_fetch_stream($Stream, SSH2_STREAM_STDIO);
			$Content=stream_get_contents($Output);
			
			echo Error("$Content");
		}
		
	
	}
	else
	{
	echo Error("Connection Refused");
	}
	
	exit;
	
}


	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;
?>
