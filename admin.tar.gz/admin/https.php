<?php
include "navigator.php";
$Buttons="";
include "title.php";

$SiteID=intval($_REQUEST['SiteID']);
$Domain=ValidateUsername($_REQUEST['Domain']);

if (intval($PageNo)==0) {$PageNo=20;}

if ($Action!="")
{
include "access.php";

	if ($Action=="1")
	{
		SQL("UPDATE Site set SSLRedirect='1' where Domain='$Domain'");
	
		$Error=SSH ("/go/https $Domain 1",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	else
	{
	
		SQL("UPDATE Site set SSLRedirect='0' where Domain='$Domain'");
	
		$Error=SSH ("/go/https $Domain 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	
}



    
	include "search.php";
	
    Echo "
	<form name=CheckForm id=CheckForm action='$CurrentFileName'>
	<input type=hidden name=Action id=Action>
	
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

	<THEAD>
	
	<tr>
	
    <TH align='$DAlign' width='60%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=Domain')\">{$LNG['Domain']}</a>
    </TH>

    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=SSLRedirect')\">{$LNG['HTTPSStatus']}</a>
    </TH>
	
    <TH width='20%'>
 
    </TH>
	
	</tr>
	
	</THEAD>
	
	";
	

	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";


	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	
	$Domain=$Row['Domain'];
	
	$SSLRedirect=$Row['SSLRedirect'];
		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}


		if ($SSLRedirect==1)
		{
		$HTTPSStatusCode="✔";
		}
		else
		{
		$HTTPSStatusCode="✖";
		}
	

    ECHO "
	<tr class='$TDColor' divid=Find find='{$Row['Domain']}-{$Row['Email']}'>

    <TD>
    <a href=\"http://{$Row['Domain']}\" target='_blank'>{$Row['Domain']}</a>
    </td>

	<TD>
    $HTTPSStatusCode
    </td>
	
	<TD align='$OAlign'>
	";
	
	if ($SSLRedirect==1)
	{	
	echo "
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=0&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox' checked>
	<span class='slider round'></span>
	</label>
	";
	}
	else
	{
	echo "
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=1&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox'>
	<span class='slider round'></span>
	</label>
	";
	
	}
	
	echo "
	</td>
    
	</tr>
	";
	
	$X++;
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "
	<TFOOT>

	<tr class=TdDown>

	<th align='$DAlign' colspan=6>
	Showing $X of $RowsNo records.
	</th>

	</tr>

	</TFOOT>

	</TABLE>
	</div>
	</form>
	";
	
	include "pages.php";


	
?>