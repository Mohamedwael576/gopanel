<?php

	function Moderator($ModeratorString,$ModeratorSize,$One)
	{
	global $Lng,$Service,$LService,$Theme,$LNG;

	$ModeratorStringArray=explode(",",$ModeratorString);
	
	if ($ModeratorSize=="")
	{
	$ModeratorSize=1;
	}

	if ($Lng=="ar")
	{
	$DAlign="right";
	$LeftPx="0px";
	}
	else
	{
	$DAlign="left";
	$LeftPx="-120px";
	}

echo "<script type='text/javascript' src='include/js/menu.js' type='text/javascript'></script>";

echo "

<style>



/* All <ul> tags in the menu including the first level */
.ModeratorMenuList, .ModeratorMenuList  ul {margin: 0; padding: 0; list-style: none;}

/* Submenus (<ul> tags) are hidden and absolutely positioned downwards from their parent */
.ModeratorMenuList ul { display: none; position: absolute; top: 27px; margin-top: -3px;  left: $LeftPx; width: 250px;}

/* Second and third etc. level submenus - position across from parent instead */
.ModeratorMenuList ul ul { top: 0px; margin-top: 0; left: 248px;}

/*
 All menu items (<li> tags). 'float: left' lines them up horizontally, and they are
 positioned relatively to correctly offset submenus. Also, they have overlapping borders.
*/
.ModeratorMenuList li { float: {$LNG['OAlign']}; display: block; position: relative;  border: 0px solid #330; margin-right: 0px;}

/* Items in submenus - override float/border/margin from above, restoring default vertical style */
.ModeratorMenuList ul li { float: none; margin: 0; margin-bottom: 0px;}
.ModeratorMenuList ul>li:last-child { margin-bottom: 0px;}

/* Links inside the menu */
.ModeratorMenuList a { display: block; padding-right: 1px; padding-left: 1px;color: #000; text-decoration: none;}

/* Lit  items: 'hover' is mouseover, 'highlighted' are parent items to visible menus */
.ModeratorMenuList a:hover, .ModeratorMenuList a.highlighted:hover, .ModeratorMenuList a:focus { color: #FFFFFF; background-color: #316ac5}
.ModeratorMenuList a.highlighted { color: #FFFFFF; margin: 0}

/*
 If you want per-item background images in your menu items, here's how to do it.
 1) Assign a unique ID tag to each link in your menu, like so: <a id='xyz' href='#'>
 2) Copy and paste these next lines for each link you want to have an image:
    .ModeratorMenuList a#xyz {
      background-image: url(out.gif);
    }
    .ModeratorMenuList a#xyz:hover, .ModeratorMenuList a.highlighted#xyz, .ModeratorMenuList a:focus {
     background-image: url(over.gif);
    }
*/

/* Only style submenu indicators within submenus. */
.ModeratorMenuList a .subind {
 display: none;
}
.ModeratorMenuList ul a .subind {
 display: block;
 float: right;
}


/* 'Escaped Comment' hack for horizontal menubar width in IE5/Mac */
.ModeratorMenuList a {
 float: left;
}
.ModeratorMenuList ul a {
 float: none;
}
/* \*/
.ModeratorMenuList a {
 float: none;
}
/* */


/*
 HACKS: IE/Win:
 A small height on <li> and <a> tags and floating prevents gaps in menu.
 * html affects <=IE6 and *:first-child+html affects IE7.
 You may want to move these to browser-specific style sheets.
*/
*:first-child+html .ModeratorMenuList ul li {
 float: left;
 width: 100%;
}

* html .ModeratorMenuList ul li {
 float: left;
 height: 1%;
}
* html .ModeratorMenuList ul a {
 height: 1%;
}
/* End Hacks */z

</style>

";


$ModeratorCode="

<UL class=ModeratorMenuList id=ModeratorMenuList"."$One"."Root>
";

	if ($ModeratorSize==1 or $ModeratorSize==2)
	{
	$ModeratorCode.="

	<LI><a><img src=\"$URL[IMAGE]/moderator-$Dir.gif\" onmouseover=\"this.src='$URL[IMAGE]/moderator-on-$Dir.gif';\" onmouseout=\"this.src='$URL[IMAGE]/moderator-$Dir.gif';\" ></a>
	<UL>
	<LI><table width=150 class=TableCategoryVertical><td colspan=2 class=TdTitle><span class=Title>{$LNG['Moderator']}</td>
	";

				for ($x=0;$x<=count($ModeratorStringArray)-1;$x++)
				{
				
				$ModeratorStringSplit=explode("|",$ModeratorStringArray[$x]);

					$ModeratorCode.="<tr style='cursor:pointer'><td width='2%' class=TdCategories onMouseOver=\"this.className='TdCategoriesOver'\" OnMouseOut=\"this.className='TdCategories'\"><img src='$URL[IMAGE]/$ModeratorStringSplit[3].gif' width=16 height=16 ></td><td valign=middle class=TdCategories onMouseOver=\"this.className='TdCategoriesOver'\" OnMouseOut=\"this.className='TdCategories'\" width=98% class=Category><a class=UserGroup$ModeratorStringSplit[2] href='$ScriptUrl/$LService-members-$UserGroup$ModeratorStringSplit[1]-$Lng.html' title='Gender: $ModeratorStringSplit[3]'>$ModeratorStringSplit[0]</a></td>";
				
				}	
				
		
	
	$ModeratorCode.="
	</table></LI>

	</UL>
	";
	}
	
	if ($ModeratorSize==2)
	{
	$ModeratorCode.="	
	

	<LI><a><img src=\"$URL[IMAGE]/module-$Dir.gif\" onmouseover=\"this.src='$URL[IMAGE]/module-on-$Dir.gif';\" onmouseout=\"this.src='$URL[IMAGE]/module-$Dir.gif';\" ></a>
	<UL>
	<LI><div style='background:#fff; overflow:auto;width:300px;height:200px;border-left:1px solid #7f9DB9;border-top:1px solid #7f9DB9;border-bottom:1px solid #7f9DB9;border-right:1px solid #7f9DB9;'><table width='100%' class=Table><td colspan=2 class=TdTitle><span class=Title>Moderator to</td>
	";
	

			// $Sql = "select * from Service where ID>=1 order by Service";
			// $Result = SQL($Sql);
			// foreach ($Result as $Row)
			// {


				
				// $ModuleImage=strtolower("image/module/$Row['Service'].gif");
				// if (file_exists("$ModuleImage"))
				// {
				// $ModeratorCode.="<tr><td width='5%' background='$URL[IMAGE]/moderator-category-bg.gif'><a class=Category href='$ListPageUrl'><img src='$ModuleImage' ></a></td><td background='$URL[IMAGE]/moderator-category-bg.gif' width='95%'><a class=ModeratorFont href='$ListPageUrl'>$ServiceName</a></td>";
				// }
				// else
				// {
				// $ModeratorCode.="<tr><td colspan=2 background='$URL[IMAGE]/moderator-category-bg.gif'><a class=Category href='$ListPageUrl'>$ServiceName</a></td>";
				// }	
			// }				
				
				
				
		
	
		$ModeratorCode.="
		</table></div></LI>

		</UL>
		";
	}


echo "
<script type='text/javascript'>

var ModeratorMenuList"."$One"." = new FSMenu('ModeratorMenuList"."$One"."', true, 'display', 'block', 'none');


ModeratorMenuList"."$One".".animations[ModeratorMenuList"."$One".".animations.length] = FSMenu.animFade;
//ModeratorMenuList"."$One".".animations[ModeratorMenuList"."$One".".animations.length] = FSMenu.animSwipeDown;
//ModeratorMenuList"."$One".".animations[ModeratorMenuList"."$One".".animations.length] = FSMenu.animClipDown;

var arrow = null;
if (document.createElement && document.documentElement)
{
arrow = document.createElement('span');
arrow.appendChild(document.createTextNode('>'));
// Feel free to replace the above two lines with these for a small arrow image...
//arrow = document.createElement('img');
//arrow.src = 'arrow.gif';
//arrow.style.borderWidth = '0';
arrow.className = 'subind';
}
addEvent(window, 'load', new Function('ModeratorMenuList"."$One".".activateMenu(\"ModeratorMenuList"."$One"."Root\", arrow)'));

</script>
";

// End Menus


return $ModeratorCode;
}
?>
