<?php

	function ProfilePhotoUpload($ProfilePhotoUploadSize)
	{
	global $Lng,$Service,$LService,$Theme,$LNG['OAlign'],$SEO,$Prefix,$SessionUserID,$SectionID;

	
	if ($ProfilePhotoUploadSize=="")
	{
	$ProfilePhotoUploadSize=1;
	}



	

	if ($Lng=="ar")
	{
	$DAlign="right";
	$LeftPx="0px";
	}
	else
	{
	$DAlign="left";
	$LeftPx="0px";
	}




echo "
<script type='text/javascript' src='include/js/menu.js' type='text/javascript'></script>

<style>



/* All <ul> tags in the menu including the first level */
.ProfilePhotoUploadMenuList, .ProfilePhotoUploadMenuList  ul {margin: 0; padding: 0; list-style: none;}

/* Submenus (<ul> tags) are hidden and absolutely positioned downwards from their parent */
.ProfilePhotoUploadMenuList ul { display: none; position: absolute; top: 230px; margin-top: -230px;  left: $LeftPx; width: 250px;}

/* Second and third etc. level submenus - position across from parent instead */
.ProfilePhotoUploadMenuList ul ul { top: 0px; margin-top: 0; left: 248px;}

/*
 All menu items (<li> tags). 'float: left' lines them up horizontally, and they are
 positioned relatively to correctly offset submenus. Also, they have overlapping borders.
*/
.ProfilePhotoUploadMenuList li { float: {$LNG['OAlign']}; display: block; position: relative;  border: 0px solid #330; margin-right: 0px;}

/* Items in submenus - override float/border/margin from above, restoring default vertical style */
.ProfilePhotoUploadMenuList ul li { float: none; margin: 0; margin-bottom: 0px;}
.ProfilePhotoUploadMenuList ul>li:last-child { margin-bottom: 0px;}

/* Links inside the menu */
.ProfilePhotoUploadMenuList a { display: block; padding-right: 0px; padding-left: 0px;color: #000000; text-decoration: none;}

/* Lit  items: 'hover' is mouseover, 'highlighted' are parent items to visible menus */

/*
 If you want per-item background images in your menu items, here's how to do it.
 1) Assign a unique ID tag to each link in your menu, like so: <a id='xyz' href='#'>
 2) Copy and paste these next lines for each link you want to have an image:
    .ProfilePhotoUploadMenuList a#xyz {
      background-image: url(out.gif);
    }
    .ProfilePhotoUploadMenuList a#xyz:hover, .ProfilePhotoUploadMenuList a.highlighted#xyz, .ProfilePhotoUploadMenuList a:focus {
     background-image: url(over.gif);
    }
*/

/* Only style submenu indicators within submenus. */
.ProfilePhotoUploadMenuList a .subind {
 display: none;
}
.ProfilePhotoUploadMenuList ul a .subind {
 display: block;
 float: right;
}


/* 'Escaped Comment' hack for horizontal menubar width in IE5/Mac */
.ProfilePhotoUploadMenuList a {
 float: left;
}
.ProfilePhotoUploadMenuList ul a {
 float: none;
}
/* \*/
.ProfilePhotoUploadMenuList a {
 float: none;
}
/* */


/*
 HACKS: IE/Win:
 A small height on <li> and <a> tags and floating prevents gaps in menu.
 * html affects <=IE6 and *:first-child+html affects IE7.
 You may want to move these to browser-specific style sheets.
*/
*:first-child+html .ProfilePhotoUploadMenuList ul li {
 float: left;
 width: 100%;
}

* html .ProfilePhotoUploadMenuList ul li {
 float: left;
 height: 1%;
}
* html .ProfilePhotoUploadMenuList ul a {
 height: 1%;
}
/* End Hacks */

</style>

";


$ProfilePhotoUploadCode="

<UL class=ProfilePhotoUploadMenuList id=ProfilePhotoUploadMenuListOneRoot>
";

	if ($ProfilePhotoUploadSize==1)
	{
	$ProfilePhotoUploadCode.="

	<LI><a><img src=\"$URL[IMAGE]/update-profile-photo-$Dir.gif\" onmouseover=\"this.src='$URL[IMAGE]/update-profile-photo-on-$Dir.gif';\" onmouseout=\"this.src='$URL[IMAGE]/update-profile-photo-$Dir.gif';\" ></a>
	<UL>
	<LI><div style='background:#fff; overflow:auto;width:349px;height:47px;border-left:1px solid #89d050;border-top:1px solid #89d050;border-bottom:1px solid #89d050;border-right:1px solid #89d050;'><table width='100%' class=TableZ><td bgcolor=#89d050><span color='#ffffff' style='FONT-WEIGHT: normal;FONT-SIZE: 12px; COLOR: #ffffff; FONT-FAMILY: Arial,Verdana,Comic Sans MS'>Upload a Profile Picture</td>
	<tr>
	
	<td align=middle bgcolor='#ffffff'>
	<iframe frameborder=NO marginwidth=0 marginheight=0 src='iframe/profile.php?UserID=$SessionUserID' width=343 height=26></iframe>
	</td>
	

	</table></div></LI>

	</UL>
	";
	}
	
	if ($ProfilePhotoUploadSize==2)
	{
	$ProfilePhotoUploadCode.="

	<LI><a><img src=\"$URL[IMAGE]/create-new-album-$Dir.gif\" onmouseover=\"this.src='$URL[IMAGE]/create-new-album-on-$Dir.gif';\" onmouseout=\"this.src='$URL[IMAGE]/create-new-album-$Dir.gif';\" ></a>
	<UL>
	<LI><div style='background:#fff; overflow:auto;width:349px;height:47px;border-left:1px solid #89d050;border-top:1px solid #89d050;border-bottom:1px solid #89d050;border-right:1px solid #89d050;'><table width='100%' class=TableZ><td bgcolor=#89d050><span color='#ffffff' style='FONT-WEIGHT: normal;FONT-SIZE: 12px; COLOR: #ffffff; FONT-FAMILY: Arial,Verdana,Comic Sans MS'>Create new album</td>
	<tr>
	
	<td align=middle bgcolor='#ffffff'>
	<iframe frameborder=NO marginwidth=0 marginheight=0 src='iframe/create-album.php?UserID=$SessionUserID' width=343 height=26></iframe>
	</td>
	

	</table></div></LI>

	</UL>
	";
	}
	
	if ($ProfilePhotoUploadSize==3)
	{
	$ProfilePhotoUploadCode.="

	<LI><a><img src=\"$URL[IMAGE]/create-new-folder-$Dir.gif\" onmouseover=\"this.src='$URL[IMAGE]/create-new-folder-on-$Dir.gif';\" onmouseout=\"this.src='$URL[IMAGE]/create-new-folder-$Dir.gif';\" ></a>
	<UL>
	<LI><div style='background:#fff; overflow:auto;width:349px;height:47px;border-left:1px solid #89d050;border-top:1px solid #89d050;border-bottom:1px solid #89d050;border-right:1px solid #89d050;'><table width='100%' class=TableZ><td bgcolor=#89d050><span color='#ffffff' style='FONT-WEIGHT: normal;FONT-SIZE: 12px; COLOR: #ffffff; FONT-FAMILY: Arial,Verdana,Comic Sans MS'>Create new folder</td>
	<tr>
	
	<td align=middle bgcolor='#ffffff'>
	<iframe frameborder=NO marginwidth=0 marginheight=0 src='iframe/create-folder.php?UserID=$SessionUserID&SectionID=$SectionID' width=343 height=26></iframe>
	</td>
	

	</table></div></LI>

	</UL>
	";
	}




echo "
<script type='text/javascript'>

var ProfilePhotoUploadMenuListOne = new FSMenu('ProfilePhotoUploadMenuListOne', true, 'display', 'block', 'none');


ProfilePhotoUploadMenuListOne.animations[ProfilePhotoUploadMenuListOne.animations.length] = FSMenu.animFade;
//ProfilePhotoUploadMenuListOne.animations[ProfilePhotoUploadMenuListOne.animations.length] = FSMenu.animSwipeDown;
//ProfilePhotoUploadMenuListOne.animations[ProfilePhotoUploadMenuListOne.animations.length] = FSMenu.animClipDown;

var arrow = null;
if (document.createElement && document.documentElement)
{
 arrow = document.createElement('span');
 arrow.appendChild(document.createTextNode('>'));
 // Feel free to replace the above two lines with these for a small arrow image...
 //arrow = document.createElement('img');
 //arrow.src = 'arrow.gif';
 //arrow.style.borderWidth = '0';
 arrow.className = 'subind';
 
 
 
 
 
}
addEvent(window, 'load', new Function('ProfilePhotoUploadMenuListOne.activateMenu(\"ProfilePhotoUploadMenuListOneRoot\", arrow)'));



</script>
";

// End Menus











	return $ProfilePhotoUploadCode;
	}
?>
