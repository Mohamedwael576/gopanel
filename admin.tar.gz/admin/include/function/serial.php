<?php
function Serial ($Service,$CategoryDisplayOrderBy,$CategoryDisplaySortOrder,$CategoryDisplayFilter,$CategoryDisplaySubCategories,$CategoryDisplaySubCategoriesLimit,$SectionDisplaySubSectionsLimit,$SectionDisplayCategoriesLimit,$SectionDisplayBulet)
{
	global $Prefix,$PDO;
	
	$LService=strtolower($Service);
	
	if ($CategoryDisplayOrderBy=="Alphabetic") {$EnCategorySortBy="EnCategory";}
	If ($CategoryDisplayOrderBy=="Alphabetic") {$ArCategorySortBy="BINARY ArCategory";}
	
	if ($CategoryDisplayOrderBy=="Sort")
	{
		$EnCategorySortBy="Sort";
		$ArCategorySortBy="Sort";
	}
	
	if ($CategoryDisplayOrderBy=="ID") 
	{
		$EnCategorySortBy="CategoryID";
		$ArCategorySortBy="CategoryID";
	}
	
	if (trim($CategoryDisplayFilter!=""))
	{
		$CategoryDisplayFilter=stripcslashes($CategoryDisplayFilter);
		
		$CategoryDisplayFilter="and ".$CategoryDisplayFilter;
	}

	// EnSerial						
	$Serial=0;
	$Sql = "select * from $Service"."Category where CategoryID>=1 $CategoryDisplayFilter order by SectionID ASC,$EnCategorySortBy $CategoryDisplaySortOrder";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{	
		$CategoryID=$Row['CategoryID'];
		$SectionID=$Row['SectionID'];
		
		if ($SectionID!=$LastSectionID)
		{
			$Serial=0;
		}
		
		
		$Serial++;
		$SqlQ = "UPDATE $Service"."Category set EnSerial='$Serial' where CategoryID='$CategoryID'";
		$ResultQ = $PDO->query($SqlQ);
		
		$LastSectionID=$SectionID;		
	}
	
	
	// ArSerial						
	$Serial=0;
	$Sql = "select * from $Service"."Category where CategoryID>=1 $CategoryDisplayFilter order by SectionID ASC,$ArCategorySortBy $CategoryDisplaySortOrder";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{	
		$CategoryID=$Row['CategoryID'];
		$SectionID=$Row['SectionID'];
		
		if ($SectionID!=$LastSectionID)
		{
			$Serial=0;
		}
		
		
		$Serial++;
		$SqlQ = "UPDATE $Service"."Category set ArSerial='$Serial' where CategoryID='$CategoryID'";
		$ResultQ = $PDO->query($SqlQ);
		
		$LastSectionID=$SectionID;		
	}
	
	
	
	
	
	// انشاء كود التصنيفات الفرعية من التصنيف الحالى و تسجيلة فى قاعدة البيانات نظام للكاش
	
	$Sql = "select * from Service where Service='$Service'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{   
	$Theme=$Row['Theme'];
	}
	
	$Sql = "select * from $Service"."Info where Theme='$Theme'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		$SEO=$Row['SEO'];
	}
	
	$Sql = "select * from $Prefix".$Service."Variable where Variable='LngSubCategories'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		{$LNG['EnSubCategories']}=$Row['EnValue'];
		{$LNG['ArSubCategories']}=$Row['ArValue'];		
	}
	
	
	if ($CategoryDisplaySubCategories==1)
	{

		
		if ($CategoryDisplaySubCategoriesLimit=="") {$CategoryDisplaySubCategoriesLimit=3;}
		
		
		// English Cache
		$SqlC = "select * from $Prefix".$Service."Category where CategoryID>=1";
		$ResultC = $PDO->query($SqlC);
		while ($RowC = $ResultC->fetch_assoc())
		{
			// English Cache
			$SqlQ = "select * from $Prefix".$Service."Category where SubFromCategoryID=$RowC[CategoryID] order by $EnCategorySortBy $CategoryDisplaySortOrder LIMIT $CategoryDisplaySubCategoriesLimit";
			$Q=0;
			$ResultQ = $PDO->query($SqlQ);
			foreach ($ResultQ as $RowQ)
			{
				$Q++;
				
				if ($SEO==1)
				{
					$EnListPageUrl="$LService-list-$RowQ['CategoryID']-1-en.html";
				}
				else
				{
					$EnListPageUrl="$ScriptUrl/index.php?Open=list.php&Lng=en&CategoryID=$RowQ['CategoryID']&Page=1";
				}
				
				
				if ($Q==1)
				{
					$EnSubCategoryCache="<br /><span class=SubCategories>{$LNG['EnSubCategories']}: <a class=SubCategories href='$EnListPageUrl'>{$RowQ['EnCategory']}</a>";
					

				}
				else
				{
					$EnSubCategoryCache.= ", <a class=SubCategories href='$EnListPageUrl'>{$RowQ['EnCategory']}</a>";
					

				}
				
				




				


			}



			// تحديث كاش التصنيفات الفرعية 
			$EnSubCategoryCache=addslashes($EnSubCategoryCache);
			$SqlQU = "update $Prefix".$Service."Category set EnSubCategoryCache='$EnSubCategoryCache' where CategoryID=$RowC[CategoryID]";
			$ResultQU = $PDO->query($SqlQU);

			unset ($EnSubCategoryCache);

			




			// Arabic Cache
			$SqlQ = "select * from $Prefix".$Service."Category where SubFromCategoryID=$RowC[CategoryID] order by $ArCategorySortBy $CategoryDisplaySortOrder LIMIT $CategoryDisplaySubCategoriesLimit";
			$Q=0;
			$ResultQ = $PDO->query($SqlQ);
			foreach ($ResultQ as $RowQ)
			{
				$Q++;
				
				if ($SEO==1)
				{
					$ArListPageUrl="$LService-list-$RowQ['CategoryID']-1-ar.html";
				}
				else
				{
					$ArListPageUrl="$ScriptUrl/index.php?Open=list.php&Lng=ar&CategoryID=$RowQ['CategoryID']&Page=1";
				}
				
				
				if ($Q==1)
				{
					$ArSubCategoryCache="<br /><span class=SubCategories>{$LNG['ArSubCategories']}: <a class=SubCategories href='$ArListPageUrl'>{$RowQ['ArCategory']}</a>";
				}
				else
				{
					$ArSubCategoryCache.= ", <a class=SubCategories href='$ArListPageUrl'>{$RowQ['ArCategory']}</a>";
				}
				
				




				


			}



			// تحديث كاش التصنيفات الفرعية 
			$ArSubCategoryCache=addslashes($ArSubCategoryCache);
			$SqlQU = "update $Prefix".$Service."Category set ArSubCategoryCache='$ArSubCategoryCache' where CategoryID=$RowC[CategoryID]";
			$ResultQU = $PDO->query($SqlQU);

			unset ($ArSubCategoryCache);
			
		}
		

	}

	
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	

			$Sql = "select * from $Service"."Section where SectionID>=1";
			$Result = SQL($Sql);
			foreach ($Result as $Row)
			{	
			
			
			
			


// SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS





					if ($SectionDisplaySubSectionsLimit=="") {$SectionDisplaySubSectionsLimit=3;}

						if ($SectionDisplayBulet==1)
						{
							$EnSubSectionBulet="<img src='module/$LService/image/section/bulet-sub-en.gif' > ";
							$ArSubSectionBulet="<img src='module/$LService/image/section/bulet-sub-ar.gif' > ";
						}


	

					// English
					$SqlS = "select * from $Prefix".$Service."Section where SubFromSectionID={$Row['SectionID']} order by EnSection ASC LIMIT $SectionDisplaySubSectionsLimit";
					$C=0;
					$ResultC = $PDO->query($SqlS);
					while ($RowS = $ResultC->fetch_assoc())
					{
						$C=$C+1;
						

						
						

						
						if ($SEO==0)
						{
						$CategoryPageUrl="$ScriptUrl/index.php?Open=$LService-category.php&Lng=$Lng&Service=$Service&SectionID=$RowS[SectionID]";
						}
						elseif ($SEO==1)
						{
						$CategoryPageUrl="$LService-category-$RowS[SectionID]-$Lng.html";
						}
						else
						{
						$CategoryPageUrl="$ScriptUrl/$Lng/$LService/category/$RowS[SectionID]";		
						}

						
						if ($C==1)
						{
						$EnSubSectionCache="<br />&nbsp;&nbsp;&nbsp;$EnSubSectionBulet <a href='$CategoryPageUrl'>$RowS['EnSection']</a>";
						}
						else
						{
						$EnSubSectionCache.= ", <a href='$CategoryPageUrl'>$RowS['EnSection']</a>";
						}

					}
					// تحديث كاش الاقسام الفرعية المترفعة من القسم الحالى
					$EnSubSectionCache=addslashes($EnSubSectionCache);
					$SqlCU = "update $Prefix".$Service."Section set EnSubSectionCache='$EnSubSectionCache' where SectionID={$Row['SectionID']}";
					$ResultCU = $PDO->query($SqlCU);

					unset ($EnSubSectionCache);

					

					// Arabic
					$SqlS = "select * from $Prefix".$Service."Section where SubFromSectionID={$Row['SectionID']} order by BINARY ArSection ASC LIMIT $SectionDisplaySubSectionsLimit";
					$C=0;
					$ResultC = $PDO->query($SqlS);
					while ($RowS = $ResultC->fetch_assoc())
					{
						$C=$C+1;
						

						
						
						if ($SEO==1)
						{
							$CategoryPageUrl="$LService-category-$RowS[SectionID]-ar.html";
						}
						else
						{
							$CategoryPageUrl="$ScriptUrl/index.php?Open=$LService-category.php&Lng=ar&SectionID=$RowS[SectionID]";
						}
						
						if ($C==1)
						{
						$ArSubSectionCache="<br />&nbsp;&nbsp;&nbsp;$ArSubSectionBulet <a href='$CategoryPageUrl'>$RowS['ArSection']</a>";
						}
						else
						{
						$ArSubSectionCache.= ", <a href='$CategoryPageUrl'>$RowS['EnSection']</a>";
						}

					}
					// تحديث كاش الاقسام الفرعية المترفعة من القسم الحالى
					$EnSubSectionCache=addslashes($EnSubSectionCache);
					$SqlCU = "update $Prefix".$Service."Section set ArSubSectionCache='$ArSubSectionCache' where SectionID={$Row['SectionID']}";
					$ResultCU = $PDO->query($SqlCU);

					unset ($ArSubSectionCache);
			
			
			

			// كاش التصنيفات الفرعية من القسم الحالى
					if ($SectionDisplayCategoriesLimit=="") {$SectionDisplayCategoriesLimit=3;}
					if ($SubFromCategoryID=="") {$SubFromCategoryID=0;}

					// English Cache					
					$SqlC = "select * from $Prefix".$Service."Category where SubFromCategoryID=0 and SectionID={$Row['SectionID']} $CategoryDisplayFilter order by $EnCategorySortBy $CategoryDisplaySortOrder LIMIT $SectionDisplayCategoriesLimit";
					$C=0;
					$ResultC = $PDO->query($SqlC);
					while ($RowC = $ResultC->fetch_assoc())
					{
					$C=$C+1;


						$EnCategory=$RowC['EnCategory'];
						$EnDescription=$RowC['EnDescription'];
						
		
											
						if ($SEO==1)
						{
						$EnListPageUrl="$LService-list-$RowC[CategoryID]-1-en.html";
						$EnShowPageUrl="$LService-show-$RowC[LastItemID]-en.html";
						}
						else
						{
						$EnListPageUrl="$ScriptUrl/index.php?Open=list.php&Lng=en&CategoryID=$RowC[CategoryID]&Page=1";
						$EnShowPageUrl="$ScriptUrl/index.php?Open=show.php&Lng=en&ID={$Row['LastItemID']}";
						}

						
			
					
							if ($C==1)
							{
							$EnCategoriesCache="<br /><a class=Categories href='$EnListPageUrl'>$EnCategory</a>";
							}
							else
							{
							$EnCategoriesCache.=", <a class=Categories href='$EnListPageUrl'>$EnCategory</a>";
							}
	

					}
					
					// تحديث كاش التصنيفات الفرعية من القسم الحالى
					$EnCategoriesCache=addslashes($EnCategoriesCache);
					$SqlCU = "update $Prefix".$Service."Section set EnCategoriesCache='$EnCategoriesCache' where SectionID={$Row['SectionID']}";
					$ResultCU = $PDO->query($SqlCU);

					unset ($EnCategoriesCache);
					
														
					// Arabic Cache					
					$SqlC = "select * from $Prefix".$Service."Category where SubFromCategoryID=0 and SectionID={$Row['SectionID']} $CategoryDisplayFilter order by $ArCategorySortBy $CategoryDisplaySortOrder LIMIT $SectionDisplayCategoriesLimit";
					$C=0;
					$ResultC = $PDO->query($SqlC);
					while ($RowC = $ResultC->fetch_assoc())
					{
					$C=$C+1;

						$ArCategory=$RowC['ArCategory'];
						$ArDescription=$RowC['ArDescription'];
						
		
											
						if ($SEO==1)
						{
						$ArListPageUrl="$LService-list-$RowC[CategoryID]-1-ar.html";
						$ArShowPageUrl="$LService-show-$RowC[LastItemID]-ar.html";
						}
						else
						{
						$ArListPageUrl="$ScriptUrl/index.php?Open=list.php&Lng=ar&CategoryID=$RowC[CategoryID]&Page=1";
						$ArShowPageUrl="$ScriptUrl/index.php?Open=show.php&Lng=ar&ID={$Row['LastItemID']}";
						}

				
							if ($C==1)
							{
							$ArCategoriesCache="<br /><a class=Categories href='$ArListPageUrl'>$ArCategory</a>";
							}
							else
							{
							$ArCategoriesCache.=", <a class=Categories href='$ArListPageUrl'>$ArCategory</a>";
							}
	

					}
					
					// تحديث كاش التصنيفات الفرعية من القسم الحالى
					$ArCategoriesCache=addslashes($ArCategoriesCache);
					$SqlCU = "update $Prefix".$Service."Section set ArCategoriesCache='$ArCategoriesCache' where SectionID={$Row['SectionID']}";
					$ResultCU = $PDO->query($SqlCU);

					unset ($ArCategoriesCache);

				


					
					
			}
	
	
}
?>
