<?php
// فنكشن تستخدم مع الملف
// install/index.php
// و مع ملفات اخرى فى الادمن
// الغرض منهت تركيب المتغيرات و تحديثها



	function InsertVariable ($Variable,$En,$Fr,$De,$It,$Es,$Ru,$Cn,$Ar,$Service,$Theme)
	{
	global $UpdateVariable,$ErrRepeatNo,$Prefix,$PDO;
	
		if ($Theme=="") {$Theme="All";}
	
		$VariableFound=0;
		$Sql = "select * from $Prefix".$Service."Variable where BINARY Variable='$Variable' and Theme='$Theme'";
		$Result = SQL($Sql);
		if (!$Result) {echo $mysqli->error;}
		foreach ($Result as $Row)
		{	
		$VariableID=$Row['VariableID'];
		$VariableFound=1;	
		}
		
		if ($VariableFound==0)
		{
		$Sql = "INSERT INTO $Prefix".$Service."Variable (Variable,En,Fr,De,It,Es,Ru,Cn,Ar,Theme) VALUES ('$Variable','$En','$Fr','$De','$It','$Es','$Ru','$Cn','$Ar','$Theme')";
		$Result = SQL($Sql);
		}
		else
		{
		
			if ($UpdateVariable==1)
			{
			$Sql = "UPDATE $Prefix".$Service."Variable set Variable='$Variable',En='$En',Fr='$Fr',De='$De',It='$It',Es='$Es',Ru='$Ru',Cn='$Cn',Ar='$Ar' where VariableID=$VariableID";
			$Result = SQL($Sql);			
			}
			else
			{
			$ErrRepeatNo=$ErrRepeatNo+1;
			echo "<span style='color:#FF0000'>$ErrRepeatNo - $Variable is repated in Service $Service please remove repated ...</span><HR>";
			}
		
		}
	
	}
	
	
	
	
	
	
	function SetupVariable ($XMLPath,$Service,$Theme,$SkipVariable="")
	{
		
		libxml_use_internal_errors(true);
		$XML = simpleXML_load_file($XMLPath); 
		if ($XML)
		{

			foreach($XML->children() as $Child)
			{
			$XMLValue=$Child->getName();
			$$XMLValue=$Child;
			




				if ($XMLValue=="Ar")
				{

					if (!stristr($SkipVariable,"|$Variable|"))
					{
						$X=InsertVariable ($Variable,$En,$Fr,$De,$It,$Es,$Ru,$Cn,$Ar,$Service,$Theme);
						
					
						
						$En="";
						$Fr="";
						$De="";
						$It="";
						$Es="";
						$Ru="";
						$Cn="";
						$Ar="";
					}
				
				}
				

			}
		}
		else
		{
		
			if (file_exists("$XMLPath"))
			{
			
				foreach (libxml_get_errors() as $error) 
				{
					echo "<img src='../theme/{$_SESSION['SessionAdminTheme']}/image/box-red.gif' > Failed to open $XMLPath [<span style='color:#FF0000'>Line: $error->line</span>]<br />";
				}
				libxml_clear_errors();
			
			}
			else
			{
			echo "<img src='../theme/{$_SESSION['SessionAdminTheme']}/image/box-red.gif' > Failed to open $XMLPath. [<span style='color:#FF0000'>File not found</span>]<br />";
			}
			

			
			exit;

		}
	}

?>