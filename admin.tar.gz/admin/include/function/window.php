<?php

	// تحويل النص إلى Unicode
	function Window($WindowURL,$WindowTitle,$WindowWidth,$WindowHeight,$WindowTheme,$WindowAutoOpen)
	{
	$ThemePath="../media/image/window/$WindowTheme";
	
	$WindowCode="
	<script type='text/javascript'>
	var dragapproved=false
	var minrestore=0
	var initialwidth,initialheight
	var ie5=document.all&&document.getElementById
	var ns6=document.getElementById&&!document.all

		function iecompattest()
		{
		return (!window.opera && document.compatMode && document.compatMode!=\"BackCompat\")? document.documentElement : document.body
		}

		function drag_drop(e)
		{
			if (ie5&&dragapproved&&event.button==1)
			{
			document.getElementById(\"dwindow\").style.left=tempx+event.clientX-offsetx+\"px\"
			document.getElementById(\"dwindow\").style.top=tempy+event.clientY-offsety+\"px\"
			}
			else if (ns6&&dragapproved)
			{
			document.getElementById(\"dwindow\").style.left=tempx+e.clientX-offsetx+\"px\"
			document.getElementById(\"dwindow\").style.top=tempy+e.clientY-offsety+\"px\"
			}
		}

		function initializedrag(e)
		{
		offsetx=ie5? event.clientX : e.clientX
		offsety=ie5? event.clientY : e.clientY
		//document.getElementById(\"dwindowcontent\").style.display=\"none\" //extra
		tempx=parseInt(document.getElementById(\"dwindow\").style.left)
		tempy=parseInt(document.getElementById(\"dwindow\").style.top)

		dragapproved=true
		document.getElementById(\"dwindow\").onmousemove=drag_drop
		}

		function loadwindow(url,width,height)
		{
			if (!ie5&&!ns6)
			window.open(url,\"\",\"width=width,height=height,scrollbars=1\")
			else
			{
			document.getElementById(\"dwindow\").style.display=''
			document.getElementById(\"dwindow\").style.width=initialwidth=width+\"px\"
			document.getElementById(\"dwindow\").style.height=initialheight=height+\"px\"
			document.getElementById(\"dwindow\").style.left=\"30px\"
			document.getElementById(\"dwindow\").style.top=ns6? window.pageYOffset*1+30+\"px\" : iecompattest().scrollTop*1+30+\"px\"
			document.getElementById(\"cframe\").src=url
			}
		}

		function maximize()
		{
			if (minrestore==0)
			{
			minrestore=1 //maximize window
			document.getElementById(\"maxname\").setAttribute(\"src\",\"$ThemePath/restore.gif\")
			document.getElementById(\"dwindow\").style.width=ns6? window.innerWidth-20+\"px\" : iecompattest().clientWidth+\"px\"
			document.getElementById(\"dwindow\").style.height=ns6? window.innerHeight-20+\"px\" : iecompattest().clientHeight+\"px\"
			}
			else
			{
			minrestore=0 //restore window
			document.getElementById(\"maxname\").setAttribute(\"src\",\"$ThemePath/max.gif\")
			document.getElementById(\"dwindow\").style.width=initialwidth
			document.getElementById(\"dwindow\").style.height=initialheight
			}
			
			document.getElementById(\"dwindow\").style.left=ns6? window.pageXOffset+\"px\" : iecompattest().scrollLeft+\"px\"
			document.getElementById(\"dwindow\").style.top=ns6? window.pageYOffset+\"px\" : iecompattest().scrollTop+\"px\"
		}

		function closeit()
		{
		document.getElementById(\"dwindow\").style.display=\"none\"
		}
		
		function stopdrag()
		{
		dragapproved=false;
		document.getElementById(\"dwindow\").onmousemove=null;
		//document.getElementById(\"dwindowcontent\").style.display=\"\" //extra
		}

	</script>
	
	<style>
	.WindowTitle {FONT-WEIGHT: bold;FONT-SIZE: 14px; COLOR: #efefef; FONT-FAMILY: Times New Roman}
	</style>
	
		<div id=\"dwindow\" style=\"position:absolute;background-color:#EBEBEB;cursor:pointer;left:0px;top:0px;display:none\" onMousedown=\"initializedrag(event)\" onMouseup=\"stopdrag()\" onSelectStart=\"return false\">
		<table  cellPadding=0 cellSpacing=0 width='100%'><td background='$ThemePath/left.gif' width=3 height=30><img src='$ThemePath/left.gif'></td><td background='$ThemePath/bar.gif' width=21 align=middle><img src='$ThemePath/logo.gif' hspace=1></td><td background='$ThemePath/bar.gif' width=98% class=WindowTitle>&nbsp;$WindowTitle</td><td background='$ThemePath/bar.gif' width=21 align=middle><img src='$ThemePath/max.gif'  hspace=1 id=\"maxname\" onClick=\"maximize()\"></td><td background='$ThemePath/bar.gif' align=middle width=21><img src='$ThemePath/close.gif' onmouseover=\"this.src='$ThemePath/close-on.gif';\" onmouseout=\"this.src='$ThemePath/close.gif';\" hspace=1 onClick='closeit()'></td><td background='$ThemePath/right.gif' width=3><img src='$ThemePath/right.gif'></td></table>
		<div id=\"dwindowcontent\" style='background:#fff; height:100%;border-left:1px solid #F2F2EF;border-top:1px solid #F2F2EF;border-bottom:1px solid #F2F2EF;border-right:1px solid #F2F2EF;'>
		<iframe id=\"cframe\" src=\"\" width='100%' height=100% frameborder=NO marginwidth=0 marginheight=0></iframe>
		</div>
		</div>
		
	";

		if ($WindowAutoOpen==1)
		{
		$WindowCode.="	
		<script type='text/javascript'>
		if (ns6) window.onload=new Function('loadwindow(\"$WindowURL\",$WindowWidth,$WindowHeight)')
		else
		loadwindow(\"$WindowURL\",$WindowWidth,$WindowHeight)
		</script>
		";
		
		}
	

	return $WindowCode;
	}
?>
