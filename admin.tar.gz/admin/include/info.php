<?php

	// Get value for $SectionDisplayOption,$CategoryDisplayOption,$ListDisplayOption,$ShowDisplayOption
	// Also Get All ServiceInfo Table
	libxml_use_internal_errors(true);
	$XML = @simpleXML_load_file("../module/$LService/theme/$Theme/xml/display.xml");
	if ($XML)
	{
		foreach($XML->children() as $Child)
		{
		$XMLValue=$Child->getName();
		unset ($$XMLValue);
		$$XMLValue=$Child;
		}
	}
	else
	{
	
	
			if (file_exists("../module/$LService/theme/$Theme/xml/display.xml"))
			{
			
				foreach (libxml_get_errors() as $error) 
				{
					echo "<img src='theme/{$_SESSION['SessionAdminTheme']}/image/box-red.gif' > ||Failed to open ../module/$LService/theme/$Theme/xml/display.xml <span style='color:#FF0000'>[Line: $error->line]</span><br />";
				}
				libxml_clear_errors();
			
			}
			else
			{
			echo "<img src='theme/{$_SESSION['SessionAdminTheme']}/image/box-red.gif' > || Failed to open ../module/$LService/theme/$Theme/xml/display.xml. [<span style='color:#FF0000'>File not found</span>]<br />";
			}
			
			exit;	
	
	}
	


	$Sql = "INSERT INTO $Prefix".$Service."Info (Theme,PageNo,PageBarNo,ShowWidth,ShowHeight,NewsFlashMax,RelatedNewsMax,MoreNewsMax,ArchivedVotesMax,ActiveValue,ActiveFollow,ActiveLinkID,SEO,WODesign,MOT,LinkBarDesign,LinkBarLogin,ActiveSearchHistory,ActiveSearchBar,ActiveLetterBar,ActiveLinkBar,ActiveStatisticBar,ActiveJumpBar,UserAccess,ColumnOption,WatermarkOption,PermissionOption,SectionDisplayOption,CategoryDisplayOption,ListDisplayOption,ShowDisplayOption,RegisterDisplayOption,UsercpDisplayOption,SubmitDisplayOption,ContactDisplayOption,DesignSystem,BkgAlign,LeftBlockWidth,RightBlockWidth,MiddleBlockWidth,LeftBlockAlign,RightBlockAlign,MiddleBlockAlign,LeftBlockValign,RightBlockValign,MiddleBlockValign,LeftAttribute,RightAttribute,MiddleAttribute,InsideMiddleWidth,BR,BannerSql,PollID,ActiveMethod) VALUES ('$ThemeFolder','$PageNo','$PageBarNo','$ShowWidth','$ShowHeight','$NewsFlashMax','$RelatedNewsMax','$MoreNewsMax','$ArchivedVotesMax','$ActiveValue','$ActiveFollow','$ActiveLinkID','$SEO','$WODesign','$MOT','$LinkBarDesign','$LinkBarLogin','$ActiveSearchHistory','$ActiveSearchBar','$ActiveLetterBar','$ActiveLinkBar','$ActiveStatisticBar','$ActiveJumpBar','$UserAccess','$ColumnOption','$WatermarkOption','$PermissionOption','$SectionDisplayOption','$CategoryDisplayOption','$ListDisplayOption','$ShowDisplayOption','$RegisterDisplayOption','$UsercpDisplayOption','$SubmitDisplayOption','$ContactDisplayOption','$DesignSystem','$BkgAlign','$LeftBlockWidth','$RightBlockWidth','$MiddleBlockWidth','$LeftBlockAlign','$RightBlockAlign','$MiddleBlockAlign','$LeftBlockValign','$RightBlockValign','$MiddleBlockValign','$LeftAttribute','$RightAttribute','$MiddleAttribute','$InsideMiddleWidth','$BR','$BannerSql','$PollID','$ActiveMethod')";
	$Result = SQL($Sql);
	if (!$Result)
	{
	echo "<li><span style='color:#FF0000'>Can not insert Info for $Service please check file admin/include/info.php.<br /></span></li>";
	exit;
	}
	
?>