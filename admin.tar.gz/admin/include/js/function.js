var CurrentFileName=''; 
var ControlID=0; 
function Load(Url,CurrentControlID=0)
{

	if (ControlID!=0)
	{
		var LastMenuID='C'+ControlID;
		
		if (document.getElementById(LastMenuID))
		{
		document.getElementById(LastMenuID).classList.remove('MenuActive');
		document.getElementById(LastMenuID).classList.add('Menu');
		}
	}

	if (CurrentControlID!=0)
	{
		var MenuID='C'+CurrentControlID;
		if (document.getElementById(MenuID))
		{
		document.getElementById(MenuID).classList.remove('Menu');
		document.getElementById(MenuID).classList.add('MenuActive');
		
		var AccessMenuID = document.getElementById(MenuID);
		AccessMenuID.scrollIntoView({behavior: 'smooth'}, true);
		
		}
	}
	
	// document.getElementById("MyElement").classList.add('MyClass');
	// 
	// if ( document.getElementById("MyElement").classList.contains('MyClass') )
	// document.getElementById("MyElement").classList.toggle('MyClass');



	CurrentFileName=Url;
	ControlID=CurrentControlID;

	http=Ajax();http.abort();
	http.open("POST",Url,true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = LoadInfo;
	http.send('');
}

function LoadInfo()
{
	if (http.readyState == 1)
	{
	document.getElementById('Load').innerHTML = '<img src=\'image/ajax/1.gif\' border=\'0\'>';
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;
		document.getElementById('Load').innerHTML = response;
	
		if (CurrentFileName.match("timezone-fpm.php"))
		{
		CurrentTimezone();
		}
	
		if (CurrentFileName.match("responder.php"))
		{
		
			$(function() {
				  $('#StartDate').datepicker({dateFormat: 'dd/mm/yy'});
				  $('#EndDate').datepicker({dateFormat: 'dd/mm/yy'});
			});
		
		}
		
		if (CurrentFileName.match("customer.php"))
		{
		
			$("[data-fancybox]").fancybox({
				iframe : {
					css : {
						width : '500px',
						height : '400px'
					}
				}
			});
		
		}
		
		
		if (CurrentFileName.match("site.php") || CurrentFileName.match("multiple.php") || CurrentFileName.match("expiration.php") || CurrentFileName.match("vps.php"))
		{
			$(function() {
				$('#ExpiresOn').datepicker({dateFormat: 'dd/mm/yy'});
			});
		}
		
		if (CurrentFileName.match("sql.php"))
		{
		
			$(document).ready( function() 
			{
			
				var WWWPath=document.forms['Form'].WWWPath.value;

				$( '#container' ).html( '<ul class="filetree start"><li class="wait">' + 'Generating Tree...' + '<li></ul>' );	
				getfilelist( $('#container') , WWWPath);
				function getfilelist(cont,root)
				{
				
					$( cont ).addClass( 'wait' );
						
					$.post('tree.php', { dir: root }, function(data) 
					{
				
						$( cont ).find( '.start' ).html('');
						$( cont ).removeClass( 'wait' ).append( data );
						if( 'Sample' == root ) 
							$( cont ).find('UL:hidden').show();
						else 
							$( cont ).find('UL:hidden').slideDown({ duration: 500, easing: null });
						
					});
				}
				
				$( '#container' ).on('click', 'LI A', function() 
				{
					var entry = $(this).parent();
					
					if( entry.hasClass('folder') ) 
					{
						if( entry.hasClass('collapsed') ) 
						{
							entry.find('UL').remove();
							getfilelist( entry, escape( $(this).attr('rel') ));
							entry.removeClass('collapsed').addClass('expanded');
						}
						else 
						{
							entry.find('UL').slideUp({ duration: 500, easing: null });
							entry.removeClass('expanded').addClass('collapsed');
						}
						
					}
					else
					{
						
						if (CurrentFileName.match("sql.php"))
						{
						document.forms['Form'].Database.value=$(this).attr('rel');
						}
						
					}
					
				return false;
				});
				
			});
		
		
		}
		
		if (CurrentFileName.match("directory.php") || CurrentFileName.match("github.php") || CurrentFileName.match("script.php"))
		{
			SetDirectory();
		}
		
		if (CurrentFileName.match("spf.php"))
		{
		SPF();
		}

		if (CurrentFileName.match("username.php"))
		{
		GetUsername();
		}

		if (CurrentFileName.match("document-root.php"))
		{
		GetDocumentRoot();
		}
		
		if (CurrentFileName.match("ftp.php"))
		{
		FTPDirectory();
		}

		if (CurrentFileName.match("mail-default.php"))
		{
		DefaultEmail();
		}
		
		if (CurrentFileName.match("RestartHTTP"))
		{		
		setTimeout(function(){ Load('http.php?Action=StatusHTTP&ControlID='+ControlID,ControlID); }, 10000);
		}
		
		if (CurrentFileName.match("RestoreApacheConfiguration"))
		{
		setTimeout(function(){ Load('apache.php?ControlID='+ControlID,ControlID); }, 10000);
		}

		if (CurrentFileName.match("RestoreNGINXConfiguration"))
		{
		setTimeout(function(){ Load('nginx.php?ControlID='+ControlID,ControlID); }, 10000);
		}

		if (CurrentFileName.match("RestorePHPConfiguration"))
		{
		setTimeout(function(){ Load('php.php?ControlID='+ControlID,ControlID); }, 10000);
		}
		
		if (CurrentFileName.match("Destination=URL"))
		{
		setTimeout(function(){ Load('history.php',0); }, 10000);
		}
		
		if (CurrentFileName.match("template.php"))
		{		
			editAreaLoader.init({
				id: "DefaultWebsitePageCode"
				,font_size: "14"
				,start_highlight: true	
				,allow_toggle: false
				,language: "en"
				,toolbar: "search, go_to_line, |, undo, redo, |, highlight, reset_highlight,fullscreen"
				,syntax: "html"	
			});
			
			editAreaLoader.init({
				id: "AccountSuspendedCode"	
				,font_size: "14"
				,start_highlight: true	
				,allow_toggle: false
				,language: "en"
				,toolbar: "search, go_to_line, |, undo, redo, |, highlight, reset_highlight,fullscreen"
				,syntax: "html"	
			});

			editAreaLoader.init({
				id: "DiskQuotaExceededCode"	
				,font_size: "14"
				,start_highlight: true	
				,allow_toggle: false
				,language: "en"
				,toolbar: "search, go_to_line, |, undo, redo, |, highlight, reset_highlight,fullscreen"
				,syntax: "html"	
			});
			
			editAreaLoader.init({
				id: "BandwidthLimitExceededCode"	
				,font_size: "14"
				,start_highlight: true	
				,allow_toggle: false
				,language: "en"
				,toolbar: "search, go_to_line, |, undo, redo, |, highlight, reset_highlight,fullscreen"
				,syntax: "html"	
			});
			
			editAreaLoader.init({
				id: "AccountUnpublishedCode"	
				,font_size: "14"
				,start_highlight: true	
				,allow_toggle: false
				,language: "en"
				,toolbar: "search, go_to_line, |, undo, redo, |, highlight, reset_highlight,fullscreen"
				,syntax: "html"	
			});

			editAreaLoader.init({
				id: "HostingExpiredCode"	
				,font_size: "14"
				,start_highlight: true	
				,allow_toggle: false
				,language: "en"
				,toolbar: "search, go_to_line, |, undo, redo, |, highlight, reset_highlight,fullscreen"
				,syntax: "html"	
			});

		}
		
		if (CurrentFileName.match("update.php"))
		{		
		location.reload();
		}

		if (CurrentFileName.match("logout.php"))
		{		
		window.location="index.php";
		}
		
		if (CurrentFileName.match("mail.php") || CurrentFileName.match("mails.php") || CurrentFileName.match("password.php") || CurrentFileName.match("site.php") || CurrentFileName.match("multiple.php") || CurrentFileName.match("root.php") || CurrentFileName.match("mysql.php") || CurrentFileName.match("copydb.php") || CurrentFileName.match("encoder.php") || CurrentFileName.match("sql.php") || CurrentFileName.match("mysql-reset.php") || CurrentFileName.match("directory.php"))
		{	

			var myInput = document.getElementById("Password");
			var letter = document.getElementById("letter");
			var capital = document.getElementById("capital");
			var number = document.getElementById("number");
			var length = document.getElementById("length");

			myInput.onfocus = function() 
			{
				document.getElementById("message").style.display = "block";
			}

			myInput.onblur = function() 
			{
				document.getElementById("message").style.display = "none";
			}

			// When the user starts to type something inside the password field
			myInput.onkeyup = function() 
			{
				// Validate lowercase letters
				var lowerCaseLetters = /[a-z]/g;
				if(myInput.value.match(lowerCaseLetters)) 
				{  
				letter.classList.remove("invalid");
				letter.classList.add("valid");
				} 
				else 
				{
				letter.classList.remove("valid");
				letter.classList.add("invalid");
				}
			  
				// Validate capital letters
				var upperCaseLetters = /[A-Z]/g;
				if(myInput.value.match(upperCaseLetters)) 
				{  
				capital.classList.remove("invalid");
				capital.classList.add("valid");
				} 
				else 
				{
				capital.classList.remove("valid");
				capital.classList.add("invalid");
				}

				// Validate numbers
				var numbers = /[0-9]/g;
				if(myInput.value.match(numbers)) 
				{  
				number.classList.remove("invalid");
				number.classList.add("valid");
				} 
				else 
				{
				number.classList.remove("valid");
				number.classList.add("invalid");
				}

				// Validate length
				if(myInput.value.length >= 8) 
				{
				length.classList.remove("invalid");
				length.classList.add("valid");
				} 
				else
				{
				length.classList.remove("valid");
				length.classList.add("invalid");
				}
			}

		}
		
		if (CurrentFileName.match("mysql.php"))
		{	

			var InputName = document.getElementById('Name');
			var FixedName = document.getElementById('FixedName').value;

			InputName.addEventListener("keydown", function() {
			  var OldName = this.value;
			  var FieldName = this;
			  
			  setTimeout(function () {
				if(FieldName.value.indexOf(FixedName) !== 0) {
					FieldName.value = OldName;
				} 
			}, 1);
			});		


			var InputUser = document.getElementById('User');
			var FixedUser = document.getElementById('FixedUser').value;

			InputUser.addEventListener("keydown", function() {
			  var OldUser = this.value;
			  var FieldUser = this;
			  
			  setTimeout(function () {
				if(FieldUser.value.indexOf(FixedUser) !== 0) {
					FieldUser.value = OldUser;
				} 
			}, 1);
			});		



			
			

			
			
		
		}
		
		if (CurrentFileName.match("reboot.php"))
		{	
			
			var TimeStamp=document.getElementById('TimeStamp').value;
			

			var x = setInterval(function() 
			{
				TimeStamp++;
			
				var RebootStamp=document.getElementById('RebootStamp').value;
			
				var distance = RebootStamp - TimeStamp;

				// Time calculations for days, hours, minutes and seconds
				var hours = Math.floor(distance / 3600);
				var minutes = Math.floor((distance / 60)%60);
				var seconds = Math.floor(distance%60);

				document.getElementById('Countdown').innerHTML = hours + ':' + minutes + ':' + seconds;

			}, 1000);

		}
	
	}
}

function HandelPost()
{

	if (http.readyState == 4)
	{
		var response = http.responseText;
		document.getElementById('Load').innerHTML = response;
	}
}

function Search(Tag)
{

	if (Tag=="tr")
	{
	var SearchRegExp = new RegExp(document.getElementById('SearchFor').value,"i");

	atags = document.getElementsByTagName('tr');
	}
	else
	{
	var SearchRegExp = new RegExp(document.getElementById('MenuSearch').value,"i");

	atags = document.getElementsByTagName('div');
	}
	
	for(i=0;i<atags.length;i++) 
	{
	
		if(atags[i].getAttribute('divid') == 'Find')
		{
			var str=atags[i].getAttribute('find');

			if(str.search(SearchRegExp) >= 0)
			{
				atags[i].style.display='';
			}
			else
			{
				atags[i].style.display='none';
			}
		}
		
	}
}

function SearchPost(FileName)
{
var SearchFor = document.getElementById('SearchFor').value;

Load (FileName+'?SearchFor='+SearchFor+'&ControlID='+ControlID);

return false;
}

function Radio (Name)
{
	var radios = document.getElementsByName(Name);

	for (var i = 0, length = radios.length; i < length; i++)
	{
		if (radios[i].checked)
		{
		return (radios[i].value);

		break;
		}
	}
}

function IsEmpty(str)
{
	var i;
	var len;
	if( str == null )
	return true;

	len = str.length;

	for( var i=0; i<len; i++ )
	{
	if( str.charAt(i) != ' ')
	return false;
	}
	
	return true;
}

var ApacheID='';
function Apache(Command,Value,ApacheInpuID)
{
	ApacheID=ApacheInpuID;

	http=Ajax();http.abort();
	http.open("POST", "ajax/apache.php?Lng=$Lng&Command="+Command+"&Value="+Value,true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = ApacheLoad;
	http.send('');
}

function ApacheLoad()
{

	if (http.readyState == 1)
	{

	}

	if (http.readyState == 4)
	{
		var response = http.responseText;

		if (response.match('Service Unavailable'))
		{
		alert ('Service Unavailable');
		}
		else if (response.match('!'))
		{
		alert (response);
		}
		else
		{
		document.getElementById(ApacheID).value=response;
		}
	}
}



var NGINXID='';
function NGINX(Command,Value,NGINXInpuID)
{
	NGINXID=NGINXInpuID;

	http=Ajax();http.abort();
	http.open("POST", "ajax/nginx.php?Lng=$Lng&Command="+Command+"&Value="+Value,true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = NGINXLoad;
	http.send('');
}

function NGINXLoad()
{

	if (http.readyState == 1)
	{

	}

	if (http.readyState == 4)
	{
		var response = http.responseText;

		if (response.match('Service Unavailable'))
		{
		alert ('Service Unavailable');
		}
		else if (response.match('!'))
		{
		alert (response);
		}
		else
		{
		document.getElementById(NGINXID).value=response;
		}
	}
}

var PHPID='';
function PHP(Command,Value,PHPInputID)
{
PHPID=PHPInputID;

http=Ajax();http.abort();
http.open("POST", "ajax/php.php?Lng=$Lng&Command="+Command+"&Value="+Value,true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = PHPLoad;
http.send('');
}

function PHPLoad()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;
	
		if (response.match('!'))
		{
		alert (response);
		}
		else
		{
		document.getElementById(PHPID).value=response;
		}
	}
}


var ReturnID='';
function Resellerclub(SiteID,Value,InputID)
{
ReturnID=InputID;

http=Ajax();http.abort();
http.open("POST", "ajax/resellerclub.php?Lng=$Lng&SiteID="+SiteID+"&Value="+Value+"&ID="+InputID,true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = ResellerclubLoad;
http.send('');
}

function ResellerclubLoad()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;
	
		if (response.match('!'))
		{
		alert (response);
		}
		else
		{
		document.getElementById(ReturnID).value=response;
		}
	}
}


var ReturnID='';
function Cloudflare(SiteID,Value,InputID)
{
ReturnID=InputID;

http=Ajax();http.abort();
http.open("POST", "ajax/cloudflare.php?Lng=$Lng&SiteID="+SiteID+"&Value="+Value+"&ID="+InputID,true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = CloudflareLoad;
http.send('');
}

function CloudflareLoad()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;
	
		if (response.match('!'))
		{
		alert (response);
		}
		else
		{
		document.getElementById(ReturnID).value=response;
		}
	}
}


var ReturnID='';
function OpenBasedir(SiteID,Value,InputID)
{
ReturnID=InputID;

http=Ajax();http.abort();
http.open("POST", "ajax/openbasedir.php?Lng=$Lng&SiteID="+SiteID+"&Value="+Value+"&ID="+InputID,true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = OpenBasedirLoad;
http.send('');
}

function OpenBasedirLoad()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;
	
		if (response.match('!'))
		{
		alert (response);
		}
		else
		{
		document.getElementById(ReturnID).value=response;
		}
	}
}






var ReturnModifyID='';
function Modify(SiteID,Value,InputID)
{
ReturnModifyID=InputID;

http=Ajax();http.abort();
http.open("POST", "ajax/modify.php?Lng=$Lng&SiteID="+SiteID+"&Value="+Value+"&ID="+InputID,true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = ModifyLoad;
http.send('');
}

function ModifyLoad()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;
	
		if (response.match('!'))
		{
		alert (response);
		}
		else
		{
		document.getElementById(ReturnModifyID).value=response;
		}
	}
}










var IMAPID='';
function IMAP(IMAPInputID,Value)
{
IMAPID=IMAPInputID;

http=Ajax();http.abort();
http.open("POST", "ajax/imap.php?Lng=$Lng&IMAPID="+IMAPID+"&Value="+Value,true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = IMAPLoad;
http.send('');
}

function IMAPLoad()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;

	
		if (response.match('!'))
		{
		alert (response);
		}
		else
		{
			
			document.getElementById(IMAPID).value=response;
			
			
		}
	}
}



var SMTPID='';
function SMTP(SMTPInputID,Value)
{
SMTPID=SMTPInputID;

http=Ajax();http.abort();
http.open("POST", "ajax/smtp.php?Lng=$Lng&SMTPID="+SMTPID+"&Value="+Value,true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = SMTPLoad;
http.send('');
}

function SMTPLoad()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
		var response = http.responseText;

	
		if (response.match('!'))
		{
		alert (response);
		}
		else
		{
			
			document.getElementById(SMTPID).value=response;
			
			
		}
	}
}




function ChangeRootPassword()
{	
	if(IsEmpty(document.forms['Form'].Password.value))
	{
	alert('Please type your new password');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}

	if (document.forms['Form'].Password.value!=document.forms['Form'].VerifyPassword.value)
	{
	alert('Your password entries did not match');
	document.forms['Form'].Password.value='';
	document.forms['Form'].VerifyPassword.value='';
	document.forms['Form'].Password.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
	
	http=Ajax();http.abort();
	http.open("POST", "root.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Password='+Password+'&ControlID='+ControlID);
	
	return false;
	
}




function ServerTime()
{

	var Timezone = document.forms['Form'].Timezone.value;

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('timezone.php?Timezone='+Timezone+'&ControlID='+ControlID,ControlID);
	
	return false;


}

function WebsiteTime()
{

	var Timezone = document.forms['Form'].Timezone.value;
	var Domain = document.forms['Form'].Domain.value;

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('timezone-fpm.php?Domain='+Domain+'&Timezone='+Timezone+'&ControlID='+ControlID,ControlID);
	
	return false;


}

function ChangeHostname()
{

	if(IsEmpty(document.forms['Form'].Hostname.value))
	{
	alert('Please Enter hostname');
	document.forms['Form'].Hostname.focus();
	return false;
	}
	
	var Hostname = document.forms['Form'].Hostname.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Hostname))
	{
	alert('Incorrect Server Hostname');
	document.forms['Form'].Hostname.focus();
	return false;
	}
	
	if(IsEmpty(document.forms['Form'].IMAPHostname.value))
	{
		document.forms['Form'].IMAPHostname.value=document.forms['Form'].Hostname.value;
	}
	
	var IMAPHostname = document.forms['Form'].IMAPHostname.value;
	if (!Filter.test(IMAPHostname))
	{
	alert('Incorrect IMAP Hostname');
	document.forms['Form'].IMAPHostname.focus();
	return false;
	}
	
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('hostname.php?Hostname='+Hostname+'&IMAPHostname='+IMAPHostname+'&ControlID='+ControlID,ControlID);
	
	return false;

}

function Resolver()
{

	var PrimaryIP = document.forms['Form'].PrimaryIP.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(PrimaryIP))
	{
	alert('You have entered an invalid IP address');
	document.forms['Form'].PrimaryIP.focus();
	return false;
	}
	
	var SecondaryIP = document.forms['Form'].SecondaryIP.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(SecondaryIP))
	{
	alert('You have entered an invalid IP address');
	document.forms['Form'].SecondaryIP.focus();
	return false;
	}

	if(!IsEmpty(document.forms['Form'].TertiaryIP.value))
	{
	
		var X = document.forms['Form'].TertiaryIP.value;
		var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
		if (!Filter.test(X))
		{
		alert('You have entered an invalid IP address');
		document.forms['Form'].TertiaryIP.focus();
		return false;
		}
	
	}
	
	if(!IsEmpty(document.forms['Form'].QuaternaryIP.value))
	{
	
		var X = document.forms['Form'].QuaternaryIP.value;
		var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
		if (!Filter.test(X))
		{
		alert('You have entered an invalid IP address');
		document.forms['Form'].QuaternaryIP.focus();
		return false;
		}
	
	}
	
	var TertiaryIP = document.forms['Form'].TertiaryIP.value;
	var QuaternaryIP = document.forms['Form'].QuaternaryIP.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('resolver.php?PrimaryIP='+PrimaryIP+'&SecondaryIP='+SecondaryIP+'&TertiaryIP='+TertiaryIP+'&QuaternaryIP='+QuaternaryIP+'&ControlID='+ControlID,ControlID);
	
	return false;
	
			
}

function Skeleton()
{

	if(IsEmpty(document.forms['Form'].Password.value))
	{
	alert('Please type your new password');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
		
	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
		
	http=Ajax();http.abort();
	http.open("POST", "skeleton.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Password='+Password+'&ControlID='+ControlID);
	
	return false;
	
}

function Alias()
{

	var AliasDomain = document.forms['Form'].AliasDomain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(AliasDomain))
	{
	alert('Incorrect Alias Domain');
	document.forms['Form'].AliasDomain.focus();
	return false;
	}

	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
		
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('alias.php?Domain='+Domain+'&AliasDomain='+AliasDomain+'&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function Addon()
{

	var AddonDomain = document.forms['Form'].AddonDomain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(AddonDomain))
	{
	alert('Incorrect Addon Domain');
	document.forms['Form'].AddonDomain.focus();
	return false;
	}
	
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
	
	http=Ajax();http.abort();
	http.open("POST", "addon.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&AddonDomain='+AddonDomain+'&Password='+Password+'&ControlID='+ControlID);
	
	return false;
	
}

function CurrentVersion()
{	
http=Ajax();http.abort();
http.open('POST', 'ajax/multiphp.php?Lng=en&Domain='+document.getElementById('Domain').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleCurrentVersion;
http.send('');
}

function HandleCurrentVersion()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	document.getElementById('DivPHPVersion').innerHTML = 'PHP Version<br>'+response;
	}
}


function MultiPHP()
{


	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	var PHPVersion=Radio('PHPVersion');
	
	if(IsEmpty(PHPVersion))
	{
	alert('Select PHP version.');
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('multiphp.php?Domain='+Domain+'&PHPVersion='+PHPVersion+'&ControlID='+ControlID,ControlID);
	
	return false;
	

}




function GoogleAuth()
{

	var AuthUser = document.forms['Form'].AuthUser.value;
	var AuthSecret = document.forms['Form'].AuthSecret.value;
	var Code = document.forms['Form'].Code.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('auth.php?AuthUser='+AuthUser+'&AuthSecret='+AuthSecret+'&Code='+Code+'&ControlID='+ControlID,ControlID);
	
	return false;
	

}






function CurrentTimezone()
{	
http=Ajax();http.abort();
http.open('POST', 'ajax/timezone-fpm.php?Lng=en&Domain='+document.getElementById('Domain').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleCurrentTimezone;
http.send('');
}

function HandleCurrentTimezone()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	
	var ResponseArray = response.split('|');
			
	document.getElementById('Timezone').value = ResponseArray[0];
	document.getElementById('DivCurrentTime').innerHTML = ResponseArray[1];
	}
}

function Reseller()
{

	var Username = document.forms['Form'].Username.value;
	var Filter  = /^\w+$/;	
	if (!Filter.test(Username))
	{
	alert('Username must contain only letters, numbers and underscores');
	document.forms['Form'].Username.focus();
	return false;
	}
	
	var Edit = document.forms['Form'].Edit.value;
	var Password = document.forms['Form'].Password.value;
	if (Edit!=1 || !IsEmpty(Password)) 
	{
		var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
		if (!Filter.test(Password))
		{
		alert('Password must contain only letters, numbers and underscores');
		document.forms['Form'].Password.focus();
		return false;
		}
	}
	
	var Email = document.forms['Form'].Email.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(Email))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].Email.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var ResellerDiskSpace = document.forms['Form'].ResellerDiskSpace.value;
	var ResellerAccounts = document.forms['Form'].ResellerAccounts.value;
	var UserID = document.forms['Form'].UserID.value;

	var SubReseller='0';
	if (document.forms['Form'].SubReseller)
	{
		if (document.forms['Form'].SubReseller.checked==true)
		{
		SubReseller='1';
		}
	}
	
	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
	
	http=Ajax();http.abort();
	http.open("POST", "reseller.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Username='+Username+'&Password='+Password+'&Email='+Email+'&ResellerDiskSpace='+ResellerDiskSpace+'&ResellerAccounts='+ResellerAccounts+'&SubReseller='+SubReseller+'&UserID='+UserID+'&Edit='+Edit);
	
	return false;
	
}

function DefaultAddress()
{

	if(!IsEmpty(document.forms['Form'].Email.value))
	{
	
		var X = document.forms['Form'].Email.value;
		var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (!Filter.test(X))
		{
		alert('Incorrect Email Address');
		document.forms['Form'].Email.focus();
		return false;
		}
	
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Domain = document.forms['Form'].Domain.value;
	var Email = document.forms['Form'].Email.value;

	Load ('mail-default.php?Domain='+Domain+'&Email='+Email+'&ControlID='+ControlID,ControlID);
	
	return false;
}


function Defaultemail()
{

http=Ajax();http.abort();
http.open('POST', 'ajax/mail-default.php?Lng=en&Domain='+document.getElementById('Domain').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleDefaultEmail;
http.send('');
}

function HandleDefaultEmail()
{


	if (http.readyState == 1)
	{
	
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	document.getElementById('Email').value = response;
	}
}


function SPF()
{
http=Ajax();http.abort();
http.open('POST', 'ajax/spf.php?Lng=en&Domain='+document.getElementById('Domain').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleSPF;
http.send('');
}

function HandleSPF()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	document.getElementById('DivSPF').innerHTML = response;
	}
}
	
function GetDocumentRoot()
{
http=Ajax();http.abort();
http.open('POST', 'ajax/document-root.php?Lng=en&Username='+document.getElementById('Username').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleGetDocumentRoot;
http.send('');
}

function HandleGetDocumentRoot()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	document.getElementById('DocumentRoot').value = response;
	}
}
	
		
function GetUsername()
{
http=Ajax();http.abort();
http.open('POST', 'ajax/username.php?Lng=en&Domain='+document.getElementById('Domain').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleGetUsername;
http.send('');
}

function HandleGetUsername()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	document.getElementById('Username').value=response;
	}
}
	
	
	

function MySQLReset()
{

	if(IsEmpty(document.forms['Form'].Password.value))
	{
	alert('Please type your new password');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}

	if (document.forms['Form'].Password.value!=document.forms['Form'].VerifyPassword.value)
	{
	alert('Your password entries did not match');
	document.forms['Form'].Password.value='';
	document.forms['Form'].VerifyPassword.value='';
	document.forms['Form'].Password.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
	
	http=Ajax();http.abort();
	http.open("POST", "mysql-reset.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Password='+Password+'&ControlID='+ControlID);
		
	return false;
	
					
}


function PasswordModification()
{

	var Domain = document.forms['Form'].Domain.value;

	if(IsEmpty(document.forms['Form'].Password.value))
	{
	alert('Please type your new password');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}

	if (document.forms['Form'].Password.value!=document.forms['Form'].VerifyPassword.value)
	{
	alert('Your password entries did not match');
	document.forms['Form'].Password.value='';
	document.forms['Form'].VerifyPassword.value='';
	document.forms['Form'].Password.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "password.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Password='+Password+'&ControlID='+ControlID);
	
	return false;
	
}



function UsernameModification()
{
	var Domain = document.forms['Form'].Domain.value;
	var Username = document.forms['Form'].Username.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('username.php?Domain='+Domain+'&Username='+Username+'&ControlID='+ControlID,ControlID);

	return false;
}




function WordpressPassword()
{

	var Username = document.forms['Form'].Username.value;

	if(IsEmpty(document.forms['Form'].Password.value))
	{
	alert('Please type your new password');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}

	if (document.forms['Form'].Password.value!=document.forms['Form'].VerifyPassword.value)
	{
	alert('Your password entries did not match');
	document.forms['Form'].Password.value='';
	document.forms['Form'].VerifyPassword.value='';
	document.forms['Form'].Password.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "wordpress-password.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Username='+Username+'&Password='+Password+'&ControlID='+ControlID);
	
	return false;
	
}


function Encoder()
{

	var Domain = document.forms['Form'].Domain.value;

	if(IsEmpty(document.forms['Form'].Password.value))
	{
	alert('Please type your new password');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('Encryption Key must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	var Type=Radio('Type');
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "encoder.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Password='+Password+'&Type='+Type+'&ControlID='+ControlID);
	
	return false;
	
}

function SSHPort()
{	
	var PORT = document.forms['Form'].PORT.value;
	var DROPBEARPORT = document.forms['Form'].DROPBEARPORT.value;
	
	// is not number
	if(isNaN(PORT))
	{
	alert('Incorrect Port');
	document.forms['Form'].PORT.focus();
	return false;
	}
	
	if (PORT<1 || PORT>65535)
	{
	alert('Incorrect Port');
	document.forms['Form'].PORT.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('port.php?PORT='+PORT+'&DROPBEARPORT='+DROPBEARPORT+'&ControlID='+ControlID,ControlID);
	
	return false;
	
	
}

function DirectoryPrivacy()
{

	if(IsEmpty(document.forms['Form'].Name.value))
	{
	alert('Please Enter Name');
	document.forms['Form'].Name.focus();
	return false;
	}
	
	var Name = document.forms['Form'].Name.value;
	var Directory = document.forms['Form'].Directory.value;
	var User = document.forms['Form'].User.value;
	var Password = document.forms['Form'].Password.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('directory.php?Name='+Name+'&Directory='+Directory+'&User='+User+'&Password='+Password+'&ControlID='+ControlID,ControlID);
	
	return false;
	
	
}


function GithubDownloader()
{

	if(IsEmpty(document.forms['Form'].URL.value))
	{
	alert('Please Enter URL');
	document.forms['Form'].URL.focus();
	return false;
	}
	
	var Directory = document.forms['Form'].Directory.value;
	var URL = document.forms['Form'].URL.value;
	
	var Sync='0';
	if (document.forms['Form'].Sync.checked==true)
	{
	Sync='1';
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('github.php?Directory='+Directory+'&URL='+URL+'&Sync='+Sync+'&ControlID='+ControlID,ControlID);
	
	return false;
	
	
}


function InstallScript()
{

	var Name = document.forms['Form'].Name.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(Name))
	{
	alert('MySQL Database Name must contain only letters, numbers and underscores');
	document.forms['Form'].Name.focus();
	return false;
	}
	
	var User = document.forms['Form'].User.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(User))
	{
	alert('Username must contain only letters, numbers and underscores');
	document.forms['Form'].User.focus();
	return false;
	}
	
	if(IsEmpty(document.forms['Form'].Pass.value))
	{
	alert('Please type database password');
	document.forms['Form'].Pass.focus();
	return false;
	}
	
	var Pass = document.forms['Form'].Pass.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Pass))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Pass.focus();
	return false;
	}		
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	var ScriptFile = document.forms['Form'].ScriptFile.value;
	var Directory = document.forms['Form'].Directory.value;
	var ScriptID = document.forms['Form'].ScriptID.value;
	var NavigatorTitle = document.forms['Form'].NavigatorTitle.value;
		
	Pass = Pass.replaceAll("$", "[DollarSign]");
	Pass = Pass.replaceAll("&", "[AndSign]");
	Pass = Pass.replaceAll("=", "[EqualSign]");
	Pass = Pass.replaceAll("#", "[HashSign]");
		
	http=Ajax();http.abort();
	http.open("POST", "script.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('ScriptFile='+ScriptFile+'&Name='+Name+'&User='+User+'&Pass='+Pass+'&Directory='+Directory+'&ScriptID='+ScriptID+'&NavigatorTitle='+NavigatorTitle+'&ControlID='+ControlID);
		
	return false;

}

var WhoisNo=0;
function Whois()
{
	
	WhoisNo=0;
	
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
		// invalid domain
		WhoisNo++;
	}
	
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(Domain))
	{
		// invalid ip
		WhoisNo++;

	}
	
	if (WhoisNo==2)
	{
	alert('Incorrect Domain or IP Address');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';


	Load ('whois.php?Domain='+Domain+'&ControlID='+ControlID,ControlID);
	
	return false;

}


function TrackDNS()
{
	
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}	
		
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('dig.php?Domain='+Domain+'&ControlID='+ControlID,ControlID);
	
	return false;
	
}


function CNAME()
{
	
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('cname.php?Domain='+Domain+'&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function Nameserver()
{
	
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('nameserver.php?Domain='+Domain+'&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function Mx()
{

	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('mx.php?Domain='+Domain+'&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function TXT()
{
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('txt.php?Domain='+Domain+'&ControlID='+ControlID,ControlID);
	return false;

}

function Ping()
{
	
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('ping.php?Domain='+Domain+'&ControlID='+ControlID,ControlID);
	return false;
	
}

function Responder()
{

	var Email = document.forms['Form'].User.value+"@"+document.forms['Form'].Domain.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(Email))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].User.focus();
	return false;
	}
	
	var Edit = document.forms['Form'].Edit.value;
	var Domain = document.forms['Form'].Domain.value;
	var Subject = document.forms['Form'].Subject.value;
	var Message = document.forms['Form'].Message.value;
	var StartDate = document.forms['Form'].StartDate.value;
	var EndDate = document.forms['Form'].EndDate.value;

	var Active=Radio('Active');

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	http=Ajax();http.abort();
	http.open("POST", "responder.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Email='+Email+'&Subject='+Subject+'&Message='+Message+'&StartDate='+StartDate+'&EndDate='+EndDate+'&Active='+Active+'&Edit='+Edit+'&ControlID='+ControlID);
		

	return false;
	
}


function Site()
{
		
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	var Username = document.forms['Form'].Username.value;
	var Filter  = /^[a-zA-Z0-9\/\-\_\.]+$/;
	if (!Filter.test(Username))
	{
	alert('Invalid Username');
	document.forms['Form'].Username.focus();
	return false;
	}
	
	var Edit = document.forms['Form'].Edit.value;
		
	var Password='';
	if (Edit!=1)
	{
		Password = document.forms['Form'].Password.value;
		var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
		if (!Filter.test(Password))
		{
		alert('Password must contain only letters, numbers and underscores');
		document.forms['Form'].Password.focus();
		return false;
		}
	}
	
	
	var Email = document.forms['Form'].Email.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(Email))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].Email.focus();
	return false;
	}
	
	var PHPVersion=Radio('PHPVersion');
	
	if(IsEmpty(PHPVersion))
	{
	alert('Select PHP version.');
	return false;
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var SSLCertificate='0';
	if (document.forms['Form'].SSLCertificate.checked==true)
	{
	SSLCertificate='1';
	}

	var SSLRedirect='0';
	if (document.forms['Form'].SSLRedirect.checked==true)
	{
	SSLRedirect='1';
	}

	var FPM='0';
	if (document.forms['Form'].FPM.checked==true)
	{
	FPM='1';
	}
	
	var Skeleton='n';
	if (document.forms['Form'].Skeleton)
	{
		if (document.forms['Form'].Skeleton.checked==true)
		{
		Skeleton='y';
		}
	}
		
	
	var CurrentDomain = document.forms['Form'].CurrentDomain.value;
	
	var PackageID = document.forms['Form'].PackageID.value;
	var DiskSpace = document.forms['Form'].DiskSpace.value;
	var Bandwidth = document.forms['Form'].Bandwidth.value;
	var FTPNo = document.forms['Form'].FTPNo.value;
	var EmailNo = document.forms['Form'].EmailNo.value;
	var DatabaseNo = document.forms['Form'].DatabaseNo.value;
	var SubDomainNo = document.forms['Form'].SubDomainNo.value;
	var AliasNo = document.forms['Form'].AliasNo.value;
	var AddonNo = document.forms['Form'].AddonNo.value;
	var ExpiresOn = document.forms['Form'].ExpiresOn.value;
	
	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
	
	http=Ajax();http.abort();
	http.open("POST", "site.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Edit='+Edit+'&Domain='+Domain+'&Username='+Username+'&CurrentDomain='+CurrentDomain+'&Password='+Password+'&Email='+Email+'&PHPVersion='+PHPVersion+'&PackageID='+PackageID+'&DiskSpace='+DiskSpace+'&Bandwidth='+Bandwidth+'&FTPNo='+FTPNo+'&EmailNo='+EmailNo+'&DatabaseNo='+DatabaseNo+'&SubDomainNo='+SubDomainNo+'&AliasNo='+AliasNo+'&AddonNo='+AddonNo+'&SSLCertificate='+SSLCertificate+'&SSLRedirect='+SSLRedirect+'&FPM='+FPM+'&Skeleton='+Skeleton+'&ExpiresOn='+ExpiresOn+'&ControlID='+ControlID);
		
	return false;

}


function MultipleSite()
{
	
	var X = document.forms['Form'].Email.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(X))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].Email.focus();
	return false;
	}
	
	var PHPVersion=Radio('PHPVersion');
	
	if(IsEmpty(PHPVersion))
	{
	alert('Select PHP version.');
	return false;
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var SSLCertificate='0';
	if (document.forms['Form'].SSLCertificate.checked==true)
	{
	SSLCertificate='1';
	}
	
	var SSLRedirect='0';
	if (document.forms['Form'].SSLRedirect.checked==true)
	{
	SSLRedirect='1';
	}
	
	var Skeleton='n';
	if (document.forms['Form'].Skeleton)
	{
		if (document.forms['Form'].Skeleton.checked==true)
		{
		Skeleton='y';
		}
	}
	

	var Domains = document.forms['Form'].Domains.value;
	Domains = Domains.replace(/\n/g,',');
	
	var Email = document.forms['Form'].Email.value;
	var PackageID = document.forms['Form'].PackageID.value;
	var DiskSpace = document.forms['Form'].DiskSpace.value;
	var Bandwidth = document.forms['Form'].Bandwidth.value;
	var FTPNo = document.forms['Form'].FTPNo.value;
	var EmailNo = document.forms['Form'].EmailNo.value;
	var DatabaseNo = document.forms['Form'].DatabaseNo.value;
	var SubDomainNo = document.forms['Form'].SubDomainNo.value;
	var AliasNo = document.forms['Form'].AliasNo.value;
	var AddonNo = document.forms['Form'].AddonNo.value;
	var ExpiresOn = document.forms['Form'].ExpiresOn.value;
	
	Password = document.forms['Form'].Password.value;
	
	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
	
	http=Ajax();http.abort();
	http.open("POST", "multiple.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domains='+Domains+'&Password='+Password+'&Email='+Email+'&PHPVersion='+PHPVersion+'&PackageID='+PackageID+'&DiskSpace='+DiskSpace+'&Bandwidth='+Bandwidth+'&FTPNo='+FTPNo+'&EmailNo='+EmailNo+'&DatabaseNo='+DatabaseNo+'&SubDomainNo='+SubDomainNo+'&AliasNo='+AliasNo+'&AddonNo='+AddonNo+'&SSLCertificate='+SSLCertificate+'&SSLRedirect='+SSLRedirect+'&Skeleton='+Skeleton+'&ExpiresOn='+ExpiresOn+'&ControlID='+ControlID);
		
	return false;

}



function Expiration()
{
		
	var SiteID = document.forms['Form'].SiteID.value;
	var FullName = document.forms['Form'].FullName.value;
	var MobNo = document.forms['Form'].MobNo.value;
	var Email = document.forms['Form'].Email.value;
	var ExpiresOn = document.forms['Form'].ExpiresOn.value;
	var Description = document.forms['Form'].Description.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	http=Ajax();http.abort();
	http.open("POST", "client.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('ExpiresOn='+ExpiresOn+'&SiteID='+SiteID+'&FullName='+FullName+'&MobNo='+MobNo+'&Email='+Email+'&Description='+Description+'&ControlID='+ControlID);
		

	return false;

}

function RestartDNS()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('dns-restart.php?Action=RestartDNS&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function RestartHTTP()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('http.php?Action=RestartHTTP&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function RestartFTP()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';


	

	Load ('vsftpd.php?Action=RestartFTP&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function RestartMAIL()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';


	

	Load ('mailserver.php?Action=RestartMAIL&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function RestartMySQL()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';


	

	Load ('mysqlserver.php?Action=RestartMySQL'+'&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function RestartSSH()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';


	

	Load ('sshserver.php?Action=RestartSSH&ControlID='+ControlID,ControlID);
	
	return false;
	
}


function RestartFPM()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';


	

	Load ('php-fpm.php?Action=RestartFPM&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function CheckAll()
{
	var OneRow=1

	N=CheckForm.elements['CheckList[]'].length;

	if (document.forms['CheckForm'].AllCheckList.checked==true)
	{
		for ( var i=0; i < N ; i++ )
		{
			CheckForm.elements['CheckList[]'][i].checked=true;
			eval("R"+i+".style.background='#FF0000';");   	
		
		var OneRow=0;
		}

		if (OneRow==1)
		{
			CheckForm.elements['CheckList[]'].checked=true;
			R0.style.background="#FF0000";   	
		}

	}
	else
	{
	var OneRow=1

		for ( var i=0; i < N ; i++ )
		{
			CheckForm.elements['CheckList[]'][i].checked=false;

				if (i/2==Math.ceil(i/2))
				{
				eval("R"+i+".style.background='#FFFFFF';");
				}
				else
				{
				eval("R"+i+".style.background='#CCCCCC';");
				}

		var OneRow=0;
		}

		if (OneRow==1)
		{
		CheckForm.elements['CheckList[]'].checked=false;
		R0.style.background="#FFFFFF";   	
		}
	}
} 

function ColorRow(RowID,i,DefaultColor)
{
	N=CheckForm.elements['CheckList[]'].length;
	
	if (N>=2)
	{

		if (CheckForm.elements['CheckList[]'][i].checked==true)
		{
		RowID.style.background="#FF0000";   	
		}	
		else
		{
		RowID.style.background=DefaultColor;   	
		}	
	}
	else
	{
					if (CheckForm.elements['CheckList[]'].checked==true)
		{
		RowID.style.background="#FF0000";   	
		}
		else
		{
		RowID.style.background=DefaultColor;   	
		}	
	}

}


function BlockIP()
{
	var IP = document.forms['Form'].IP.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(IP))
	{
	alert('You have entered an invalid IP address');
	document.forms['Form'].IP.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Domain = document.forms['Form'].Domain.value;

	Load ('block.php?Domain='+Domain+'&IP='+IP);
	
	return false;
	
}


var N=0;
function ClamAVAntivirus()
{

	N=0;

	X=Scan('1');
	return false;

}

function Scan(N)
{
http=Ajax();http.abort();
http.open('POST', 'ajax/antivirus.php?Lng=en&Domain='+document.getElementById('Domain').value+'&N='+N,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleScan;
http.send('');
}

function HandleScan()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	N++;
	
		var response = http.responseText;
	
		if (response=='')
		{
		
			
			Dot=N%6;
			DotString='';
			for (D=0;D<=Dot;D++)
			{
			DotString=DotString+'.';
			}
			
			document.getElementById('DivScan').innerHTML = '<b>Scanning'+DotString+'</b>';
		
		
			setTimeout(function(){ Scan('2'); }, 5000);

		}
		else
		{
		document.getElementById('DivScan').innerHTML = response;
		}
	
	
	}
}


function Backup()
{
	var Username = document.forms['Form'].Username.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Type = document.forms['Form'].Type.value;
	var Destination = document.forms['Form'].Destination.value;
	var Email = document.forms['Form'].Email.value;
	var RemoteServer = document.forms['Form'].RemoteServer.value;
	var RemoteUser = document.forms['Form'].RemoteUser.value;
	var RemotePassword = document.forms['Form'].RemotePassword.value;
	var RemoteDir = document.forms['Form'].RemoteDir.value;
	var ControlID = document.forms['Form'].ControlID.value;
	
	if (Destination=="URL")
	{
	Load ('backup.php?Username='+Username+'&Type='+Type+'&Destination='+Destination+'&Email='+Email+'&ControlID='+ControlID);
	}
	else
	{
	http=Ajax();http.abort();
	http.open("POST", "backup.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Username='+Username+'&Type='+Type+'&Destination='+Destination+'&Email='+Email+'&RemoteServer='+RemoteServer+'&RemoteUser='+RemoteUser+'&RemotePassword='+RemotePassword+'&RemoteDir='+RemoteDir+'&ControlID='+ControlID);
	}
	
	return false;
}




function ScheduleBackup()
{

	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Storage=Radio('Storage');

	var Domain = document.forms['Form'].Domain.value;
	var Destination = document.forms['Form'].Destination.value;
	var Email = document.forms['Form'].Email.value;
	var RemoteServer = document.forms['Form'].RemoteServer.value;
	var RemoteUser = document.forms['Form'].RemoteUser.value;
	var RemotePassword = document.forms['Form'].RemotePassword.value;
	var Port = document.forms['Form'].Port.value;
	var RemoteDir = document.forms['Form'].RemoteDir.value;

	var Type='';
	if (document.forms['Form'].WWWBackup.checked==true && document.forms['Form'].MailBackup.checked==true && document.forms['Form'].DatabaseBackup.checked==true)
	{
	var Type='full';
	}
	else
	{

		if (document.forms['Form'].WWWBackup.checked==true)
		{
		Type=Type+'www';
		}
		
		if (document.forms['Form'].MailBackup.checked==true)
		{
		Type=Type+'mail';
		}
		
		if (document.forms['Form'].DatabaseBackup.checked==true)
		{
		Type=Type+'database';
		}

	}

	http=Ajax();http.abort();
	http.open("POST", "schedule.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Type='+Type+'&Destination='+Destination+'&Email='+Email+'&RemoteServer='+RemoteServer+'&RemoteUser='+RemoteUser+'&RemotePassword='+RemotePassword+'&Port='+Port+'&RemoteDir='+RemoteDir+'&Storage='+Storage);
	
	
	return false;
}


function SyncPath()
{

	

	if (document.forms['Form'].Home.checked==true && document.forms['Form'].Mail.checked==true)
	{
	document.forms['Form'].SYNCPath.value="/home/*/www:/home/*/mail";
	}
	else if (document.forms['Form'].Home.checked==true)
	{
	document.forms['Form'].SYNCPath.value="/home/*/www";
	}
	else if (document.forms['Form'].Mail.checked==true)
	{
	document.forms['Form'].SYNCPath.value="/home/*/mail";
	}
	else
	{
	document.forms['Form'].SYNCPath.value="";
	}

}

function SyncBackup()
{
	
	var BackupType='-';
	
	if (document.forms['Form'].Incremental.checked==true && document.forms['Form'].Differential.checked==true)
	{
	BackupType="incremental-differential";
	}
	else if (document.forms['Form'].Incremental.checked==true)
	{
	BackupType="incremental";
	}
	else if (document.forms['Form'].Differential.checked==true)
	{
	BackupType="differential";
	}
	
	var RemoteServer = document.forms['Form'].RemoteServer.value;
	var RemotePassword = document.forms['Form'].RemotePassword.value;
	var Destination = document.forms['Form'].Destination.value;

	var IncrementalTime = document.forms['Form'].IncrementalTime.value;
	var DifferentialTime = document.forms['Form'].DifferentialTime.value;
	
	var SYNCPath = document.forms['Form'].SYNCPath.value;
	var Email = document.forms['Form'].Email.value;
	var RemoteUser = document.forms['Form'].RemoteUser.value;
	var RemoteDir = document.forms['Form'].RemoteDir.value;


	if (Destination=='SCP')
	{

		if(IsEmpty(RemotePassword))
		{
		alert('Please enter remote password');
		document.forms['Form'].RemotePassword.focus();
		return false;
		}

	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';


	http=Ajax();http.abort();
	http.open("POST", "sync.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('BackupType='+BackupType+'&IncrementalTime='+IncrementalTime+'&DifferentialTime='+DifferentialTime+'&SYNCPath='+SYNCPath+'&Destination='+Destination+'&Email='+Email+'&RemoteServer='+RemoteServer+'&RemoteUser='+RemoteUser+'&RemotePassword='+RemotePassword+'&RemoteDir='+RemoteDir);
	
	return false;
}


function CreateEmail()
{

	var User = document.forms['Form'].User.value;
	var Filter  = /^[a-zA-Z0-9\/\.\_]+$/;
	if (!Filter.test(User))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].User.focus();
	return false;
	}
	
	var Pass = document.forms['Form'].Pass.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Pass))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Pass.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Domain = document.forms['Form'].Domain.value;
	var Edit = document.forms['Form'].Edit.value;

	Pass = Pass.replaceAll("$", "[DollarSign]");
	Pass = Pass.replaceAll("&", "[AndSign]");
	Pass = Pass.replaceAll("=", "[EqualSign]");
	Pass = Pass.replaceAll("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "mail.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&User='+User+'&Pass='+Pass+'&Edit='+Edit);
	
	return false;
	
}


function CreateMultipleEmail()
{
	
	var Pass = document.forms['Form'].Pass.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Pass))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Pass.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Pass = Pass.replaceAll("$", "[DollarSign]");
	Pass = Pass.replaceAll("&", "[AndSign]");
	Pass = Pass.replaceAll("=", "[EqualSign]");
	Pass = Pass.replaceAll("#", "[HashSign]");

	var Emails = document.forms['Form'].Emails.value;
	Emails = Emails.replace(/\n/g,',');

	http=Ajax();http.abort();
	http.open("POST", "mails.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Emails='+Emails+'&Pass='+Pass);
	
	return false;
	
}


function Forwarders()
{

	var X = document.forms['Form'].Username.value+"@"+document.forms['Form'].Domain.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(X))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].Username.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	
	var KeepCopy='0';
	if (document.forms['Form'].KeepCopy.checked==true)
	{
	KeepCopy='1';
	}

	var Reject='0';
	if (document.forms['Form'].Reject.checked==true)
	{
	Reject='1';
	}
	
	var Username = document.forms['Form'].Username.value;
	var Domain = document.forms['Form'].Domain.value;
	var ForwardTo = document.forms['Form'].ForwardTo.value;
	var RejectMessage = document.forms['Form'].RejectMessage.value;
	var Edit = document.forms['Form'].Edit.value;

	Load ('forward.php?Domain='+Domain+'&Username='+Username+'&ForwardTo='+ForwardTo+'&KeepCopy='+KeepCopy+'&Reject='+Reject+'&RejectMessage='+RejectMessage+'&Edit='+Edit);
	
	return false;
	
}


function SwitchReject()
{
	if (document.getElementById('Reject').checked==true)
	{
	document.getElementById('ForwardTo').style.display='none';
	document.getElementById('KeepCopy').style.display='none';
	document.getElementById('RejectMessage').style.display='';
	}
	else
	{
	document.getElementById('ForwardTo').style.display='';
	document.getElementById('KeepCopy').style.display='';
	document.getElementById('RejectMessage').style.display='none';
	}
}




function AddDistro()
{
	var File = document.forms['Form'].File.value;
	var Name = document.forms['Form'].Name.value;
	var DistroID = document.forms['Form'].DistroID.value;
	var Edit = document.forms['Form'].Edit.value;
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('distro.php?Name='+Name+'&File='+File+'&DistroID='+DistroID+'&Edit='+Edit);
	
	return false;
	
}




function ChangeDocumentRoot()
{

	var DocumentRoot = document.forms['Form'].DocumentRoot.value;

	if (DocumentRoot!="")
	{
		
		var Filter  = /^[a-zA-Z0-9\/\-\_]+$/;
		if (!Filter.test(DocumentRoot))
		{
		alert('Invalid Document Root');
		document.forms['Form'].DocumentRoot.focus();
		return false;
		}
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
		
	var Username = document.forms['Form'].Username.value;

	Load ('document-root.php?Username='+Username+'&DocumentRoot='+DocumentRoot);
	
	return false;
}


function CreateSubdomain()
{

	var Directory = document.forms['Form'].Directory.value;
	var Filter  = /^[a-zA-Z0-9\-]+$/;
	if (!Filter.test(Directory))
	{
	alert('Incorrect Subdomain');
	document.forms['Form'].Directory.focus();
	return false;
	}
	
	var DocumentRoot = document.forms['Form'].DocumentRoot.value;
	var Filter  = /^[a-zA-Z0-9\/\-\_]+$/;
	if (!Filter.test(DocumentRoot))
	{
	alert('Invalid Document Root');
	document.forms['Form'].DocumentRoot.focus();
	return false;
	}

	var PHPVersion=Radio('PHPVersion');
	
	if(IsEmpty(PHPVersion))
	{
	alert('Select PHP version.');
	return false;
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
		
	var Domain = document.forms['Form'].Domain.value;
	var RedirectUrl = document.forms['Form'].RedirectUrl.value;
	var SubdomainID = document.forms['Form'].SubdomainID.value;
	var Edit = document.forms['Form'].Edit.value;

	Load ('subdomain.php?Domain='+Domain+'&Directory='+Directory+'&DocumentRoot='+DocumentRoot+'&RedirectUrl='+RedirectUrl+'&PHPVersion='+PHPVersion+'&Edit='+Edit+'&SubdomainID='+SubdomainID);
	
	return false;
}

function MySQL()
{
	
	var Name = document.forms['Form'].Name.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(Name))
	{
	alert('MySQL Database Name must contain only letters, numbers and underscores');
	document.forms['Form'].Name.focus();
	return false;
	}
	
	var User = document.forms['Form'].User.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(User))
	{
	alert('Username must contain only letters, numbers and underscores');
	document.forms['Form'].User.focus();
	return false;
	}
	
	var Pass = document.forms['Form'].Pass.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Pass))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Pass.focus();
	return false;
	}
	
	var Remote='0';
	if (document.forms['Form'].Remote.checked==true)
	{
	Remote='1';
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	var Domain = document.forms['Form'].Domain.value;
	var Edit = document.forms['Form'].Edit.value;

	Pass = Pass.replaceAll("$", "[DollarSign]");
	Pass = Pass.replaceAll("&", "[AndSign]");
	Pass = Pass.replaceAll("=", "[EqualSign]");
	Pass = Pass.replaceAll("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "mysql.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Name='+Name+'&User='+User+'&Pass='+Pass+'&Remote='+Remote+'&Edit='+Edit);
		
	return false;
	
}



function CopyMySQL()
{

	var Username = document.forms['Form'].Username.value;
	
	var Name = document.forms['Form'].Name.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(Name))
	{
	alert('MySQL Database Name must contain only letters, numbers and underscores');
	document.forms['Form'].Name.focus();
	return false;
	}
	
	var User = document.forms['Form'].User.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(User))
	{
	alert('Username must contain only letters, numbers and underscores');
	document.forms['Form'].User.focus();
	return false;
	}
	
	var Pass = document.forms['Form'].Pass.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Pass))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Pass.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	var Source = document.forms['Form'].Source.value;

	Pass = Pass.replaceAll("$", "[DollarSign]");
	Pass = Pass.replaceAll("&", "[AndSign]");
	Pass = Pass.replaceAll("=", "[EqualSign]");
	Pass = Pass.replaceAll("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "copydb.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Username='+Username+'&Name='+Name+'&User='+User+'&Pass='+Pass+'&Source='+Source);
		
	return false;
	
}



function ImportSQL()
{

	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	var Name = document.forms['Form'].Name.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(Name))
	{
	alert('MySQL Database Name must contain only letters, numbers and underscores');
	document.forms['Form'].Name.focus();
	return false;
	}
	
	var Username = document.forms['Form'].Username.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(Username))
	{
	alert('Username must contain only letters, numbers and underscores');
	document.forms['Form'].Username.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	var Database = document.forms['Form'].Database.value;

	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "sql.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Name='+Name+'&Username='+Username+'&Password='+Password+'&Database='+Database);
		
	return false;
	
}



function Postgre()
{

	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	var Name = document.forms['Form'].Name.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(Name))
	{
	alert('PostgreSQL Database Name must contain only letters, numbers and underscores');
	document.forms['Form'].Name.focus();
	return false;
	}
	
	var Username = document.forms['Form'].Username.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(Username))
	{
	alert('PostgreSQL Username must contain only letters, numbers and underscores');
	document.forms['Form'].Username.focus();
	return false;
	}
	
	var Password = document.forms['Form'].Password.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Password))
	{
	alert('PostgreSQL Password must contain only letters, numbers and underscores');
	document.forms['Form'].Password.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	var Edit = document.forms['Form'].Edit.value;

	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");

	http=Ajax();http.abort();
	http.open("POST", "postgre.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Name='+Name+'&Username='+Username+'&Password='+Password+'&Edit='+Edit);
		
	return false;
	
}

function CreateFTPAccount()
{
	var User= document.forms['Form'].User.value;
	var Filter  = /^\w+$/;
	if (!Filter.test(User))
	{
	alert('Username must contain only letters, numbers and underscores');
	document.forms['Form'].Username.focus();
	return false;
	}
	
	var Pass = document.forms['Form'].Pass.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(Pass))
	{
	alert('Password must contain only letters, numbers and underscores');
	document.forms['Form'].Pass.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Domain = document.forms['Form'].Domain.value;
	var Directory = document.forms['Form'].Directory.value;
	var Edit = document.forms['Form'].Edit.value;
	
	Pass = Pass.replaceAll("$", "[DollarSign]");
	Pass = Pass.replaceAll("&", "[AndSign]");
	Pass = Pass.replaceAll("=", "[EqualSign]");
	Pass = Pass.replaceAll("#", "[HashSign]");
	
	http=Ajax();http.abort();
	http.open("POST", "ftp.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&User='+User+'&Pass='+Pass+'&Directory='+Directory+'&Edit='+Edit);
		
	return false;
}


function SQLite()
{


	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Domain = document.forms['Form'].Domain.value;
	var Directory = document.forms['Form'].Directory.value;
	var Edit = document.forms['Form'].Edit.value;
	
	Load ('sqlite.php?Domain='+Domain+'&Directory='+Directory+'&Edit='+Edit);
	
	return false;
	
}

function SSL()
{
	var Domain = document.forms['Form'].Domain.value;
	var Certificate = encodeURIComponent($('#Certificate').val());
	var PrivateKey = encodeURIComponent($('#PrivateKey').val());
	var Bundle = encodeURIComponent($('#Bundle').val());
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	http=Ajax();http.abort();
	http.open("POST", "ssl.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('Domain='+Domain+'&Certificate='+Certificate+'&PrivateKey='+PrivateKey+'&Bundle='+Bundle);
		
	return false;



}

function FreeSSL()
{
	var Domain = document.forms['Form'].Domain.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(Domain))
	{
	alert('Incorrect Domain');
	document.forms['Form'].Domain.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Type=Radio('Type');
	
	Load ('letsencrypt.php?Domain='+Domain+'&Type='+Type);
	
	return false;

}

function ShutdownMethod()
{

	if (document.forms['Form'].Shutdown[0].checked==true)
	{
	document.getElementById('TrDelay1').style.display='none';
	document.getElementById('TrScheduleTime1').style.display='none';
	}

	if (document.forms['Form'].Shutdown[1].checked==true)
	{
	document.getElementById('Delay').style.display='';
	document.getElementById('ScheduleTime').style.display='none';
	}

	if (document.forms['Form'].Shutdown[2].checked==true)
	{
	document.getElementById('Delay').style.display='none';
	document.getElementById('ScheduleTime').style.display='';
	}

}



function Reboot()
{

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	var Shutdown=Radio('Shutdown');

	var Hours = document.forms['Form'].Hours.value;
	var Minutes = document.forms['Form'].Minutes.value;
	var H = document.forms['Form'].H.value;
	var M = document.forms['Form'].M.value;
	var AMPM = document.forms['Form'].AMPM.value;

	Load ('reboot.php?Shutdown='+Shutdown+'&Hours='+Hours+'&Minutes='+Minutes+'&H='+H+'&M='+M+'&AMPM='+AMPM);
	return false;

}

function Zone()
{

	var ControlID = document.forms['Form'].ControlID.value;
	
	var Domain = document.forms['Form'].Domain.value;
	var Name = document.forms['Form'].Name.value;
	var Type = document.forms['Form'].Type.value;
	var Value = document.forms['Form'].Value.value;
	var TTL = document.forms['Form'].TTL.value;
	
	var Edit = document.forms['Form'].Edit.value;
	var ZoneID = document.forms['Form'].ZoneID.value;

	var Filter  = /^[0-9a-zA-Z\.\_]+$/;
	if (!Filter.test(Name))
	{
	alert('You must specify a valid zone name.');
	document.forms['Form'].Name.focus();
	return false;
	}
		
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (Filter.test(Name))
	{
	alert('You must specify a valid zone name.');
	document.forms['Form'].Name.focus();
	return false;
	}
	
	if (Type=="A")
	{
		
		if(IsEmpty(Value))
		{
		alert('You have entered an invalid IP address');
		document.forms['Form'].Value.focus();
		return false;
		}
		
		var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
		if (!Filter.test(Value))
		{
		alert(Value+' is not a valid IP address.');
		document.forms['Form'].Value.focus();
		return false;
		}
	}
	
	if (Type=="CNAME")
	{
		// NOT IP
		var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
		if (Filter.test(Value))
		{
		alert('Value for CNAME record should be a host/domainname/fqdn & not an IP Address');
		document.forms['Form'].Value.focus();
		return false;
		}
	
		var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
		if (!Filter.test(Value))
		{
		alert('Value for CNAME record should be a host/domainname/fqdn & not an IP Address');
		document.forms['Form'].Value.focus();
		return false;
		}
	
	}
	

	if (Type=="MX" || Type=="NS")
	{
	
		// NOT IP
		var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
		if (Filter.test(Value))
		{
		alert('Please provide a valid fqdn.');
		document.forms['Form'].Value.focus();
		return false;
		}
	
		var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
		if (!Filter.test(Value))
		{
		alert('Please provide a valid fqdn.');
		document.forms['Form'].Value.focus();
		return false;
		}
	
	}
	
	var Priority=0;
	if (document.forms['Form'].Priority)
	{
	Priority = document.forms['Form'].Priority.value;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	
	Load ('zone.php?Domain='+Domain+'&Name='+Name+'&Type='+Type+'&Value='+Value+'&TTL='+TTL+'&Priority='+Priority+'&Edit='+Edit+'&ZoneID='+ZoneID+'&ControlID='+ControlID);
	return false;

}



function awsPanelSetup()
{

	var AdminEmail = document.forms['Form'].AdminEmail.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(AdminEmail))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].AdminEmail.focus();
	return false;
	}

	var AlternativeAdminEmail = document.forms['Form'].AlternativeAdminEmail.value;
	if (AlternativeAdminEmail!="")
	{
		var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (!Filter.test(AlternativeAdminEmail))
		{
		alert('Incorrect Email Address');
		document.forms['Form'].AlternativeAdminEmail.focus();
		return false;
		}
	}
	
	
	var AdminMobile = document.forms['Form'].AdminMobile.value;
	var AlternativeAdminMobile = document.forms['Form'].AlternativeAdminMobile.value;
	var ConfigPassword = document.forms['Form'].ConfigPassword.value;
	var QueueNo = document.forms['Form'].QueueNo.value;
	var WAInstanceID = document.forms['Form'].WAInstanceID.value;
	var WAAPIKey = document.forms['Form'].WAAPIKey.value;

	var SSHAlert='0';
	if (document.forms['Form'].SSHAlert.checked==true)
	{
	SSHAlert='1';
	}

	var IMAPAlert='0';
	if (document.forms['Form'].IMAPAlert.checked==true)
	{
	IMAPAlert='1';
	}

	var Junk='0';
	if (document.forms['Form'].Junk.checked==true)
	{
	Junk='1';
	}

	var Welcome='0';
	if (document.forms['Form'].Welcome.checked==true)
	{
	Welcome='1';
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
		
	Load ('basic.php?AdminEmail='+AdminEmail+'&AlternativeAdminEmail='+AlternativeAdminEmail+'&AdminMobile='+AdminMobile+'&AlternativeAdminMobile='+AlternativeAdminMobile+'&ConfigPassword='+ConfigPassword+'&QueueNo='+QueueNo+'&WAInstanceID='+WAInstanceID+'&WAAPIKey='+WAAPIKey+'&SSHAlert='+SSHAlert+'&IMAPAlert='+IMAPAlert+'&Junk='+Junk+'&Welcome='+Welcome);  
	
	return false;

}



function Nameservers()
{
	var NS1 = document.forms['Form'].NS1.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(NS1))
	{
	alert('Incorrect Nameserver 1');
	document.forms['Form'].NS1.focus();
	return false;
	}
	
	var NS2 = document.forms['Form'].NS2.value;
	var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
	if (!Filter.test(NS2))
	{
	alert('Incorrect Nameserver 2');
	document.forms['Form'].NS2.focus();
	return false;
	}
	
	
	var NS3 = document.forms['Form'].NS3.value;
	if(! IsEmpty(NS3))
	{	
		var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
		if (!Filter.test(NS3))
		{
		alert('Incorrect Nameserver 3');
		document.forms['Form'].NS3.focus();
		return false;
		}
	}
		
	var NS4 = document.forms['Form'].NS4.value;
	if(! IsEmpty(NS4))
	{
		var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
		if (!Filter.test(NS4))
		{
		alert('Incorrect Nameserver 4');
		document.forms['Form'].NS4.focus();
		return false;
		}
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';
	
	Load ('nameservers.php?NS1='+NS1+'&NS2='+NS2+'&NS3='+NS3+'&NS4='+NS4);
	
	return false;

}



function Affiliate()
{
	var Email = document.forms['Form'].Email.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(Email))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].Email.focus();
	return false;
	}

	var Website = document.forms['Form'].Website.value;
	if(! IsEmpty(Website))
	{
	
		var Filter  = /^((?:(?:(?:\w[\.\-\+]?)*)\w)+)((?:(?:(?:\w[\.\-\+]?){0,62})\w)+)\.(\w{2,12})$/;
		if (!Filter.test(Website))
		{
		alert('Incorrect Website');
		document.forms['Form'].Website.focus();
		return false;
		}
		
		
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Password = document.forms['Form'].Password.value;
	var FullName = document.forms['Form'].FullName.value;
	var MobNo = document.forms['Form'].MobNo.value;
	var Gender = Radio('Gender');
	var Country = document.forms['Form'].Country.value;
	var Company = document.forms['Form'].Company.value;
	var Edit = document.forms['Form'].Edit.value;
	
	Password = Password.replace("$", "[DollarSign]");
	Password = Password.replace("&", "[AndSign]");
	Password = Password.replace("=", "[EqualSign]");
	Password = Password.replace("#", "[HashSign]");
	
	Load ('affiliate.php?Email='+Email+'&Password='+Password+'&FullName='+FullName+'&MobNo='+MobNo+'&Gender='+Gender+'&Country='+Country+'&Website='+Website+'&Company='+Company+'&Edit='+Edit);
	
	return false;
	
}

function MobileApi()
{
	var ApiKey = document.forms['Form'].ApiKey.value;
	var Filter  = /^[0-9a-zA-Z\.\_\$\!\@\#\%\^\&\*\+\-\=]+$/;
	if (!Filter.test(ApiKey))
	{
	alert('API Key must contain only letters, numbers and underscores');
	document.forms['Form'].ApiKey.focus();
	return false;
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Name = document.forms['Form'].Name.value;
	var TableName = document.forms['Form'].TableName.value;
	var Columns = document.forms['Form'].Columns.value;
	var Domain = document.forms['Form'].Domain.value;
	var Edit = document.forms['Form'].Edit.value;
	var MobileApiID = document.forms['Form'].MobileApiID.value;
	
	Load ('mobile-api.php?Name='+Name+'&TableName='+TableName+'&Columns='+Columns+'&ApiKey='+ApiKey+'&Domain='+Domain+'&MobileApiID='+MobileApiID+'&Edit='+Edit);
	
	return false;
	
}


function Api()
{
	var IP = document.forms['Form'].IP.value;

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Edit = document.forms['Form'].Edit.value;
	var ApiID = document.forms['Form'].ApiID.value;
	
	Load ('create-api.php?IP='+IP+'&ApiID='+ApiID+'&Edit='+Edit);
	
	return false;
	
}

function Package()
{
	var Name = document.forms['Form'].Name.value;
	var Filter  = /^[0-9a-zA-Z\.\_\-\ ]+$/;
	if (!Filter.test(Name))
	{
	alert('Incorrect package name');
	document.forms['Form'].Name.focus();
	return false;
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var DiskSpace = document.forms['Form'].DiskSpace.value;
	var Bandwidth = document.forms['Form'].Bandwidth.value;
	var FTPNo = document.forms['Form'].FTPNo.value;
	var EmailNo = document.forms['Form'].EmailNo.value;
	var DatabaseNo = document.forms['Form'].DatabaseNo.value;
	var SubDomainNo = document.forms['Form'].SubDomainNo.value;
	var AliasNo = document.forms['Form'].AliasNo.value;
	var AddonNo = document.forms['Form'].AddonNo.value;
	var PackageID = document.forms['Form'].PackageID.value;
	var Edit = document.forms['Form'].Edit.value;
	
	Load ('package.php?Name='+Name+'&DiskSpace='+DiskSpace+'&Bandwidth='+Bandwidth+'&FTPNo='+FTPNo+'&EmailNo='+EmailNo+'&DatabaseNo='+DatabaseNo+'&SubDomainNo='+SubDomainNo+'&AliasNo='+AliasNo+'&AddonNo='+AddonNo+'&PackageID='+PackageID+'&Edit='+Edit);
	
	return false;
	
}

function PackageInfo()
{	
http=Ajax();http.abort();
http.open('POST', 'ajax/package.php?Lng=en&PackageID='+document.getElementById('PackageID').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandlePackageInfo;
http.send('');
}

function HandlePackageInfo()
{
	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;

	var PackageArray = response.split("|");

	document.forms['Form'].DiskSpace.value=PackageArray[0];
	document.forms['Form'].Bandwidth.value=PackageArray[1];
	document.forms['Form'].FTPNo.value=PackageArray[2];
	document.forms['Form'].EmailNo.value=PackageArray[3];
	document.forms['Form'].DatabaseNo.value=PackageArray[4];
	document.forms['Form'].SubDomainNo.value=PackageArray[5];
	document.forms['Form'].AliasNo.value=PackageArray[6];
	document.forms['Form'].AddonNo.value=PackageArray[7];

	}
}


function Customer()
{
	var Name = document.forms['Form'].Name.value;	
	if(IsEmpty(Name))
	{
	alert('Please type customer name');
	document.forms['Form'].Name.focus();
	return false;
	}

	var Email = document.forms['Form'].Email.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(Email))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].Email.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Password = document.forms['Form'].Password.value;
	var Company = document.forms['Form'].Company.value;
	var Address = document.forms['Form'].Address.value;
	var City = document.forms['Form'].City.value;
	var ZipCode = document.forms['Form'].ZipCode.value;
	var Country = document.forms['Form'].Country.value;
	var Mobile = document.forms['Form'].Mobile.value;
	var CustomerID = document.forms['Form'].CustomerID.value;
	var Edit = document.forms['Form'].Edit.value;
	
	Load ('customer.php?Name='+Name+'&Email='+Email+'&Password='+Password+'&Company='+Company+'&Address='+Address+'&City='+City+'&ZipCode='+ZipCode+'&Country='+Country+'&Mobile='+Mobile+'&CustomerID='+CustomerID+'&Edit='+Edit);
	
	return false;
	
}


function VPS()
{

	var CustomerID = document.forms['Form'].CustomerID.value;

	var ServerIP = document.forms['Form'].ServerIP.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(ServerIP))
	{
	alert('Invalid IP Address');
	document.forms['Form'].ServerIP.focus();
	return false;
	}

	var ID = document.forms['Form'].ID.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(ID))
	{
	alert('Incorrect Container ID');
	document.forms['Form'].ID.focus();
	return false;
	}
	
	var MAC = document.forms['Form'].MAC.value;
	
	if(!IsEmpty(MAC))
	{
		var Filter = /^[0-9a-fA-F:]+$/;
		if (!(MAC.match(Filter)) || MAC.length != 17) 
		{
			alert("Invalid MAC Address");
			document.forms['Form'].MAC.focus();
			return false;
		}
		
	}

	var IP = document.forms['Form'].IP.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(IP))
	{
	alert('Invalid Container IP Address');
	document.forms['Form'].IP.focus();
	return false;
	}

	var Gateway = document.forms['Form'].Gateway.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(Gateway))
	{
	alert('Invalid Gateway IP Address');
	document.forms['Form'].IP.focus();
	return false;
	}

	var File = document.forms['Form'].File.value;

	var DiskType = document.forms['Form'].DiskType.value;
	if(IsEmpty(DiskType))
	{
	alert('Please Enter Disk Type');
	document.forms['Form'].DiskType.focus();
	return false;
	}

	var DiskSpace = document.forms['Form'].DiskSpace.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(DiskSpace))
	{
	alert('Incorrect Disk Space');
	document.forms['Form'].DiskSpace.focus();
	return false;
	}

	var Cores = document.forms['Form'].Cores.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(Cores))
	{
	alert('Incorrect Cores');
	document.forms['Form'].Cores.focus();
	return false;
	}
	
	var CIDR = document.forms['Form'].CIDR.value;
	
	var Memory = document.forms['Form'].Memory.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(Memory))
	{
	alert('Incorrect Memory');
	document.forms['Form'].Memory.focus();
	return false;
	}
	
	var Price = document.forms['Form'].Price.value;
	var Filter  = /^[0-9\.]+$/;
	if (!Filter.test(Price))
	{
	alert('Incorrect Price');
	document.forms['Form'].Price.focus();
	return false;
	}
	

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var Hostname = document.forms['Form'].Hostname.value;
	var VPSName = document.forms['Form'].VPSName.value;
	var PlanName = document.forms['Form'].PlanName.value;
	var ExpiresOn = document.forms['Form'].ExpiresOn.value;
	var VPSID = document.forms['Form'].VPSID.value;
	var Edit = document.forms['Form'].Edit.value;
	
 	Load ('vps.php?ID='+ID+'&ServerIP='+ServerIP+'&IP='+IP+'&CIDR='+CIDR+'&Gateway='+Gateway+'&MAC='+MAC+'&CustomerID='+CustomerID+'&File='+File+'&DiskType='+DiskType+'&DiskSpace='+DiskSpace+'&Cores='+Cores+'&Memory='+Memory+'&Hostname='+Hostname+'&VPSName='+VPSName+'&PlanName='+PlanName+'&Price='+Price+'&ExpiresOn='+ExpiresOn+'&VPSID='+VPSID+'&Edit='+Edit);
	
	return false;
	
}

function Server()
{

	var ServerName = document.forms['Form'].ServerName.value;
	if(IsEmpty(ServerName))
	{
	alert('Please type server name');
	document.forms['Form'].ServerName.focus();
	return false;
	}

	var ServerIP = document.forms['Form'].ServerIP.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(ServerIP))
	{
	alert('Invalid IP Address');
	document.forms['Form'].ServerIP.focus();
	return false;
	}
	

	var Subnet = document.forms['Form'].Subnet.value;
	var Filter  = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
	if (!Filter.test(Subnet))
	{
	alert('Invalid Subnet IP Address');
	document.forms['Form'].Subnet.focus();
	return false;
	}
	
	var CIDR = document.forms['Form'].CIDR.value;
	var Location = document.forms['Form'].Location.value;
	
	if(IsEmpty(Location))
	{
	alert('Please type server location');
	document.forms['Form'].Location.focus();
	return false;
	}
	
	var DiskType = document.forms['Form'].DiskType.value;
	if(IsEmpty(DiskType))
	{
	alert('Please Select Hard Disk Type');
	document.forms['Form'].DiskType.focus();
	return false;
	}
	
	var DiskSpace = document.forms['Form'].DiskSpace.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(DiskSpace))
	{
	alert('Incorrect Disk Space');
	document.forms['Form'].DiskSpace.focus();
	return false;
	}

	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var ServerID = document.forms['Form'].ServerID.value;
	var Edit = document.forms['Form'].Edit.value;

	var FormCheckbox = document.forms["Form"];
	var AllOptions = FormCheckbox.elements["AvailablePlan"];
	var SelectedOptions = [];
	AllOptions.forEach((Element) => 
	{
		if (Element.checked)
		{
		SelectedOptions.push(Element.value);
		}
	});
	
	var AvailablePlan = "|"+SelectedOptions.join("|")+"|";

 	Load ('server.php?ServerName='+ServerName+'&ServerIP='+ServerIP+'&Subnet='+Subnet+'&CIDR='+CIDR+'&Location='+Location+'&DiskType='+DiskType+'&DiskSpace='+DiskSpace+'&AvailablePlan='+AvailablePlan+'&ServerID='+ServerID+'&Edit='+Edit);
	
	return false;
	
}



function Plan()
{
	var PlanName = document.forms['Form'].PlanName.value;
	var Location = document.forms['Form'].Location.value;
	
	if(IsEmpty(PlanName))
	{
	alert('Please type plan name');
	document.forms['Form'].PlanName.focus();
	return false;
	}
	

	if(IsEmpty(Location))
	{
	alert('Please type location');
	document.forms['Form'].Location.focus();
	return false;
	}

	
	var DiskType = document.forms['Form'].DiskType.value;
	if(IsEmpty(DiskType))
	{
	alert('Please select Disk Type');
	document.forms['Form'].DiskType.focus();
	return false;
	}
	
	var DiskSpace = document.forms['Form'].DiskSpace.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(DiskSpace))
	{
	alert('Incorrect Disk Space');
	document.forms['Form'].DiskSpace.focus();
	return false;
	}

	var Cores = document.forms['Form'].Cores.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(Cores))
	{
	alert('Incorrect Cores');
	document.forms['Form'].Cores.focus();
	return false;
	}
	
	var Memory = document.forms['Form'].Memory.value;
	var Filter  = /^[0-9]+$/;
	if (!Filter.test(Memory))
	{
	alert('Incorrect Memory');
	document.forms['Form'].Memory.focus();
	return false;
	}
	
	var Price = document.forms['Form'].Price.value;
	var Filter  = /^[0-9\.]+$/;
	if (!Filter.test(Price))
	{
	alert('Incorrect Price');
	document.forms['Form'].Price.focus();
	return false;
	}
	
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var PlanID = document.forms['Form'].PlanID.value;
	var Edit = document.forms['Form'].Edit.value;
	
	Load ('plan.php?PlanName='+PlanName+'&Location='+Location+'&DiskType='+DiskType+'&DiskSpace='+DiskSpace+'&Cores='+Cores+'&Memory='+Memory+'&Price='+Price+'&PlanID='+PlanID+'&Edit='+Edit);
	
	return false;
	
}

function SetPlan()
{
	var PlanString = document.forms['Form'].Plan.value;
	var PlanArray = PlanString.split("|");
	
	document.forms['Form'].PlanName.value=PlanArray[1];
	document.forms['Form'].DiskType.value=PlanArray[2];
	document.forms['Form'].DiskSpace.value=PlanArray[3];
	document.forms['Form'].Cores.value=PlanArray[4];
	document.forms['Form'].Memory.value=PlanArray[5];
	document.forms['Form'].Price.value=PlanArray[6];
	
}


function BackupDestination()
{

	if (document.forms['Form'].Destination.value=="HOMEDIR" || document.forms['Form'].Destination.value=="URL")
	{
	document.getElementById('RemoteServer').style.display='none';
	document.getElementById('RemoteUser').style.display='none';
	document.getElementById('RemotePassword').style.display='none';
	document.getElementById('RemoteDir').style.display='none';
	}
	else
	{
	document.getElementById('RemoteServer').style.display='';
	document.getElementById('RemoteUser').style.display='';
	document.getElementById('RemotePassword').style.display='';
	document.getElementById('RemoteDir').style.display='';
	}

}


function ContactInformation()
{

	var Email = document.forms['Form'].Email.value;
	var Filter  = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	if (!Filter.test(Email))
	{
	alert('Incorrect Email Address');
	document.forms['Form'].Email.focus();
	return false;
	}

	var FullName = document.forms['Form'].FullName.value;
	var MobNo = document.forms['Form'].MobNo.value;

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('awspanel.php?Email='+Email+'&FullName='+FullName+'&MobNo='+MobNo+'&ControlID='+ControlID,ControlID);
	
	return false;
	
}

function Template()
{
		
	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	var DefaultWebsitePageCode = editAreaLoader.getValue('DefaultWebsitePageCode');
	var AccountSuspendedCode = editAreaLoader.getValue('AccountSuspendedCode');
	var DiskQuotaExceededCode = editAreaLoader.getValue('DiskQuotaExceededCode');
	var BandwidthLimitExceededCode = editAreaLoader.getValue('BandwidthLimitExceededCode');
	var AccountUnpublishedCode = editAreaLoader.getValue('AccountUnpublishedCode');
	var HostingExpiredCode = editAreaLoader.getValue('HostingExpiredCode');

	
	http=Ajax();http.abort();
	http.open("POST", "template.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelPost;
	http.send('DefaultWebsitePageCode='+DefaultWebsitePageCode+'&AccountSuspendedCode='+AccountSuspendedCode+'&DiskQuotaExceededCode='+DiskQuotaExceededCode+'&BandwidthLimitExceededCode='+BandwidthLimitExceededCode+'&AccountUnpublishedCode='+AccountUnpublishedCode+'&HostingExpiredCode='+HostingExpiredCode+'&ControlID='+ControlID);
		
	return false;

}


function CopyFiles()
{

	var From = document.forms['Form'].From.value;
	var To = document.forms['Form'].To.value;
	
	if (From==To)
	{
	alert('Can\'t copy files to same user account');
	document.forms['Form'].To.focus();
	return false;
	}

	document.getElementById('DivSubmit').innerHTML = '<img class=\'preloader-image\' src=\'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2ZXJzaW9uPSIxLjEiIHN0eWxlPSItLWFuaW1hdGlvbi1zdGF0ZTpydW5uaW5nOyI+CiAgICAgIDxzdHlsZT4KICAgICAgICA6cm9vdCB7CiAgICAgICAgICAtLWFuaW1hdGlvbi1zdGF0ZTogcGF1c2VkOwogICAgICAgIH0KCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSB3aGVyZSB0aGUgInJlZ3VsYXIiIHNjaGVtZSBpcyBkYXJrICovCiAgICAgICAgLyogdXNlciBwaWNrZWQgYSB0aGVtZSBhIGxpZ2h0IHNjaGVtZSBhbmQgYWxzbyBlbmFibGVkIGEgZGFyayBzY2hlbWUgKi8KCiAgICAgICAgLyogZGVhbCB3aXRoIGxpZ2h0IHNjaGVtZSBmaXJzdCAqLwogICAgICAgIEBtZWRpYSAocHJlZmVycy1jb2xvci1zY2hlbWU6IGxpZ2h0KSB7CiAgICAgICAgICA6cm9vdCB7CiAgICAgICAgICAgIC0tcHJpbWFyeTogIzIyMjIyMjsKICAgICAgICAgICAgLS1zZWNvbmRhcnk6ICNmZmZmZmY7CiAgICAgICAgICAgIC0tdGVydGlhcnk6ICMyNDY4YzE7CiAgICAgICAgICAgIC0tcXVhdGVybmFyeTogI2U0NTczNTsKICAgICAgICAgICAgLS1oaWdobGlnaHQ6ICNmZmZmNGQ7CiAgICAgICAgICAgIC0tc3VjY2VzczogIzAwOTkwMDsKICAgICAgICAgIH0KICAgICAgICB9CgogICAgICAgIC8qIHRoZW4gZGVhbCB3aXRoIGRhcmsgc2NoZW1lICovCiAgICAgICAgQG1lZGlhIChwcmVmZXJzLWNvbG9yLXNjaGVtZTogZGFyaykgewogICAgICAgICAgOnJvb3QgewogICAgICAgICAgICAtLXByaW1hcnk6ICMyMjIyMjI7CiAgICAgICAgICAgIC0tc2Vjb25kYXJ5OiAjZmZmZmZmOwogICAgICAgICAgICAtLXRlcnRpYXJ5OiAjMjQ2OGMxOwogICAgICAgICAgICAtLXF1YXRlcm5hcnk6ICNlNDU3MzU7CiAgICAgICAgICAgIC0taGlnaGxpZ2h0OiAjZmZmZjRkOwogICAgICAgICAgICAtLXN1Y2Nlc3M6ICMwMDk5MDA7CiAgICAgICAgICB9CiAgICAgICAgfQoKICAgICAgICAvKiB0aGVzZSBzdHlsZXMgbmVlZCB0byBsaXZlIGhlcmUgYmVjYXVzZSB0aGUgU1ZHIGhhcyBhIGRpZmZlcmVudCBzY29wZSAqLwogICAgICAgIC5kb3RzIHsKICAgICAgICAgIGFuaW1hdGlvbi1uYW1lOiBsb2FkZXI7CiAgICAgICAgICBhbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOiBlYXNlLWluLW91dDsKICAgICAgICAgIGFuaW1hdGlvbi1kdXJhdGlvbjogM3M7CiAgICAgICAgICBhbmltYXRpb24taXRlcmF0aW9uLWNvdW50OiBpbmZpbml0ZTsKICAgICAgICAgIGFuaW1hdGlvbi1wbGF5LXN0YXRlOiB2YXIoLS1hbmltYXRpb24tc3RhdGUpOwogICAgICAgICAgc3Ryb2tlOiAjZmZmOwogICAgICAgICAgc3Ryb2tlLXdpZHRoOiAwLjVweDsKICAgICAgICAgIHRyYW5zZm9ybS1vcmlnaW46IGNlbnRlcjsKICAgICAgICAgIG9wYWNpdHk6IDA7CiAgICAgICAgICByOiBtYXgoMXZ3LCAxMXB4KTsKICAgICAgICAgIGN5OiA1MCU7CiAgICAgICAgICBmaWx0ZXI6IHNhdHVyYXRlKDIpIG9wYWNpdHkoMC44NSk7CiAgICAgICAgfQoKICAgICAgICAuZG90czpmaXJzdC1jaGlsZCB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCgyKSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS1xdWF0ZXJuYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xNXM7CiAgICAgICAgfQoKICAgICAgICAuZG90czpudGgtY2hpbGQoMykgewogICAgICAgICAgZmlsbDogdmFyKC0taGlnaGxpZ2h0KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4zczsKICAgICAgICB9CgogICAgICAgIC5kb3RzOm50aC1jaGlsZCg0KSB7CiAgICAgICAgICBmaWxsOiB2YXIoLS10ZXJ0aWFyeSk7CiAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuNDVzOwogICAgICAgIH0KCiAgICAgICAgLmRvdHM6bnRoLWNoaWxkKDUpIHsKICAgICAgICAgIGZpbGw6IHZhcigtLXRlcnRpYXJ5KTsKICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC42czsKICAgICAgICB9CgogICAgICAgIEBrZXlmcmFtZXMgbG9hZGVyIHsKICAgICAgICAgIDAlIHsKICAgICAgICAgICAgb3BhY2l0eTogMDsKICAgICAgICAgICAgdHJhbnNmb3JtOiBzY2FsZSgxKTsKICAgICAgICAgIH0KICAgICAgICAgIDQ1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDY1JSB7CiAgICAgICAgICAgIG9wYWNpdHk6IDE7CiAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUoMC43KTsKICAgICAgICAgIH0KICAgICAgICAgIDEwMCUgewogICAgICAgICAgICBvcGFjaXR5OiAwOwogICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlKDEpOwogICAgICAgICAgfQogICAgICAgIH0KICAgICAgPC9zdHlsZT4KCiAgICAgIDxnIGNsYXNzPSJjb250YWluZXIiPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSIzMHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjQwdnciLz4KICAgICAgICA8Y2lyY2xlIGNsYXNzPSJkb3RzIiBjeD0iNTB2dyIvPgogICAgICAgIDxjaXJjbGUgY2xhc3M9ImRvdHMiIGN4PSI2MHZ3Ii8+CiAgICAgICAgPGNpcmNsZSBjbGFzcz0iZG90cyIgY3g9IjcwdnciLz4KICAgICAgPC9nPgogICAgPC9zdmc+\'>';

	Load ('copywww.php?From='+From+'&To='+To,ControlID);
	
	return false;
	
}



function Switch()
{
	var Username = document.getElementById('SwitchUsername').value;
	
	http=Ajax();http.abort();
	http.open("POST", "ajax/switch.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelSwitch;
	http.send('Username='+Username);
		
	return false;

}

function HandelSwitch()
{

	if (http.readyState == 4)
	{
		var response = http.responseText;
		if (response==1)
		{
		location.reload();
		}
	}
}


function AdminEmail()
{
	var Domain = document.forms['Form'].Domain.value;
	
	http=Ajax();http.abort();
	http.open("POST", "ajax/admin-email.php",true);
	http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
	http.onreadystatechange = HandelAdminEmail;
	http.send('Domain='+Domain);
		
	return false;

}

function HandelAdminEmail()
{

	if (http.readyState == 4)
	{
		var response = http.responseText;
		document.getElementById('Email').value=response;
		
	}
}

function FTPDirectory()
{
Domain=document.getElementById('Domain').value;

http=Ajax();http.abort();
http.open("POST", "ajax/ftp.php",true);
http.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
http.onreadystatechange = HandelFTPDirectory;
http.send('Domain='+Domain);
}

function HandelFTPDirectory()
{

	if (http.readyState == 4)
	{
		var response = http.responseText;
		document.getElementById('Directory').value=response;
	}
}


function Update()
{
	document.getElementById('Update').innerHTML='Please wait...';
	Load('update.php')
}


function DropdownButton(ButtonID) 
{
  document.getElementById(ButtonID).classList.toggle("show");
}

// Close the DropdownButton menu if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {
    var DropdownButtons = document.getElementsByClassName("DropdownButtonContent");
    var i;
    for (i = 0; i < DropdownButtons.length; i++) {
      var openDropdownButton = DropdownButtons[i];
      if (openDropdownButton.classList.contains('show')) {
        openDropdownButton.classList.remove('show');
      }
    }
  }
}

function GenerateUsername()
{

	var Username = document.forms['Form'].Domain.value;

	if (Username.length <= 32) 
	{
	document.forms['Form'].Username.value=Username; 
	return;
	}
	else
	{
	var UsernameArray = Username.split(".");
	}
	
	if (UsernameArray.length==2)
	{
	Username=UsernameArray[0];
	}
	
	if (UsernameArray.length==3)
	{
	Username=UsernameArray[1];
	}
	
	if (Username.length<=32)
	{
	
		if (Username.match("-"))
		{
			var UsernameArray = Username.split("-");
			
			if (UsernameArray[0].length<=UsernameArray[1].length)
			{
			Username=UsernameArray[0];
			}
			else
			{
			Username=UsernameArray[1];
			}
			
			document.forms['Form'].Username.value=Username;
			return;		
		}
		else
		{
		document.forms['Form'].Username.value=Username;
		return;
		}
		
	}
	else
	{

		if (Username.match("-"))
		{
			var UsernameArray = Username.split("-");
			
			if (UsernameArray[0].length<=UsernameArray[1].length)
			{
			Username=UsernameArray[0];
			}
			else
			{
			Username=UsernameArray[1];
			}
			
			if (Username.length<=32)
			{
			document.forms['Form'].Username.value=Username;
			return;			
			}
			else
			{

				Username=Username.substr(0, 32);
				document.forms['Form'].Username.value=Username;
				return;	

			}
		
		}
		else
		{

			Username=Username.substr(0, 32);
			document.forms['Form'].Username.value=Username;
			return;		

		}
	
	}


}


function SetDirectory()
{

	var WWWPath=document.forms['Form'].WWWPath.value;
	document.forms['Form'].Directory.value=WWWPath;

	$( '#container' ).html( '<ul class="filetree start"><li class="wait">' + 'Generating Tree...' + '<li></ul>' );	
	getfilelist( $('#container') , WWWPath);
	function getfilelist(cont,root)
	{
	
		$( cont ).addClass( 'wait' );
			
		$.post('tree-d.php', { dir: root }, function(data) 
		{
	
			$( cont ).find( '.start' ).html('');
			$( cont ).removeClass( 'wait' ).append( data );
			if( 'Sample' == root ) 
				$( cont ).find('UL:hidden').show();
			else 
				$( cont ).find('UL:hidden').slideDown({ duration: 500, easing: null });
			
		});
	}
	
	$( '#container' ).on('click', 'LI A', function() 
	{
		var entry = $(this).parent();
		
		if( entry.hasClass('folder') ) 
		{
			if( entry.hasClass('collapsed') ) 
			{
				entry.find('UL').remove();
				getfilelist( entry, escape( $(this).attr('rel') ));
				entry.removeClass('collapsed').addClass('expanded');
			}
			else 
			{
				entry.find('UL').slideUp({ duration: 500, easing: null });
				entry.removeClass('expanded').addClass('collapsed');
			}
			
			document.forms['Form'].Directory.value=$(this).attr('rel');
			
		}
		
	return false;
	});


}

function Container()
{
http=Ajax();http.abort();
http.open('POST', 'ajax/container.php?Lng=en&ServerIP='+document.getElementById('ServerIP').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleContainer;
http.send('');
}

function HandleContainer()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	document.getElementById('ID').value = response;
	
	GetPlan();
	}
}







function GetPlan()
{
http=Ajax();http.abort();
http.open('POST', 'ajax/plan.php?Lng=en&ServerIP='+document.getElementById('ServerIP').value,true);
http.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
http.onreadystatechange = HandleGetPlan;
http.send('');
}

function HandleGetPlan()
{

	if (http.readyState == 1)
	{
	
	}

	if (http.readyState == 4)
	{
	var response = http.responseText;
	document.getElementById('DivPlan').innerHTML = response;
	}
}





const Copy = str => {
  const el = document.createElement('textarea');
  el.value = str;
  document.body.appendChild(el);
  el.select();
  document.execCommand('copy');
  document.body.removeChild(el);
};







document.addEventListener('DOMContentLoaded', function() {
  const TdLeft = document.querySelector('.TdLeft');
  let isDragging = false;
  let startX, startWidth;

  TdLeft.addEventListener('mousedown', function(e) {
    const rect = TdLeft.getBoundingClientRect();
    if (e.clientX > rect.right - 10) {
      isDragging = true;
      startX = e.clientX;
      startWidth = parseInt(document.defaultView.getComputedStyle(TdLeft).width, 10);
      e.preventDefault();
    }
  });

  document.addEventListener('mousemove', function(e) {
    if (!isDragging) return;
    const newWidth = startWidth + e.clientX - startX;
    TdLeft.style.width = newWidth + 'px';
  });

  document.addEventListener('mouseup', function() {
    isDragging = false;
  });
});
