<?php
// ملف يستدعى مرة مع كل خدمة لزرع التمبلت الاضافية الخاصة بالخدمة إن وجدت

// فى حالة استدعاة الملف من لوحة تحكم الادمن لزرع تملت خدمة واحدة
if ($SetupOneService==1)
{
	// يتم استعداء الملف هكذا
	// http://nileestate.com/install/key.php?SetupOneService=1&Service=Property&Theme=default
	
	include("../include/config/config.php");
	
	
	
	
	include("verify.php");
}

$EnFolderPath="../module/$LService/theme/$ThemeFolder/html/en";



$Files=@dir("$EnFolderPath");
if ($Files)
{
	
	While ($FileName = $Files->read())
	{
		$EnTemplate="";
		$ArTemplate="";
		
		$L=StrLen($FileName)-5;
		
		
		
		
		if (strtolower(SubStr($FileName,$L,5))==".html")
		{
			echo "Restore $FileName...<br />";	
			
			$FileNameArray=explode(".",$FileName);
			

			

			
			$TKey=$FileNameArray[0];
			
			$EnFilePath="../module/$LService/theme/$ThemeFolder/html/en/$FileName";
			$FILE =fopen("$EnFilePath", "r");
			if ($FILE)
			{	
				
				while (!feof($FILE)) 
				{
					$EnTemplate .= fread($FILE, 8192);
				}
				
				fclose($FILE);							
				
			}
			
			$ArFilePath="../module/$LService/theme/$ThemeFolder/html/ar/$FileName";
			$FILE =@fopen("$ArFilePath", "r");
			if ($FILE)
			{	
				while (!feof($FILE)) 
				{
					$ArTemplate .= fread($FILE, 8192);
				}
				
				fclose($FILE);							
			}
			
			$EnTemplate=addslashes($EnTemplate);
			$ArTemplate=addslashes($ArTemplate);
			
			if ($ArTemplate=="") {$ArTemplate=$EnTemplate;}
			
			$OptionPath="../module/$LService/theme/$ThemeFolder/html/option/$TKey.php";
			$X=@include($OptionPath);
			
			$TKeyFound=0;
			$Sql = "select * from $Prefix".$Service."Template where TKey='$TKey' and Theme='$ThemeFolder'";
			$Result = SQL($Sql);
			foreach ($Result as $Row)
			{
				$TKeyFound=1;
			}
			
			if ($TKeyFound==0)
			{
				$Sql = "INSERT INTO $Prefix".$Service."Template (TKey,DisplayOption,EnTemplate,ArTemplate,Theme) VALUES ('$TKey','$DisplayOption','$EnTemplate','$ArTemplate','$ThemeFolder')";
				$Result = SQL($Sql);
			}
			
			if ($TKeyFound==1)
			{
				$Sql = "UPDATE $Prefix".$Service."Template TKey='$TKey',DisplayOption='$DisplayOption',EnTemplate='$EnTemplate',ArTemplate='$ArTemplate',Theme='$ThemeFolder' where TKey='$TKey' and Theme='$ThemeFolder'";
				$Result = SQL($Sql);			
			}
			
		}
	}
	
}

?>