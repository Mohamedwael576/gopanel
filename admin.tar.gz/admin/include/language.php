<?php

	if ($Service=="" or $LService=="")
	{
	$LService=$DefaultService;
	$Service=ucfirst($LService);
	}
	
	if ($Theme=="")
	{
		$Sql = "select * from Service where Service='$Service'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
			$Theme=$Row['Theme'];
		}
	}
	
	// generate language files
	$EnFile=@fopen("../module/$LService/language/en.php","w");
	$FrFile=@fopen("../module/$LService/language/fr.php","w");
	$DeFile=@fopen("../module/$LService/language/de.php","w");
	$ItFile=@fopen("../module/$LService/language/it.php","w");
	$EsFile=@fopen("../module/$LService/language/es.php","w");
	$RuFile=@fopen("../module/$LService/language/ru.php","w");
	$ArFile=@fopen("../module/$LService/language/ar.php","w");
	
	$SettingsFile=@fopen("../module/$LService/language/settings.php","w");
	
	fputs($EnFile,"<?php\n");
	fputs($FrFile,"<?php\n");
	fputs($DeFile,"<?php\n");
	fputs($ItFile,"<?php\n");
	fputs($EsFile,"<?php\n");
	fputs($RuFile,"<?php\n");
	fputs($ArFile,"<?php\n");
	fputs($SettingsFile,"<?php\n");
	$Sql = "select * from $Prefix".$Service."Variable where VariableID>=1 and (Theme='All' or Theme='$Theme') order by VariableID ASC";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		// En
		$Value=$Row['En'];
		$Value=str_replace("[Theme]",$Theme,$Value);
		$Value=str_replace("[ScriptUrl]",$ScriptUrl,$Value);
		$Value=str_replace("[Service]",$Service,$Value);
		$Value=str_replace("[LService]",$LService,$Value);
		$Value=str_replace("[Company]",$_SESSION[Company],$Value);
		$Value=str_replace("[Lng]",$Lng,$Value);
		$Value=str_replace('"','\"',$Value);
		fputs($EnFile,"\$LNG['{$Row['Variable']}']=\"$Value\";\n");
		
		// Fr
		$Value=$Row['Fr'];
		$Value=str_replace("[Theme]",$Theme,$Value);
		$Value=str_replace("[ScriptUrl]",$ScriptUrl,$Value);
		$Value=str_replace("[Service]",$Service,$Value);
		$Value=str_replace("[LService]",$LService,$Value);
		$Value=str_replace("[Company]",$_SESSION[Company],$Value);
		$Value=str_replace("[Lng]",$Lng,$Value);
		$Value=str_replace('"','\"',$Value);
		fputs($FrFile,"\$LNG['{$Row['Variable']}']=\"$Value\";\n");
		
		// De
		$Value=$Row['De'];
		$Value=str_replace("[Theme]",$Theme,$Value);
		$Value=str_replace("[ScriptUrl]",$ScriptUrl,$Value);
		$Value=str_replace("[Service]",$Service,$Value);
		$Value=str_replace("[LService]",$LService,$Value);
		$Value=str_replace("[Company]",$_SESSION[Company],$Value);
		$Value=str_replace("[Lng]",$Lng,$Value);
		$Value=str_replace('"','\"',$Value);
		fputs($DeFile,"\$LNG['{$Row['Variable']}']=\"$Value\";\n");
		
		// It
		$Value=$Row['It'];
		$Value=str_replace("[Theme]",$Theme,$Value);
		$Value=str_replace("[ScriptUrl]",$ScriptUrl,$Value);
		$Value=str_replace("[Service]",$Service,$Value);
		$Value=str_replace("[LService]",$LService,$Value);
		$Value=str_replace("[Company]",$_SESSION[Company],$Value);
		$Value=str_replace("[Lng]",$Lng,$Value);
		$Value=str_replace('"','\"',$Value);
		fputs($ItFile,"\$LNG['{$Row['Variable']}']=\"$Value\";\n");
		
		// Es
		$Value=$Row['Es'];
		$Value=str_replace("[Theme]",$Theme,$Value);
		$Value=str_replace("[ScriptUrl]",$ScriptUrl,$Value);
		$Value=str_replace("[Service]",$Service,$Value);
		$Value=str_replace("[LService]",$LService,$Value);
		$Value=str_replace("[Company]",$_SESSION[Company],$Value);
		$Value=str_replace("[Lng]",$Lng,$Value);
		$Value=str_replace('"','\"',$Value);
		fputs($EsFile,"\$LNG['{$Row['Variable']}']=\"$Value\";\n");
		
		// Ru
		$Value=$Row['Ru'];
		$Value=str_replace("[Theme]",$Theme,$Value);
		$Value=str_replace("[ScriptUrl]",$ScriptUrl,$Value);
		$Value=str_replace("[Service]",$Service,$Value);
		$Value=str_replace("[LService]",$LService,$Value);
		$Value=str_replace("[Company]",$_SESSION[Company],$Value);
		$Value=str_replace("[Lng]",$Lng,$Value);
		$Value=str_replace('"','\"',$Value);
		fputs($RuFile,"\$LNG['{$Row['Variable']}']=\"$Value\";\n");
		
		// Ar
		$Value=$Row['Ar'];
		$Value=str_replace("[Theme]",$Theme,$Value);
		$Value=str_replace("[ScriptUrl]",$ScriptUrl,$Value);
		$Value=str_replace("[Service]",$Service,$Value);
		$Value=str_replace("[LService]",$LService,$Value);
		$Value=str_replace("[Company]",$_SESSION[Company],$Value);
		$Value=str_replace("[Lng]",$Lng,$Value);
		$Value=str_replace('"','\"',$Value);
		fputs($ArFile,"\$LNG['{$Row['Variable']}']=\"$Value\";\n");
		
	}
	
		fputs($SettingsFile,"\$Theme=\"$Theme\";\n");
		fputs($SettingsFile,"\$Theme=\"$Theme\";\n");
		fputs($SettingsFile,"\$Theme=\"$Theme\";\n");
		fputs($SettingsFile,"\$Theme=\"$Theme\";\n");
		fputs($SettingsFile,"\$Theme=\"$Theme\";\n");
		fputs($SettingsFile,"\$Theme=\"$Theme\";\n");
		fputs($SettingsFile,"\$Theme=\"$Theme\";\n");
	
	// Settings 

	$Sql = "select * from Config where ConfigID='1'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		fputs($SettingsFile,"\$Company=\"{$Row['Company']}\";\n");
		fputs($SettingsFile,"\$CompanyAddress=\"{$Row['CompanyAddress']}\";\n");
		fputs($SettingsFile,"\$CompanyDescription=\"{$Row['CompanyDescription']}\";\n");
		fputs($SettingsFile,"\$CompanyMobNo=\"{$Row['CompanyMobNo']}\";\n");
		fputs($SettingsFile,"\$AdminMobNo=\"{$Row['AdminMobNo']}\";\n");
		fputs($SettingsFile,"\$CompanyHotline=\"{$Row['CompanyHotline']}\";\n");
		
		$CompanyMap=str_replace('"',"'",$Row['CompanyMap']);
		fputs($SettingsFile,"\$CompanyMap=\"$CompanyMap\";\n");
		fputs($SettingsFile,"\$AdminEmail=\"{$Row['AdminEmail']}\";\n");
		
		

			if ($Row['SocialNetwork']!="")
			{
				
				$SocialNetwork=explode("|",$Row['SocialNetwork']);

				fputs($SettingsFile,"\$Facebook=\"$SocialNetwork[0]\";\n");
				fputs($SettingsFile,"\$Twitter=\"$SocialNetwork[1]\";\n");
				fputs($SettingsFile,"\$LinkedIn=\"$SocialNetwork[2]\";\n");
				fputs($SettingsFile,"\$MySpace=\"$SocialNetwork[3]\";\n");
				fputs($SettingsFile,"\$GooglePlus=\"$SocialNetwork[4]\";\n");
				fputs($SettingsFile,"\$Vimeo=\"$SocialNetwork[5]\";\n");
				fputs($SettingsFile,"\$Flickr=\"$SocialNetwork[6]\";\n");
				fputs($SettingsFile,"\$StumbleUpon=\"$SocialNetwork[7]\";\n");
				fputs($SettingsFile,"\$Reddit=\"$SocialNetwork[8]\";\n");
				fputs($SettingsFile,"\$Delicious=\"$SocialNetwork[9]\";\n");
				fputs($SettingsFile,"\$Technorati=\"$SocialNetwork[10]\";\n");
				fputs($SettingsFile,"\$DeviantArt=\"$SocialNetwork[11]\";\n");
				fputs($SettingsFile,"\$LiveJournal=\"$SocialNetwork[12]\";\n");
				fputs($SettingsFile,"\$Orkut=\"$SocialNetwork[13]\";\n");
				fputs($SettingsFile,"\$Pinterest=\"$SocialNetwork[14]\";\n");
				fputs($SettingsFile,"\$Ning=\"$SocialNetwork[15]\";\n");
				fputs($SettingsFile,"\$Meetup=\"$SocialNetwork[16]\";\n");
				fputs($SettingsFile,"\$Badoo=\"$SocialNetwork[17]\";\n");
				fputs($SettingsFile,"\$Youtube=\"$SocialNetwork[18]\";\n");
				fputs($SettingsFile,"\$Blog=\"$SocialNetwork[19]\";\n");
				fputs($SettingsFile,"\$SocialIconSize=\"$SocialNetwork[20]\";\n");
				fputs($SettingsFile,"\$FacebookApiID=\"$SocialNetwork[21]\";\n");
				fputs($SettingsFile,"\$FacebookAppSecret=\"$SocialNetwork[22]\";\n");
				fputs($SettingsFile,"\$TwitterConsumerKey=\"$SocialNetwork[23]\";\n");
				fputs($SettingsFile,"\$TwitterConsumerSecret=\"$SocialNetwork[24]\";\n");



			}
		
	}


	$Sql = "select * from $Prefix".$Service."Info where Theme='$Theme'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{

		fputs($SettingsFile,"\$ActiveValue=\"{$Row['ActiveValue']}\";\n");
		fputs($SettingsFile,"\$RelatedNewsMax=\"{$Row['RelatedNewsMax']}\";\n");
		fputs($SettingsFile,"\$MoreNewsMax=\"{$Row['MoreNewsMax']}\";\n");
		fputs($SettingsFile,"\$NewsFlashMax=\"{$Row['NewsFlashMax']}\";\n");
		fputs($SettingsFile,"\$SessionAttributedUserID=\"{$Row['SessionAttributedUserID']}\";\n");
		fputs($SettingsFile,"\$ActiveFollow=\"{$Row['ActiveFollow']}\";\n");
		fputs($SettingsFile,"\$ActiveLinkID=\"{$Row['ActiveLinkID']}\";\n");
		fputs($SettingsFile,"\$SEO=\"{$Row['SEO']}\";\n");
		fputs($SettingsFile,"\$Language=\"{$Row['Language']}\";\n");
		fputs($SettingsFile,"\$WODesign=\"{$Row['WODesign']}\";\n");
		fputs($SettingsFile,"\$MOT=\"{$Row['MOT']}\";\n");
		fputs($SettingsFile,"\$LinkBarDesign=\"{$Row['LinkBarDesign']}\";\n");
		fputs($SettingsFile,"\$LinkBarLogin=\"{$Row['LinkBarLogin']}\";\n");
		fputs($SettingsFile,"\$ExtraSearch=\"{$Row['ExtraSearch']}\";\n");
		fputs($SettingsFile,"\$SearchTypeValue=\"{$Row['SearchTypeValue']}\";\n");

		

		
		if ($Row['LinkBarLogin']==1)
		{
			fputs($SettingsFile,"\$LinkBarWidth=\"75%\";\n");
		}
		else
		{
			fputs($SettingsFile,"\$LinkBarWidth=\"100%\";\n");
		}
		
		fputs($SettingsFile,"\$ActiveSearchHistory=\"{$Row['ActiveSearchHistory']}\";\n");
		fputs($SettingsFile,"\$ActiveSearchBar=\"{$Row['ActiveSearchBar']}\";\n");
		fputs($SettingsFile,"\$ActiveLetterBar=\"{$Row['ActiveLetterBar']}\";\n");
		fputs($SettingsFile,"\$ActiveLinkBar=\"{$Row['ActiveLinkBar']}\";\n");
		fputs($SettingsFile,"\$ActiveLinkBar=\"{$Row['ActiveLinkBar']}\";\n");
		fputs($SettingsFile,"\$UserAccess=\"{$Row['UserAccess']}\";\n");
		fputs($SettingsFile,"\$CacheSystem=\"{$Row['CacheSystem']}\";\n");
		fputs($SettingsFile,"\$CacheExpire=\"{$Row['CacheExpire']}\";\n");
		fputs($SettingsFile,"\$PageNo=\"{$Row['PageNo']}\";\n");
		fputs($SettingsFile,"\$PageBarNo=\"{$Row['PageBarNo']}\";\n");
		fputs($SettingsFile,"\$PageBreak=\"{$Row['PageBreak']}\";\n");
		fputs($SettingsFile,"\$ShowWidth=\"{$Row['ShowWidth']}\";\n");
		fputs($SettingsFile,"\$ShowHeight=\"{$Row['ShowHeight']}\";\n");

		$ColumnOption=explode("|",$Row['ColumnOption']);
		fputs($SettingsFile,"\$ColumnHome=\"$ColumnOption[0]\";\n");
		fputs($SettingsFile,"\$ColumnCategory=\"$ColumnOption[1]\";\n");
		fputs($SettingsFile,"\$ColumnList=\"$ColumnOption[2]\";\n");

		$WatermarkOption=explode("|",$Row['WatermarkOption']);
		fputs($SettingsFile,"\$WatermarkType=\"$WatermarkOption[0]\";\n");
		fputs($SettingsFile,"\$WatermarkText=\"$WatermarkOption[1]\";\n");
		fputs($SettingsFile,"\$WatermarkColor=\"$WatermarkOption[2]\";\n");
		fputs($SettingsFile,"\$WatermarkBgcolor=\"$WatermarkOption[3]\";\n");
		fputs($SettingsFile,"\$WatermarkPosition=\"$WatermarkOption[4]\";\n");
		fputs($SettingsFile,"\$WatermarkFileName=\"$WatermarkOption[5]\";\n");
		

		$SectionDisplayOption=explode("|",$Row['SectionDisplayOption']);
		fputs($SettingsFile,"\$SectionDisplay=\"$SectionDisplayOption[0]\";\n");
		fputs($SettingsFile,"\$SectionDisplayTab=\"$SectionDisplayOption[1]\";\n");
		fputs($SettingsFile,"\$SectionDisplayMethod=\"$SectionDisplayOption[2]\";\n");
		fputs($SettingsFile,"\$SectionDisplayFieldsetLimit=\"$SectionDisplayOption[3]\";\n");
		fputs($SettingsFile,"\$SectionDisplayFieldsetImage=\"$SectionDisplayOption[4]\";\n");
		fputs($SettingsFile,"\$SectionDisplayAlign=\"$SectionDisplayOption[5]\";\n");
		
		fputs($SettingsFile,"\$SectionDisplayItemNo=\"$SectionDisplayOption[6]\";\n");
		fputs($SettingsFile,"\$SectionDisplayItemNoFontColor=\"$SectionDisplayOption[7]\";\n");
		fputs($SettingsFile,"\$SectionDisplayBulet=\"$SectionDisplayOption[8]\";\n");
		fputs($SettingsFile,"\$SectionDisplayViewing=\"$SectionDisplayOption[9]\";\n");
		fputs($SettingsFile,"\$SectionDisplayDotLine=\"$SectionDisplayOption[10]\";\n");
		fputs($SettingsFile,"\$SectionDisplaySubSections=\"$SectionDisplayOption[11]\";\n");
		fputs($SettingsFile,"\$SectionDisplaySubSectionsLimit=\"$SectionDisplayOption[12]\";\n");
		fputs($SettingsFile,"\$SectionDisplayCategories=\"$SectionDisplayOption[13]\";\n");
		fputs($SettingsFile,"\$SectionDisplayCategoriesLimit=\"$SectionDisplayOption[14]\";\n");
		fputs($SettingsFile,"\$SectionDisplayCategoriesCommaRow=\"$SectionDisplayOption[15]\";\n");
		fputs($SettingsFile,"\$SectionDisplayCategoriesIcon=\"$SectionDisplayOption[16]\";\n");
		fputs($SettingsFile,"\$SectionDisplayDescription=\"$SectionDisplayOption[17]\";\n");
		fputs($SettingsFile,"\$SectionDisplayOrderBy=\"$SectionDisplayOption[18]\";\n");
		fputs($SettingsFile,"\$SectionDisplaySortOrder=\"$SectionDisplayOption[19]\";\n");
		if (trim($SectionDisplayOption[20])!="")
		{
		fputs($SettingsFile,"\$SectionDisplayFilter=\"and $SectionDisplayOption[20]\";\n");
		}
		fputs($SettingsFile,"\$SectionDisplayPermission=\"$SectionDisplayOption[21]\";\n");
		fputs($SettingsFile,"\$SectionDisplayCategoryIDs=\"$SectionDisplayOption[22]\";\n");
		fputs($SettingsFile,"\$SectionDisplayTopCategory=\"$SectionDisplayOption[23]\";\n");
		fputs($SettingsFile,"\$SectionDisplayTopScore=\"$SectionDisplayOption[24]\";\n");
		fputs($SettingsFile,"\$SectionDisplayTopDownload=\"$SectionDisplayOption[25]\";\n");
		fputs($SettingsFile,"\$SectionDisplayTopVisitor=\"$SectionDisplayOption[26]\";\n");
		fputs($SettingsFile,"\$SectionDisplayTopPrint=\"$SectionDisplayOption[27]\";\n");
		fputs($SettingsFile,"\$SectionDisplayTopLastSubmitted=\"$SectionDisplayOption[28]\";\n");

		// $CategoryDisplayOption=explode("|",$Row['CategoryDisplayOption']);
		// $_SESSION['CategoryDisplay']=$CategoryDisplayOption[0];
		// $_SESSION['CategoryDisplayTab']=$CategoryDisplayOption[1];
		// $_SESSION['CategoryDisplayMethod']=$CategoryDisplayOption[2];
		// $_SESSION['CategoryDisplayFieldsetLimit']=$CategoryDisplayOption[3];
		// $_SESSION['CategoryDisplayFieldsetImage']=$CategoryDisplayOption[4];
		// $_SESSION['CategoryDisplayAlign']=$CategoryDisplayOption[5];
		// 
		// if ($_SESSION['CategoryDisplayAlign']=="[OAlign]") {$_SESSION['CategoryDisplayAlign']=$LNG['OAlign'];}
		// if ($_SESSION['CategoryDisplayAlign']=="[DAlign]") {$_SESSION['CategoryDisplayAlign']=$LNG['DAlign'];}
		// 
		// $_SESSION['CategoryDisplayItemNo']=$CategoryDisplayOption[6];
		// $_SESSION['CategoryDisplayItemNoFontColor']=$CategoryDisplayOption[7];
		// $_SESSION['CategoryDisplayBulet']=$CategoryDisplayOption[8];
		// $_SESSION['CategoryDisplayViewing']=$CategoryDisplayOption[9];
		// $_SESSION['CategoryDisplayDotLine']=$CategoryDisplayOption[10];
		// $_SESSION['CategoryDisplaySubCategories']=$CategoryDisplayOption[11];
		// $_SESSION['CategoryDisplaySubCategoriesLimit']=$CategoryDisplayOption[12];
		// $_SESSION['CategoryDisplayDescription']=$CategoryDisplayOption[13];
		// $_SESSION['CategoryDisplayTopImage']=$CategoryDisplayOption[14];
		// $_SESSION['CategoryDisplayOrderBy']=$CategoryDisplayOption[15];
		// $_SESSION['CategoryDisplaySortOrder']=$CategoryDisplayOption[16];
		// $_SESSION['CategoryDisplayFilter']=$CategoryDisplayOption[17];
		// 
		// if (trim($_SESSION['CategoryDisplayFilter']!=""))
		// {
			// $_SESSION['CategoryDisplayFilter']="and ".$_SESSION['CategoryDisplayFilter'];
		// }
		// 
		// $_SESSION['CategoryDisplayPermission']=$CategoryDisplayOption[18];
		// $_SESSION['CategoryDisplayTopCategory']=$CategoryDisplayOption[19];
		// $_SESSION['CategoryDisplayTopScore']=$CategoryDisplayOption[20];
		// $_SESSION['CategoryDisplayTopDownload']=$CategoryDisplayOption[21];
		// $_SESSION['CategoryDisplayTopVisitor']=$CategoryDisplayOption[22];
		// $_SESSION['CategoryDisplayTopPrint']=$CategoryDisplayOption[23];
		// $_SESSION['CategoryDisplayTopLastSubmitted']=$CategoryDisplayOption[24];
		// 
		// 
		
		$ListDisplayOption=explode("|",$Row['ListDisplayOption']);
		fputs($SettingsFile,"\$ListDisplay=\"$ListDisplayOption[0]\";\n");
		fputs($SettingsFile,"\$ListDisplayTab=\"$ListDisplayOption[1]\";\n");
		fputs($SettingsFile,"\$ListDisplayMethod=\"$ListDisplayOption[2]\";\n");
		fputs($SettingsFile,"\$ListDisplayImageWidth=\"$ListDisplayOption[3]\";\n");
		fputs($SettingsFile,"\$ListDisplayImageHeight=\"$ListDisplayOption[4]\";\n");
		fputs($SettingsFile,"\$ListDisplayAlign=\"$ListDisplayOption[5]\";\n");
		fputs($SettingsFile,"\$ListDisplayMakeTable=\"$ListDisplayOption[6]\";\n");
		fputs($SettingsFile,"\$ListDisplayBorder=\"$ListDisplayOption[7]\";\n");
		fputs($SettingsFile,"\$ListDisplayBulet=\"$ListDisplayOption[8]\";\n");
		fputs($SettingsFile,"\$ListDisplayViewing=\"$ListDisplayOption[9]\";\n");
		fputs($SettingsFile,"\$ListDisplayScore=\"$ListDisplayOption[10]\";\n");
		fputs($SettingsFile,"\$ListDisplayHotItem=\"$ListDisplayOption[11]\";\n");
		fputs($SettingsFile,"\$ListDisplayStatisticReport=\"$ListDisplayOption[12]\";\n");
		fputs($SettingsFile,"\$ListDisplayDotLine=\"$ListDisplayOption[13]\";\n");
		fputs($SettingsFile,"\$ListDisplayCheckbox=\"$ListDisplayOption[14]\";\n");
		fputs($SettingsFile,"\$ListDisplayCheckboxControl=\"$ListDisplayOption[15]\";\n");
		fputs($SettingsFile,"\$ListDisplayTopImage=\"$ListDisplayOption[16]\";\n");
		fputs($SettingsFile,"\$ListDisplayOrderBy=\"$ListDisplayOption[17]\";\n");
		fputs($SettingsFile,"\$ListDisplaySortOrder=\"$ListDisplayOption[18]\";\n");

		

		$ShowDisplayOption=explode("|",$Row['ShowDisplayOption']);
		fputs($SettingsFile,"\$ShowDisplay=\"$ShowDisplayOption[0]\";\n");
		fputs($SettingsFile,"\$ShowDisplayTab=\"$ShowDisplayOption[1]\";\n");
		fputs($SettingsFile,"\$ShowDisplayTopImage=\"$ShowDisplayOption[2]\";\n");
		fputs($SettingsFile,"\$ShowDisplayViewing=\"$ShowDisplayOption[3]\";\n");
		fputs($SettingsFile,"\$ShowDisplaySlider=\"$ShowDisplayOption[4]\";\n");
		fputs($SettingsFile,"\$ShowDisplayDetail=\"$ShowDisplayOption[5]\";\n");
		fputs($SettingsFile,"\$ShowDisplayComment=\"$ShowDisplayOption[6]\";\n");
		fputs($SettingsFile,"\$ShowDisplayScore=\"$ShowDisplayOption[7]\";\n");
		fputs($SettingsFile,"\$ShowDisplayFavorite=\"$ShowDisplayOption[8]\";\n");
		fputs($SettingsFile,"\$ShowDisplayCart=\"$ShowDisplayOption[9]\";\n");
		fputs($SettingsFile,"\$ShowDisplayStatisticReport=\"$ShowDisplayOption[10]\";\n");

		

		// // Register Display
		// $RegisterDisplayOption=explode("|",$Row['RegisterDisplayOption']);;
		// $_SESSION['RegisterDisplayMethod']=$RegisterDisplayOption[0];
		// $_SESSION['RegisterDisplayNumbering']=$RegisterDisplayOption[1];
		// $_SESSION['RegisterDisplayRedirectUrl']=$RegisterDisplayOption[2];
		// 
		// 
		// $_SESSION['ContactDisplayOption']=$Row['ContactDisplayOption']; 
		// $_SESSION['UsercpDisplayOption']=$Row['UsercpDisplayOption']; 
		// $_SESSION['StatisticDisplayOption']=$Row['StatisticDisplayOption']; 
		// 
		// Submit Display
		$SubmitDisplayOption=explode("|",$Row['SubmitDisplayOption']);
		fputs($SettingsFile,"\$SubmitDisplayMethod=\"$SubmitDisplayOption[0]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayNumbering=\"$SubmitDisplayOption[1]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayTopImage=\"$SubmitDisplayOption[2]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayColonSrting=\"$SubmitDisplayOption[3]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayImageNo=\"$SubmitDisplayOption[4]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayImageAlt=\"$SubmitDisplayOption[5]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayAdditionalOptions=\"$SubmitDisplayOption[6]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayNewDays=\"$SubmitDisplayOption[7]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayMetaDescription=\"$SubmitDisplayOption[8]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayMetaKeywords=\"$SubmitDisplayOption[9]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayMoreInput=\"$SubmitDisplayOption[10]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayEditorTheme=\"$SubmitDisplayOption[11]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayEditorSize=\"$SubmitDisplayOption[12]\";\n");
		fputs($SettingsFile,"\$SubmitDisplayEditorWidth=\"$SubmitDisplayOption[13]\";\n");
	
	

		// Bolcks
		fputs($SettingsFile,"\$DesignSystem=\"{$Row['DesignSystem']}\";\n");
		fputs($SettingsFile,"\$DesignSystem=\"{$Row['DesignSystem']}\";\n");

		
			if ($BkgAlign=="[DAlign]")
			{
			fputs($SettingsFile,"\$BkgAlign=\"\$LNG['DAlign']\";\n");
			}
			elseif ($BkgAlign=="[OAlign]")
			{
			fputs($SettingsFile,"\$BkgAlign=\"\$LNG['OAlign']\";\n");
			}
			else
			{
			fputs($SettingsFile,"\$BkgAlign=\"{$Row['BkgAlign']}\";\n");
			}


		fputs($SettingsFile,"\$LeftBlockWidth=\"{$Row['LeftBlockWidth']}\";\n");
		$LeftBlockWidthStripPercent=str_replace("%","",$Row['LeftBlockWidth']);
		fputs($SettingsFile,"\$LeftBlockWidthStripPercent=$LeftBlockWidthStripPercent;\n");
		
		fputs($SettingsFile,"\$RightBlockWidth=\"{$Row['RightBlockWidth']}\";\n");
		$RightBlockWidthStripPercent=str_replace("%","",$Row['RightBlockWidth']);
		fputs($SettingsFile,"\$RightBlockWidthStripPercent=$RightBlockWidthStripPercent;\n");
		
		fputs($SettingsFile,"\$MiddleBlockWidth=\"{$Row['MiddleBlockWidth']}\";\n");
		$MiddleBlockWidthStripPercent=str_replace("%","",$Row['MiddleBlockWidth']);
		fputs($SettingsFile,"\$MiddleBlockWidthStripPercent=$MiddleBlockWidthStripPercent;\n");
		

		fputs($SettingsFile,"\$LeftBlockAlign=\"{$Row['LeftBlockAlign']}\";\n");
		fputs($SettingsFile,"\$RightBlockAlign=\"{$Row['RightBlockAlign']}\";\n");
		fputs($SettingsFile,"\$MiddleBlockAlign=\"{$Row['MiddleBlockAlign']}\";\n");
		
		fputs($SettingsFile,"\$LeftBlockValign=\"{$Row['LeftBlockValign']}\";\n");
		fputs($SettingsFile,"\$RightBlockValign=\"{$Row['RightBlockValign']}\";\n");
		fputs($SettingsFile,"\$MiddleBlockValign=\"{$Row['MiddleBlockValign']}\";\n");
		
		fputs($SettingsFile,"\$MiddleBlockValign=\"{$Row['MiddleBlockValign']}\";\n");

		$LeftAttribute=$Row['LeftAttribute'];
		$LeftAttribute=str_replace("[Theme]",$Theme,$LeftAttribute);
		$LeftAttribute=str_replace("[Service]",$Service,$LeftAttribute);
		$LeftAttribute=str_replace("[LService]",$LService,$LeftAttribute);
		$LeftAttribute=str_replace("[Lng]",$Lng,$LeftAttribute);
		$LeftAttribute=str_replace("[Dir]",$Dir,$LeftAttribute);
		fputs($SettingsFile,"\$LeftAttribute=\"$LeftAttribute\";\n");

		$RightAttribute=$Row['RightAttribute'];
		$RightAttribute=str_replace("[Theme]",$Theme,$RightAttribute);
		$RightAttribute=str_replace("[Service]",$Service,$RightAttribute);
		$RightAttribute=str_replace("[LService]",$LService,$RightAttribute);
		$RightAttribute=str_replace("[Lng]",$Lng,$RightAttribute);
		$RightAttribute=str_replace("[Dir]",$Dir,$RightAttribute);
		fputs($SettingsFile,"\$RightAttribute=\"$RightAttribute\";\n");

		$MiddleAttribute=$Row['MiddleAttribute'];
		$MiddleAttribute=str_replace("[Theme]",$Theme,$MiddleAttribute);
		$MiddleAttribute=str_replace("[Service]",$Service,$MiddleAttribute);
		$MiddleAttribute=str_replace("[LService]",$LService,$MiddleAttribute);
		$MiddleAttribute=str_replace("[Lng]",$Lng,$MiddleAttribute);
		$MiddleAttribute=str_replace("[Dir]",$Dir,$MiddleAttribute);
		fputs($SettingsFile,"\$MiddleAttribute=\"$MiddleAttribute\";\n");

		fputs($SettingsFile,"\$InsideMiddleWidth=\"{$Row['InsideMiddleWidth']}\";\n");
		fputs($SettingsFile,"\$BR=\"{$Row['BR']}\";\n");

		$BannerSql=str_ireplace("[UserID]",$UserID,$Row['BannerSql']);
		
		fputs($SettingsFile,"\$BannerSql=\"$BannerSql\";\n");

		// 
		// if ($_SESSION['LeftBlockAlign']=="[DAlign]") {$_SESSION['LeftBlockAlign']=$LNG['DAlign'];}
		// if ($MiddleBlockAlign=="[DAlign]") {$MiddleBlockAlign=$LNG['DAlign'];}
		// if ($_SESSION['RightBlockAlign']=="[DAlign]") {$_SESSION['RightBlockAlign']=$LNG['DAlign'];}
		// 
		// if ($_SESSION['LeftBlockAlign']=="[OAlign]") {$_SESSION['LeftBlockAlign']=$LNG['OAlign'];}
		// if ($MiddleBlockAlign=="[OAlign]") {$MiddleBlockAlign=$LNG['OAlign'];}
		// if ($_SESSION['RightBlockAlign']=="[OAlign]") {$_SESSION['RightBlockAlign']=$LNG['OAlign'];}

	}

	// Add Display Option to settings variabkes;
	$XMLPath="../module/$LService/theme/$Theme/xml/option.xml";
	libxml_use_internal_errors(true);
	$XML = simpleXML_load_file($XMLPath); 
	if ($XML)
	{
		foreach($XML->children() as $Child)
		{
		$XMLValue=$Child->getName();
		fputs($SettingsFile,"\$DisplayOption['$XMLValue']=\"$Child\";\n");
		
		echo "\$DisplayOption['$XMLValue']=\"$Child\";<br>";
		}
	}
	
	fputs($EnFile,"?>");
	fputs($FrFile,"?>");
	fputs($DeFile,"?>");
	fputs($ItFile,"?>");
	fputs($EsFile,"?>");
	fputs($RuFile,"?>");
	fputs($ArFile,"?>");
	fputs($SettingsFile,"?>");










	
?>
