<?php
// Cache One Page debend on $ID


	if ($ID!="")
	{
	// Cash new Show Page For Magic Cache System
	echo "<iframe width=200 height=200 src='../cache.php?Service=$Service&Lng=en&CachePage=ShowPage&CacheFrom=$ID&CacheTo=$ID&CacheProcess=1&CacheSystem=1' style='display:none'></iframe>";
	echo "<iframe width=200 height=200 src='../cache.php?Service=$Service&Lng=ar&CachePage=ShowPage&CacheFrom=$ID&CacheTo=$ID&CacheProcess=1&CacheSystem=1' style='display:none'></iframe>";
	
	// Cash random List Page - Current Category -  For Magic Cache System
	srand ((float) microtime() * 1000000);
	$CacheMax=rand(1,20);

	echo "<iframe width=200 height=200 src='../cache.php?Service=$Service&Lng=en&CachePage=ListPage&Theme=$Theme&CacheFrom=$CategoryID&CacheTo=$CategoryID&Page=$CacheMax&CacheMax=$CacheMax&CacheProcess=1&CacheSystem=1' style='display:none'></iframe>";
	echo "<iframe width=200 height=200 src='../cache.php?Service=$Service&Lng=ar&CachePage=ListPage&Theme=$Theme&CacheFrom=$CategoryID&CacheTo=$CategoryID&Page=$CacheMax&CacheMax=$CacheMax&CacheProcess=1&CacheSystem=1' style='display:none'></iframe>";

	}
	else
	{
	echo "<li><span style='color:#FF0000'>ID must be number magic cahce will not be done.</span>";
	}

?>
