<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ERROR|E_PARSE);
// error_reporting(-1);

$UserID=$_REQUEST['UserID'];$Open=$_REQUEST['Open'];$HTMLFileName=$_REQUEST['HTMLFileName'];
$Username=$_REQUEST['Username'];$OperatorImage=$_REQUEST['OperatorImage'];$Admin=$_REQUEST['Admin'];$DisableWelcomeMsg=$_REQUEST['DisableWelcomeMsg'];$DeleteCookiesPassword=$_REQUEST['DeleteCookiesPassword'];$Logout=$_REQUEST['Logout'];$Action=$_REQUEST['Action'];
$CookiesLoginOption=$_REQUEST['CookiesLoginOption'];$MainPage=$_REQUEST['MainPage'];$Ext=$_REQUEST['Ext'];
$FrameTop=$_REQUEST['FrameTop'];$FrameMain=$_REQUEST['FrameMain'];$FrameLeft=$_REQUEST['FrameLeft'];$FrameTop=$_REQUEST['FrameTop'];$FrameLeft=$_REQUEST['FrameLeft'];$FrameMain=$_REQUEST['FrameMain'];$FormLogin=$_REQUEST['FormLogin'];$Page=$_REQUEST['Page'];$FromPage=$_REQUEST['FromPage'];
$Password=$_REQUEST['Password'];
$View=$_REQUEST['View'];

$FormService=$_REQUEST['FormService'];$Service=$_REQUEST['Service'];

$ModuleName=$_REQUEST['ModuleName'];
$Page=$_REQUEST['Page'];$FromPage=$_REQUEST['FromPage'];

$CookiesPassword=$_COOKIE['CookiesPassword'];
$CookiesUsername=$_COOKIE['CookiesUsername'];

$Domain = preg_replace("/^www\./","",$_SERVER['SERVER_NAME']);

try {$PDO=new PDO("sqlite:/panel/database/config.db");$PDO->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);} catch (Exception $E) 
{
	if (stristr($E->getMessage(),"open_basedir"))
	{
	header("Location: https://go.$Domain");
	}
	else
	{
	echo $E->getMessage();
	}

	exit;
}

include("include/function/function.php");
include("/panel/include/config/config.php");


if ($DBName=="")
{

	if ($_SERVER['HTTPS']=="on")
	{
	header("Location: http://{$_SERVER['HTTP_HOST']}:2020");
	}
	else
	{
	echo Error("No database selected.");
	}
	
exit;
}


// if Table AdminVariable doesn't exist
include "setup.php";

// include "authenticate.php";


$Result = SQL("select * from Config where ConfigID=1");
foreach ($Result as $Row)
{
	$JSVersion=$Row['Version'];
	$Version=Version($Row['Version']);
	$ControlScrolling=$Row['ControlScrolling'];
	$GMT=$Row['GMT'];
	
	$CR=$Row['CR'];
	$SSHPassword=$Row['SSHPassword'];
	
	$AdminHomePage=$Row['AdminHomePage'];
	
	if ($AdminHomePage=="")
	{
		$AdminHomePage="home.php?SecretCode=[SecretCode]&Theme=$Theme";
	}
	
	$AdminEmail=$Row['AdminEmail'];
	
	$ServerIP=SSH ("wget -qO- checkip.amazonaws.com",$SSHUsername,$SSHPassword);
	
}

if ($Theme=="") {$Theme="default";}

$Lng=$_SESSION['SessionLng'];
if ($Lng=="") {$Lng="en";}

// معرفة التاريخ و الوقت الحالى
$Date=date ("Y-m-d",mktime (date("G"),date("i")+$GMT,date("s"),date("m"),date("d"),date("Y")));
$Time=date ("G:i A",mktime (date("G"),date("i")+$GMT,date("s"),date("m"),date("d"),date("Y")));

if ($ControlScrolling=="")
{
	$ControlScrolling="no";
}

if ($_SERVER['REQUEST_METHOD']=="POST" or ($_SESSION['SessionUserGroup']>=1) and $Theme!="")
{

	if ($_SERVER['REQUEST_METHOD']=="POST")
	{
	$Username=ValidateUsername($_REQUEST['Username']);
	$SessionPassword=ValidatePassword($_REQUEST['SessionPassword']);
	}
	
	if (stristr($Username,"'") or stristr($Username," and ")  or stristr($Username," or ") or stristr($Password,"'") or stristr($Password," and ")  or stristr($Password," or "))
	{
		echo "<link href=\"theme/$Theme/$Lng.css\" type=\"text/css\" rel=\"stylesheet\">";
		include "style/$Theme.php";
		
		echo "
		<table  cellPadding=0 cellSpacing=0 bgcolor=$BorderBG>
		<td width=5 align=middle background='media/image/admin/$Theme/tab-big-l-$Dir.gif' style='cursor:pointer' class=Tab height=17></td>
		<td align=middle background='media/image/admin/$Theme/tab-big-bg-on.gif' class=TabOn height=17>&nbsp; Access denied  &nbsp;</td>
		<td width=5 align=middle background='media/image/admin/$Theme/tab-big-r-$Dir.gif'  height=17></td>
		</table>
		";
		
		Echo "<table  cellPadding=0 cellSpacing=9 bgcolor=$BGColor[4] width='100%'><TD align='$DAlign' width='100%'>";
		
		echo Error("Access denied. <a href='index.php?DeleteCookiesPassword=1'>Try again</a>.");
		exit;
	}


	$Sql = "select Username from Site where Username='{$_SESSION['SessionUsername']}'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
	$SiteExists=1;
	}

	if ($_SESSION['SessionUsername']=="root" or $_SESSION['SessionUsername']==$SSHUsername)
	{
		
		if ($SSHHost=="") {$SSHHost="localhost";}
		$Connect = ssh2_connect($SSHHost, $SSHPort);
		if (ssh2_auth_password($Connect,$_SESSION['SessionUsername'],$_SESSION['SessionPassword']))
		{		

			$Result = SQL("select * from User where UserID=1");
			foreach ($Result as $Row)
			{

				$Success=1;
				
				$_SESSION['SessionSSHUsername']=$Row['Username'];


			}
		}
	}
	elseif ($_SESSION['SessionType']=="Website")
	{
	
		if ($View=="") {$View="User";}
	
		// Site Access
		$Result = SQL("select * from Site where Username='{$_SESSION['SessionUsername']}' and Password='{$_SESSION['SessionPassword']}'");
		foreach ($Result as $Row)
		{
			$Success=1;
			
			$_SESSION['SessionUsername']=$Row['Username'];
			$_SESSION['SessionDomain']=$Row['Domain'];
			$_SESSION['SessionFullName']=$Row['FullName'];
						
			$_SESSION['SessionUserGroup']=1;
	
			$_SESSION['SessionSSHUsername']=$SSHUsername;
			$_SESSION['SessionSSHPassword']=$SSHPassword;
			
			if (isset($_SESSION['ResetPassword']))
			{
				$Error=SSH ("/go/password {$Row['Username']} {$_SESSION['ResetPassword']}",$SSHUsername,$SSHPassword);
			}
			
		}
		
	}
	else
	{
		
		if (StartsWith(getcwd(),"/panel"))
		{
		// Reseller
	
			$Result = SQL("select * from User where Username='{$_SESSION['SessionUsername']}' and Password='{$_SESSION['SessionPassword']}'");
			foreach ($Result as $Row)
			{
				$Success=1;
				
				$_SESSION['SessionSSHUsername']=$SSHUsername;
				$_SESSION['SessionSSHPassword']=$SSHPassword;
				
			}
			
		}
		
	}
	
	
	If ($Success!=1)
	{
		echo Error("Invalid username or password...");

		session_unset();
		session_destroy();
		unset($_SESSION['SessionUsername'],$_SESSION['SessionUserID'],$_SESSION['SessionPassword'],$_SESSION['SessionUserGroup'],$_SESSION['SessionFullName'],$_SESSION['SessionGender'],$_SESSION['SessionBirthDate'],$_SESSION['SessionAge'],$_SESSION['SessionRegisterDate'],$_SESSION['SessionLastVisitDate'],$_SESSION['SessionLastVisitTime'],$_SESSION['SessionUserType'],$_SESSION['SessionCountryID']);

		setcookie ("CookiesUserID","",time() -3600);
		setcookie ("CookiesUserGroup","",time() -3600);
		setcookie ("CookiesUsername","",time() -3600);
		setcookie ("CookiesPassword","",time() -3600);
		setcookie ("CookiesUserType","",time() -3600);

		Echo "<META HTTP-EQUIV='Refresh' Content='3;URL=index.php'>";


		exit;
		
	}
	

	


	echo "<!DOCTYPE html>";
	
	$_SESSION['SessionView']=$View;
	
	include "language/en.php";
	if ($_SESSION['SessionLng']!="en")
	{
	include "language/{$_SESSION['SessionLng']}.php";
	}
		
		echo "
		<head>
		
	
		<title>Go Panel: $Domain Administration Area.</title>
				
		<link rel=\"shortcut icon\" href=\"image/favicon.png\" type=\"image/x-icon\"/>
		<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"image/apple-touch-icon-180x180.png\"/>

		
		<link href=\"theme/{$_SESSION['SessionTheme']}/css/en.css?$JSVersion\" type=\"text/css\" rel=\"stylesheet\">
		<link href=\"theme/{$_SESSION['SessionTheme']}/css/tree.css\" type=\"text/css\" rel=\"stylesheet\">
		";

		if (stristr("|ar|fa|ps|sd|ug|ur|yi|","|{$_SESSION['SessionLng']}|"))
		{
		echo "<html dir=rtl>";
		$DAlign="right";
		$OAlign="left";
		
		$Dir="RTL";
		
		echo "
		<link href=\"css/rtl.css?$JSVersion\" type=\"text/css\" rel=\"stylesheet\">
		";
		
		}
		else
		{
		echo "<html>";
		$DAlign="left";
		$OAlign="right";
		
		$Dir="LTR";
		}

		echo "
		<link href=\"theme/{$_SESSION['SessionTheme']}/css/progress-circle.css\" type=\"text/css\" rel=\"stylesheet\">
				
		<script type='text/javascript' src='https://ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js'></script>
		<link rel='stylesheet' href='include/js/jquery-ui/jquery-ui.css' />
		
		<script src='include/js/jquery-ui/jquery-ui.js'></script>
			
		<script type='text/javascript' src=\"include/js/function.js?$JSVersion\"></script>
		<script type='text/javascript' src=\"include/js/slider/slider-perpage.js\"></script>
		<script type='text/javascript' type='text/javascript' src='actb.js'></script>
		<script type='text/javascript' type='text/javascript' src='include/js/ajax.js'></script>

		<script type=\"text/javascript\" src=\"include/js/editarea/edit_area_full.js\"></script>
		
		<script type=\"text/javascript\" src=\"jquery/fancybox.js\"></script>
		<link rel='stylesheet' href='jquery/fancybox.css' />
		";

		if ($View=="Mobile")
		{
		echo "
		<style>.Scroll {height:calc(100vh - 112px);overflow-y:scroll;width:calc(100vw);overflow-x:auto;}</style>
		";
		}
		elseif ($View=="User")
		{
		echo "
		<style>.Scroll {height:calc(100vh - 112px);overflow-y:scroll;overflow-x:auto;}</style>
		";
		}
		else
		{
		echo "
		<style>.Scroll {height:calc(100vh - 112px);overflow-y:scroll;overflow-x:auto;}</style>
		";
		}
		
		echo "
		</head>

		<body>
		";
		

		if ($View=="Mobile")
		{
			echo "
			<table cellPadding=0 cellSpacing=0 width='100%' height='100%'>
			<td align='center' class=TdLogoSwitch>
			
			</td>
			
			<td align='$OAlign' class=TdHeader>
			
				<table height=62>
				
				<td align='center' width=240>

					<div class=ExpandSearch>
					<input type='text' name='MenuSearch' id='MenuSearch' autocomplete='off' accesskey='f' size=20 onkeyup=\"Search('div')\">
					</div>
				
				</td>
				
				<td width=16></td>
				
				<td align='center' width=240>
				
				";


				if ($_SESSION['SessionSwitchUsername']=="")
				{
				echo "&nbsp;<span class=Header> Welcome <a class=Header href=\"javascript:Load('gopanel.php')\">{$_SESSION['SessionUsername']}</a>";
				}
				else
				{

					$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
					foreach ($Result as $Row)
					{
					$Account['Domain'][]=$Row['Domain'];
					$Account['Username'][]=$Row['Username'];
					}

					if (is_array($Account['Domain']))
					{
						array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);
						
						echo "
						<select name='SwitchUsername' id='SwitchUsername' onchange='Switch()' class=HeaderSelect>
						
						<option value='{$_SESSION['SessionSwitchUsername']}' selected>{$_SESSION['SessionSwitchUsername']}</option>
						
						";
						
						for ($E=0;$E<count($Account['Domain']);$E++)
						{
							
							if ($Account['Username'][$E]==$_SESSION['SessionUsername'])
							{
							echo "<option value='{$Account['Username'][$E]}' selected>{$Account['Domain'][$E]}</option>";
							}
							else
							{
							echo "<option value='{$Account['Username'][$E]}'>{$Account['Domain'][$E]}</option>";
							}
							
						}

						echo "</select>";
					}
					
				
				}
				
				echo "
				
				<td width=16></td>
				
				
				<td align='center' width=64 style='border-$Dalign:1px solid #23232E'>
				<a class=Header href=\"javascript:Load('change-log.php')\"><img src='image/change-log.svg' style='height:32px;' title='Change Log'></a>
				</td>
				
				
				<td align='center' width=64 style='border-$DAlign:1px solid #23232E'>
				
				
				";

				if ($_SESSION['SessionView']=="User")
				{
				echo "<a href='index.php?View=Admin'><img src='image/switch.svg' style='height:32px;' title='Switch View'></a>";
				}
				else
				{
				echo "<a href='index.php?View=User'><img src='image/switch.svg' style='height:32px;' title='Switch View'></a>";
				}

				echo "
				
				</td>

				<td align='center' width=64 style='border-$Dalign:1px solid #23232E'>
				<a class=Header href=\"javascript:Load('logout.php')\"><img src='image/logout.svg' style='height:32px;' title='Logout'></a>
				</td>

				</table>
				
			</td>
			
			<tr>
			
			<td valign=top colspan=2 class=TdMain>
			
			
				<div id=Load class=DivLoad>
				";
				
					if ($_REQUEST['Load']==!"")
					{
					echo "<script>Load('{$_REQUEST['Load']}');</script>";
					}
					else
					{
					// echo "<script>Load('home.php');</script>";
					include "home.php";
					}
				
				echo "
				</div>

			
			</td>
			</table>
			";
		}
		elseif ($View=="User")
		{
			echo "
			<table cellPadding=0 cellSpacing=0 width='100%' height='100%'>
			<td align='center' class=TdLogoSwitch>
			
			</td>
			
			<td align='$OAlign' class=TdHeader>
			
				<table height=62>
				
				<td align='center' width=240>

					<div class=ExpandSearch>
					<input type='text' name='MenuSearch' id='MenuSearch' autocomplete='off' accesskey='f' size=20 onkeyup=\"Search('div')\">
					</div>
				
				</td>
				
				<td width=16></td>
				
				<td align='center' width=240>
				
				";


				if ($_SESSION['SessionSwitchUsername']=="")
				{
				echo "&nbsp;<span class=Header> Welcome <a class=Header href=\"javascript:Load('gopanel.php')\">{$_SESSION['SessionUsername']}</a>";
				}
				else
				{

					$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
					foreach ($Result as $Row)
					{
					$Account['Domain'][]=$Row['Domain'];
					$Account['Username'][]=$Row['Username'];
					}

					if (is_array($Account['Domain']))
					{
						array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);
						
						echo "
						<select name='SwitchUsername' id='SwitchUsername' onchange='Switch()' class=HeaderSelect>
						
						<option value='{$_SESSION['SessionSwitchUsername']}' selected>{$_SESSION['SessionSwitchUsername']}</option>
						
						";
						
						for ($E=0;$E<count($Account['Domain']);$E++)
						{
							
							if ($Account['Username'][$E]==$_SESSION['SessionUsername'])
							{
							echo "<option value='{$Account['Username'][$E]}' selected>{$Account['Domain'][$E]}</option>";
							}
							else
							{
							echo "<option value='{$Account['Username'][$E]}'>{$Account['Domain'][$E]}</option>";
							}
							
						}

						echo "</select>";
					}
					
				
				}
				
				echo "
				
				<td width=16></td>
				
				
				<td align='center' width=64 style='border-$Dalign:1px solid #23232E'>
				<a class=Header href=\"javascript:Load('change-log.php')\"><img src='image/change-log.svg' style='height:32px;' title='Change Log'></a>
				</td>
				
				
				<td align='center' width=64 style='border-$DAlign:1px solid #23232E'>
				
				
				";

				if ($_SESSION['SessionView']=="User")
				{
				echo "<a href='index.php?View=Admin'><img src='image/switch.svg' style='height:32px;' title='Switch View'></a>";
				}
				else
				{
				echo "<a href='index.php?View=User'><img src='image/switch.svg' style='height:32px;' title='Switch View'></a>";
				}

				echo "
				
				</td>

				<td align='center' width=64 style='border-$Dalign:1px solid #23232E'>
				<a class=Header href=\"javascript:Load('logout.php')\"><img src='image/logout.svg' style='height:32px;' title='Logout'></a>
				</td>

				</table>
				
			</td>
			
			<tr>
			
			<td valign=top colspan=2 class=TdMain>
			
				<table cellpadding=0 cellspacing=0 border=0 width=100%>
				
				<td valign='top' width=350>
				";
				
				include "info.php";
				
				echo "
				</td>
					
				<td>
				
					<div id=Load class=DivLoad>
					";
					
						if ($_REQUEST['Load']==!"")
						{
						echo "<script>Load('{$_REQUEST['Load']}');</script>";
						}
						else
						{
						echo "<script>Load('home.php');</script>";
						}
					
					echo "
					</div>

				</td>
				
				</table>
				
			</td>
			</table>
			";
		}
		else
		{
		
			echo "
			<table cellPadding=0 cellSpacing=0 width='100%' height='100%'>
			<td align='center' class=TdLogo>
			
			
			</td>
			
			<td align='$OAlign' class=TdHeader>
			
				<table height=62>
				
				<td align='center' width=240>
				
				";

					
				if ($_SESSION['SessionSwitchUsername']=="")
				{
				echo "&nbsp;<span class=Header> Welcome <a class=Header href=\"javascript:Load('gopanel.php')\">{$_SESSION['SessionUsername']}</a>";
				}
				else
				{

					$Sql = "select * from Site where RecycleBin=0 $SearchSql";
					$Result = SQL($Sql);
					foreach ($Result as $Row)
					{
					$Account['Domain'][]=$Row['Domain'];
					$Account['Username'][]=$Row['Username'];
					}

					if (is_array($Account['Domain']))
					{
					
						array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);
						
						echo "
						<select name='SwitchUsername' id='SwitchUsername' onchange='Switch()' class=HeaderSelect>
						
						<option value='{$_SESSION['SessionSwitchUsername']}' selected>{$_SESSION['SessionSwitchUsername']}</option>
						
						";
						
						for ($E=0;$E<count($Account['Domain']);$E++)
						{
							
							if ($Account['Username'][$E]==$_SESSION['SessionUsername'])
							{
							echo "<option value='{$Account['Username'][$E]}' selected>{$Account['Domain'][$E]}</option>";
							}
							else
							{
							echo "<option value='{$Account['Username'][$E]}'>{$Account['Domain'][$E]}</option>";
							}
							
						}

						echo "</select>";
					}
					
				
				}

				echo "
				</td>
				
				<td width=16></td>
				
				<td align='center' width=64 style='border-$Dalign:1px solid #23232E'>
				<a class=Header href=\"javascript:Load('change-log.php')\"><img src='image/change-log.svg' style='height:32px;' title='Change Log'></a>
				</td>
				
				<td align='center' width=64 style='border-$DAlign:1px solid #23232E'>
				";

				if ($_SESSION['SessionView']=="User")
				{
				echo "<a href='index.php?View=Admin'><img src='image/switch.svg' style='height:32px;' title='Switch View'></a>";
				}
				else
				{
				echo "<a href='index.php?View=User'><img src='image/switch.svg' style='height:32px;' title='Switch View'></a>";
				}

				echo "
				
				</td>
				
				<td align='center' width=64 style='border-$DAlign:1px solid #23232E'>

				<a class=Header href=\"javascript:Load('logout.php')\"><img src='image/logout.svg' style='height:32px;' title='Logout'></a>

				</td>
				
				</table>

			</td>
			
			<tr>
			
			
			<td valign=top class='TdLeft'>
			<div class=Search>
			<input type='text' name='MenuSearch' id='MenuSearch' autocomplete='off' accesskey='f' size=20 onkeyup=\"Search('div')\">
			</div>
			
			";

			if ($SSHUsername=="")
			{
			$ServiceControl="Help";
			}
			else
			{
			$ServiceControl="Panel";
			}

			include "control.php";

			echo "
			</td>

			<td valign=top class=TdMain>
			<div id=Load class=DivLoad>
			
			";
			
				if ($_REQUEST['Load']==!"")
				{
				echo "<script>Load('{$_REQUEST['Load']}');</script>";
				}
				else
				{
				echo "<script>Load('home.php');</script>";
				}
			

			echo "
			</div>
			</td>
			</table>
			";
		}
		
		


	echo "</body>";
	echo "</html>";
}
else
{

echo "
<html>

<head>
<title>Go Panel: $Domain Administration Area. </title>

	<link rel=\"shortcut icon\" href=\"image/favicon.png\" type=\"image/x-icon\"/>
	<link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"image/apple-touch-icon-180x180.png\"/>


</head>

<BODY leftMargin=0 RightMargin=0 topMargin=0 marginheight=0 marginwidth=0>	


";

	$Theme="light";

	if ($Logout==1)
	{
		unset($_SESSION['SessionUsername']);
		unset($_SESSION['SessionPassword']);


		echo "<link href=\"css/$Theme/$Lng.css\" type=\"text/css\" rel=\"stylesheet\">";
		include "style/$Theme.php";

		if (stristr("|ar|fa|ps|sd|ug|ur|yi|",$Lng))
		{
		echo "<html dir=rtl>";
		$DAlign="right";
		$OAlign="left";
		$Dir="RTL";
		}
		else
		{
		echo "<html>";
		$DAlign="left";
		$OAlign="right";
		$Dir="LTR";
		}
	
		echo "
		<table  cellPadding=0 cellSpacing=0 bgcolor=$BorderBG>
		<td width=5 align=middle background='media/image/admin/$Theme/tab-big-l-$Dir.gif' style='cursor:pointer' class=Tab height=17></td>
		<td align=middle background='media/image/admin/$Theme/tab-big-bg-on.gif' class=TabOn height=17>&nbsp; Logout  &nbsp;</td>
		<td width=5 align=middle background='media/image/admin/$Theme/tab-big-r-$Dir.gif' height=17></td>
		</table>
		";
		
		
		
		Echo "<table  cellPadding=0 cellSpacing=9 bgcolor=$BGColor[4] width='100%'><TD align='$DAlign' width='100%'>";
		
		echo Error("Going to Control Panel .");
		Echo "<META HTTP-EQUIV='Refresh' Content='2;URL=index.php'>";
		
	
		exit;
	}
	
	
	if ($_COOKIE['CookiesTheme']=="dark")
	{
	echo "<link href=\"theme/dark/css/en.css??$JSVersion\" type=\"text/css\" rel=\"stylesheet\">";
	$Logo="logo-white.svg";
	}
	else
	{
	echo "<link href=\"theme/light/css/en.css??$JSVersion\" type=\"text/css\" rel=\"stylesheet\">";
	$Logo="logo.svg";
	}
	
	echo "
	<script type='text/javascript' src=\"include/js/function.js?$JSVersion\"></script>
	<script type='text/javascript' type='text/javascript' src='include/js/ajax.js'></script>
	";

	if (stristr("|ar|fa|ps|sd|ug|ur|yi|","|{$_COOKIE['CookiesLng']}|"))
	{
	echo "<html dir=rtl>";
	$DAlign="right";
	$OAlign="left";
	$Dir="RTL";
	}
	else
	{
	echo "<html>";
	$DAlign="left";
	$OAlign="right";
	$Dir="LTR";
	}


	include "language/en.php";
	if ($_COOKIE['CookiesLng']!="en")
	{
	include "language/{$_COOKIE['CookiesLng']}.php";
	}
	
	if ($SessionPassword!="")
	{

		// Logout
		session_unregister("SessionUsername");
		session_unregister("SessionPassword");
		session_destroy();

	}

	Echo "	
	<table cellpadding=0 cellspacing=0 width=100%><td width=100% align='center'>
	


	<form name=FormLogin method=POST onsubmit='Login()' autocomplete='off'>
	<input type=hidden name=TargetFrame id=TargetFrame value='$_REQUEST[TargetFrame]'>
	";
	
		$Hostname=@file_get_contents("/etc/hostname");
		$Hostname=trim($Hostname);

		if ($CookiesUsername=="" and StartsWith(getcwd(),"/panel") and !filter_var($Domain, FILTER_VALIDATE_IP)) 
		{
		$CookiesUsername=$Domain;
		}
		
		if ($Hostname==$CookiesUsername)
		{
		$CookiesUsername="root";
		}
		
		if ($CookiesUsername=="" and $ServerIP==$_SERVER['HTTP_HOST'])
		{
		$CookiesUsername="root";
		}
		
		if (stristr($CookiesUsername,"go."))
		{
			// Replace Only the First Match
			$CookiesUsername=preg_replace('/go./', "", $CookiesUsername, 1);
		}
		
		if ($DemoUsername!="")
		{
		$CookiesUsername=$DemoUsername;
		
		$String = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz";
		$CookiesPassword=substr(str_shuffle($String),0,8);		
		}
		
		
		
				

		$LANG['Code'][]="af";$LANG['Name'][]=$LNG['Afrikaans'];
		$LANG['Code'][]="sq";$LANG['Name'][]=$LNG['Albanian'];
		$LANG['Code'][]="am";$LANG['Name'][]=$LNG['Amharic'];
		$LANG['Code'][]="ar";$LANG['Name'][]=$LNG['Arabic'];
		$LANG['Code'][]="hy";$LANG['Name'][]=$LNG['Armenian'];
		$LANG['Code'][]="az";$LANG['Name'][]=$LNG['Azerbaijani'];
		$LANG['Code'][]="eu";$LANG['Name'][]=$LNG['Basque'];
		$LANG['Code'][]="be";$LANG['Name'][]=$LNG['Belarusian'];
		$LANG['Code'][]="bn";$LANG['Name'][]=$LNG['Bengali'];
		$LANG['Code'][]="bs";$LANG['Name'][]=$LNG['Bosnian'];
		$LANG['Code'][]="bg";$LANG['Name'][]=$LNG['Bulgarian'];
		$LANG['Code'][]="ca";$LANG['Name'][]=$LNG['Catalan'];
		$LANG['Code'][]="ceb";$LANG['Name'][]=$LNG['Cebuano'];
		$LANG['Code'][]="ny";$LANG['Name'][]=$LNG['Chichewa'];
		$LANG['Code'][]="zh-cn";$LANG['Name'][]=$LNG['ChineseSimplified'];
		$LANG['Code'][]="zh-tw";$LANG['Name'][]=$LNG['ChineseTraditional'];
		$LANG['Code'][]="co";$LANG['Name'][]=$LNG['Corsican'];
		$LANG['Code'][]="hr";$LANG['Name'][]=$LNG['Croatian'];
		$LANG['Code'][]="cs";$LANG['Name'][]=$LNG['Czech'];
		$LANG['Code'][]="da";$LANG['Name'][]=$LNG['Danish'];
		$LANG['Code'][]="nl";$LANG['Name'][]=$LNG['Dutch'];
		$LANG['Code'][]="en";$LANG['Name'][]=$LNG['English'];
		$LANG['Code'][]="eo";$LANG['Name'][]=$LNG['Esperanto'];
		$LANG['Code'][]="et";$LANG['Name'][]=$LNG['Estonian'];
		$LANG['Code'][]="tl";$LANG['Name'][]=$LNG['Filipino'];
		$LANG['Code'][]="fi";$LANG['Name'][]=$LNG['Finnish'];
		$LANG['Code'][]="fr";$LANG['Name'][]=$LNG['French'];
		$LANG['Code'][]="fy";$LANG['Name'][]=$LNG['Frisian'];
		$LANG['Code'][]="gl";$LANG['Name'][]=$LNG['Galician'];
		$LANG['Code'][]="ka";$LANG['Name'][]=$LNG['Georgian'];
		$LANG['Code'][]="de";$LANG['Name'][]=$LNG['German'];
		$LANG['Code'][]="el";$LANG['Name'][]=$LNG['Greek'];
		$LANG['Code'][]="gu";$LANG['Name'][]=$LNG['Gujarati'];
		$LANG['Code'][]="ht";$LANG['Name'][]=$LNG['HaitianCreole'];
		$LANG['Code'][]="ha";$LANG['Name'][]=$LNG['Hausa'];
		$LANG['Code'][]="haw";$LANG['Name'][]=$LNG['Hawaiian'];
		$LANG['Code'][]="iw";$LANG['Name'][]=$LNG['Hebrew'];
		$LANG['Code'][]="hi";$LANG['Name'][]=$LNG['Hindi'];
		$LANG['Code'][]="hmn";$LANG['Name'][]=$LNG['Hmong'];
		$LANG['Code'][]="hu";$LANG['Name'][]=$LNG['Hungarian'];
		$LANG['Code'][]="is";$LANG['Name'][]=$LNG['Icelandic'];
		$LANG['Code'][]="ig";$LANG['Name'][]=$LNG['Igbo'];
		$LANG['Code'][]="id";$LANG['Name'][]=$LNG['Indonesian'];
		$LANG['Code'][]="ga";$LANG['Name'][]=$LNG['Irish'];
		$LANG['Code'][]="it";$LANG['Name'][]=$LNG['Italian'];
		$LANG['Code'][]="ja";$LANG['Name'][]=$LNG['Japanese'];
		$LANG['Code'][]="jw";$LANG['Name'][]=$LNG['Javanese'];
		$LANG['Code'][]="kn";$LANG['Name'][]=$LNG['Kannada'];
		$LANG['Code'][]="kk";$LANG['Name'][]=$LNG['Kazakh'];
		$LANG['Code'][]="km";$LANG['Name'][]=$LNG['Khmer'];
		$LANG['Code'][]="rw";$LANG['Name'][]=$LNG['Kinyarwanda'];
		$LANG['Code'][]="ko";$LANG['Name'][]=$LNG['Korean'];
		$LANG['Code'][]="ku";$LANG['Name'][]=$LNG['KurdishKurmanji'];
		$LANG['Code'][]="ky";$LANG['Name'][]=$LNG['Kyrgyz'];
		$LANG['Code'][]="lo";$LANG['Name'][]=$LNG['Lao'];
		$LANG['Code'][]="la";$LANG['Name'][]=$LNG['Latin'];
		$LANG['Code'][]="lv";$LANG['Name'][]=$LNG['Latvian'];
		$LANG['Code'][]="lt";$LANG['Name'][]=$LNG['Lithuanian'];
		$LANG['Code'][]="lb";$LANG['Name'][]=$LNG['Luxembourgish'];
		$LANG['Code'][]="mk";$LANG['Name'][]=$LNG['Macedonian'];
		$LANG['Code'][]="mg";$LANG['Name'][]=$LNG['Malagasy'];
		$LANG['Code'][]="ms";$LANG['Name'][]=$LNG['Malay'];
		$LANG['Code'][]="ml";$LANG['Name'][]=$LNG['Malayalam'];
		$LANG['Code'][]="mt";$LANG['Name'][]=$LNG['Maltese'];
		$LANG['Code'][]="mi";$LANG['Name'][]=$LNG['Maori'];
		$LANG['Code'][]="mr";$LANG['Name'][]=$LNG['Marathi'];
		$LANG['Code'][]="mn";$LANG['Name'][]=$LNG['Mongolian'];
		$LANG['Code'][]="my";$LANG['Name'][]=$LNG['MyanmarBurmese'];
		$LANG['Code'][]="ne";$LANG['Name'][]=$LNG['Nepali'];
		$LANG['Code'][]="no";$LANG['Name'][]=$LNG['Norwegian'];
		$LANG['Code'][]="or";$LANG['Name'][]=$LNG['OdiaOriya'];
		$LANG['Code'][]="ps";$LANG['Name'][]=$LNG['Pashto'];
		$LANG['Code'][]="fa";$LANG['Name'][]=$LNG['Persian'];
		$LANG['Code'][]="pl";$LANG['Name'][]=$LNG['Polish'];
		$LANG['Code'][]="pt";$LANG['Name'][]=$LNG['Portuguese'];
		$LANG['Code'][]="pa";$LANG['Name'][]=$LNG['Punjabi'];
		$LANG['Code'][]="ro";$LANG['Name'][]=$LNG['Romanian'];
		$LANG['Code'][]="ru";$LANG['Name'][]=$LNG['Russian'];
		$LANG['Code'][]="sm";$LANG['Name'][]=$LNG['Samoan'];
		$LANG['Code'][]="gd";$LANG['Name'][]=$LNG['ScotsGaelic'];
		$LANG['Code'][]="sr";$LANG['Name'][]=$LNG['Serbian'];
		$LANG['Code'][]="st";$LANG['Name'][]=$LNG['Sesotho'];
		$LANG['Code'][]="sn";$LANG['Name'][]=$LNG['Shona'];
		$LANG['Code'][]="sd";$LANG['Name'][]=$LNG['Sindhi'];
		$LANG['Code'][]="si";$LANG['Name'][]=$LNG['Sinhala'];
		$LANG['Code'][]="sk";$LANG['Name'][]=$LNG['Slovak'];
		$LANG['Code'][]="sl";$LANG['Name'][]=$LNG['Slovenian'];
		$LANG['Code'][]="so";$LANG['Name'][]=$LNG['Somali'];
		$LANG['Code'][]="es";$LANG['Name'][]=$LNG['Spanish'];
		$LANG['Code'][]="su";$LANG['Name'][]=$LNG['Sundanese'];
		$LANG['Code'][]="sw";$LANG['Name'][]=$LNG['Swahili'];
		$LANG['Code'][]="sv";$LANG['Name'][]=$LNG['Swedish'];
		$LANG['Code'][]="tg";$LANG['Name'][]=$LNG['Tajik'];
		$LANG['Code'][]="ta";$LANG['Name'][]=$LNG['Tamil'];
		$LANG['Code'][]="tt";$LANG['Name'][]=$LNG['Tatar'];
		$LANG['Code'][]="te";$LANG['Name'][]=$LNG['Telugu'];
		$LANG['Code'][]="th";$LANG['Name'][]=$LNG['Thai'];
		$LANG['Code'][]="tr";$LANG['Name'][]=$LNG['Turkish'];
		$LANG['Code'][]="tk";$LANG['Name'][]=$LNG['Turkmen'];
		$LANG['Code'][]="uk";$LANG['Name'][]=$LNG['Ukrainian'];
		$LANG['Code'][]="ur";$LANG['Name'][]=$LNG['Urdu'];
		$LANG['Code'][]="ug";$LANG['Name'][]=$LNG['Uyghur'];
		$LANG['Code'][]="uz";$LANG['Name'][]=$LNG['Uzbek'];
		$LANG['Code'][]="vi";$LANG['Name'][]=$LNG['Vietnamese'];
		$LANG['Code'][]="cy";$LANG['Name'][]=$LNG['Welsh'];
		$LANG['Code'][]="xh";$LANG['Name'][]=$LNG['Xhosa'];
		$LANG['Code'][]="yi";$LANG['Name'][]=$LNG['Yiddish'];
		$LANG['Code'][]="yo";$LANG['Name'][]=$LNG['Yoruba'];
		$LANG['Code'][]="zu";$LANG['Name'][]=$LNG['Zulu'];
				
		array_multisort($LANG['Name'], SORT_ASC, SORT_STRING,$LANG['Code'], SORT_NUMERIC, SORT_DESC);

		
		echo "
		<br>
		<br>
		<br>
		<br>
		<br>
		<table align='center' cellPadding=2 cellSpacing=1 class=TableLogin>
		<td colspan=2 height=31 class='TdLoginB'>
		&nbsp;&nbsp;Go Panel Login
		</td>
		
		<tr>

		<TD align='$OAlign' width='120' height=31 class='TdLogin'>{$LNG['Username']}:&nbsp;</td>
		<TD align='center' width='300' class='TdLogin'><input type='Text' name='Username' id='Username' value='$CookiesUsername' onkeyup='CheckAuth(this.value)' onblur='CheckAuth(this.value)' class=InputUsername></td>
		
		<tr>
		
		<TD align='$OAlign' width='100' height=31 class='TdLogin'>{$LNG['Password']}:&nbsp;</td>
		<TD align='center' width='300' class='TdLogin'><input type='password' name='Password' id='Password' value='$CookiesPassword' onKeyPress=\"return CheckCapsLock(event)\" class=InputPassword></td>

		<tr id=GoogleAuth style='display:none'>
		
		<TD align='$OAlign' width='100' height=31 class='TdLogin'>Google Auth Code:&nbsp;</td>
		<TD align='center' width='300' class='TdLogin'><input type='text' name='Code' id='Code' class=InputUsername></td>

		<tr>
		
		<TD align='$OAlign' height=31 class='TdLogin'>{$LNG['Language']}:&nbsp;</td>
		<TD align='center' class='TdLogin'>

		<select name='SessionLng' id='SessionLng' class=InputUsername style='appearance:none;outline: none;'>
		";
		
		for ($E=0;$E<count($LANG['Name']);$E++)
		{
			if ($LANG['Code'][$E]=="en")
			{
			echo "<option value='{$LANG['Code'][$E]}' selected>{$LANG['Name'][$E]}</option>";
			}
			else
			{
			echo "<option value='{$LANG['Code'][$E]}'>{$LANG['Name'][$E]}</option>";
			}
		}

		echo "	
		</select>
	
		</td>
		
		<tr>

		<TD align='$OAlign' height=31 class='TdLogin'>{$LNG['Theme']}:&nbsp;</td>
		<TD align='center' class='TdLogin'>

			<table cellpadding=0 cellspacing=0 width=292 style='margin-top:7px'>
			<td width=50%>
				<label class=Label>{$LNG['LightMode']}
				<input type='radio' name='SessionTheme' value='light' checked='checked'>
				<span class='Radio'></span>
				</label>
			</td>
			
			<td width=50%>
				<label class=Label>{$LNG['DarkMode']}
				<input type='radio' name='SessionTheme' value='dark'>
				<span class='Radio'></span>
				</label>
			</td>
			</table>
		
		</td>

		</table>
		
		<table align='center' cellPadding=2 cellSpacing=1>
				
		<TD align='center' width=305 height=31 class='TdLoginC'><div id=DivLogin></div></TD>
		<TD align='$OAlign' width=120 class='TdLoginC'><input type=submit value='{$LNG['Login']}' onclick='return Login()' class=Login></TD>
		
		<tr>
		
		<TD align='center' colspan=2 height=31 class='TdLoginC'>
		<div id=DivCapsLock style='position:relative;font-family:Arial;font-size:12px;color:red;'></div>
		</TD>
		
		</TABLE>
		</form>
	

	<table align='center' cellPadding=2 cellSpacing=1 class=TableLogin width=99%>
	
	<td align='center' width=20% class='TdLogin'></td>
	
	<td align='center' width=20% class='TdLogin' height=31>
	Go Panel {$LNG['Version']}: $Version
	</td>
	
	<td align='center' width=20% class='TdLogin'></td>
	
	<td align='center' width=20% class='TdLogin' onclick=\"Copy('$ServerIP')\" title='Click to Copy' style='cursor:pointer'>{$LNG['ServerIP']}: $ServerIP</td>

	<td align='center' width=20% class='TdLogin'></td>

	</TABLE>
	
	
	
	
	
	</TD></TABLE>
		
		";
			
			
				

		$IP = getenv ("REMOTE_ADDR");
		$BIP=explode(".",$IP);

	
	
	?><script type='text/javascript'>
	
	if(IsEmpty(document.forms['FormLogin'].Username.value))
	{
		document.forms['FormLogin'].Username.focus();
	}
	else
	{
		document.forms['FormLogin'].Password.focus();
	}
	

	
	function IsEmpty(str)
	{
		var i;
		var len;
		if( str == null )
		return true;
		
		len = str.length;
		for( var i=0; i<len; i++ )
		{
			if( str.charAt(i) != ' ')
			return false;
		}
		return true;
	}
	
	
	function GoToPage(LService) { 
	newPage = "../en/"+LService;
	if (newPage != "") { window.location.href = newPage } 
} 


function CheckCapsLock( e ) {
document.getElementById('DivCapsLock').innerHTML ='';

var myKeyCode=0;
var myShiftKey=false;
var myMsg='Caps Look on may cause you to enter your password incorrectly.';

// Internet Explorer 4+

if ( document.all ) {
myKeyCode=e.keyCode;
myShiftKey=e.shiftKey;

// Netscape 4
} else if ( document.layers ) {
myKeyCode=e.which;
myShiftKey=( myKeyCode == 16 ) ? true : false;

// Netscape 6
} else if ( document.getElementById ) {
myKeyCode=e.which;
myShiftKey=( myKeyCode == 16 ) ? true : false;

}

// Upper case letters are seen without depressing the Shift key, therefore Caps Lock is on
if ( ( myKeyCode >= 65 && myKeyCode <= 90 ) && !myShiftKey ) {

document.getElementById('DivCapsLock').innerHTML ='<span FACE=Arial COLOR=RED size=2>'+myMsg;
//return false;

// Lower case letters are seen while depressing the Shift key, therefore Caps Lock is on
} else if ( ( myKeyCode >= 97 && myKeyCode <= 122 ) && myShiftKey ) {
document.getElementById('DivCapsLock').innerHTML ='<span FACE=Arial COLOR=RED size=2>'+myMsg;
// return false;
}

}

</script>

<?php

	// Logout
	session_unset();
	session_destroy();
	unset($_SESSION['SessionUsername'],$_SESSION['SessionUserID'],$_SESSION['SessionPassword'],$_SESSION['SessionUserGroup'],$_SESSION['SessionFullName'],$_SESSION['SessionGender'],$_SESSION['SessionBirthDate'],$_SESSION['SessionAge'],$_SESSION['SessionRegisterDate'],$_SESSION['SessionLastVisitDate'],$_SESSION['SessionLastVisitTime'],$_SESSION['SessionUserType'],$_SESSION['SessionCountryID']);

	if ($_COOKIE['CookiesLng']!="" and $_COOKIE['CookiesLng']!="en")
	{
	echo "<script type='text/javascript'>document.getElementById('SessionLng').value='{$_COOKIE['CookiesLng']}';</script>";
	}


	if ($_COOKIE['CookiesTheme']=="dark")
	{
	Echo "<script type='text/javascript'>FormLogin.SessionTheme[1].checked=true;</script>";
	}

echo "

<script type='text/javascript'>

CheckAuth();

function Radio (Name)
{
	var radios = document.getElementsByName(Name);

	for (var i = 0, length = radios.length; i < length; i++)
	{
		if (radios[i].checked)
		{
		return (radios[i].value);

		break;
		}
	}
}

function Login()
{
document.getElementById('DivLogin').innerHTML = 'Authenticating...';

	if(IsEmpty(document.forms['FormLogin'].Username.value))
	{
		alert(\"Please enter Username.\");
		document.forms['FormLogin'].Username.focus();
		
		return false;
	}
	
	if(IsEmpty(document.forms['FormLogin'].Password.value))
	{
		alert(\"Please enter password.\");
		document.forms['FormLogin'].Password.focus();
		
		return false;
	}
	
	var Username=document.getElementById('Username').value;
	var Password=document.getElementById('Password').value;

	var Code=document.getElementById('Code').value;

	var SessionLng=document.getElementById('SessionLng').value;
	
	var SessionTheme=Radio('SessionTheme');
	
	http=Ajax();http.abort();
	http.open(\"POST\", \"ajax/login.php\",true);
	http.setRequestHeader(\"Content-Type\", \"application/x-www-form-urlencoded\");
	http.onreadystatechange = HandelLogin;
	http.send('Username='+Username+'&Password='+Password+'&Code='+Code+'&SessionLng='+SessionLng+'&SessionTheme='+SessionTheme);
	
return false;
}

function HandelLogin()
{

	if (http.readyState == 4)
	{
	var response = http.responseText;
	response=response.trim();
	
	
		if (response=='Success')
		{
		document.getElementById('DivLogin').innerHTML = 'Login successful redirecting...';
		setTimeout(function(){ window.location='index.php'; }, 2000);
		}
		else if (response.match('invalid'))
		{
		document.getElementById('DivLogin').innerHTML = '<span style=\'color:#FF0000;\'>'+response+'</span>';
		}
		else
		{
		document.getElementById('DivLogin').innerHTML = response;
		}
		
		setTimeout(function(){ document.getElementById('DivLogin').innerHTML='' ; }, 5000);

	}
	
	
}


function CheckAuth()
{
	var Username=document.getElementById('Username').value;

	http=Ajax();http.abort();
	http.open(\"POST\", \"ajax/auth.php\",true);
	http.setRequestHeader(\"Content-Type\", \"application/x-www-form-urlencoded\");
	http.onreadystatechange = HandelCheckAuth;
	http.send('Username='+Username);
	
return false;
}


function HandelCheckAuth()
{

	if (http.readyState == 4)
	{
	var response = http.responseText;
		
		if (response=='1')
		{
		document.getElementById('GoogleAuth').style.display='';
		}
		else
		{
		document.getElementById('GoogleAuth').style.display='none';
		}	
	}
	
}





</script>

</body>
</html>

";
}

?>