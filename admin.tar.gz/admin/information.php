<?php

include "nav.php";
$Buttons="";
include "title.php";



		if ($Action=="Kernel")
		{
		$Error=SSH ("inxi -S -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Kernel and Distribution Information</b><br><pre>$Error</pre>";
		}
		elseif ($Action=="Model")
		{
		$Error=SSH ("inxi -M -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Laptop or PC Model Information</b><br><pre>$Error</pre>";
		}
		elseif ($Action=="CPU")
		{
		$Error=SSH ("inxi -C -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>CPU and CPU Speed Information</b><br><pre>$Error</pre>";
		
		$Error=SSH ("lscpu",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		
		$ErrorArray=explode("Flags:",$Error);
		$Error=$ErrorArray[0];

		$Error=htmlspecialchars($Error);
		$Error="<b>CPU hardware information</b><br><pre>$Error</pre>";
		}
		elseif ($Action=="Graphic")
		{
		$Error=SSH ("inxi -G -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Graphic Card Information</b><br><pre>$Error</pre>";
		
		}
		elseif ($Action=="Audio")
		{
		$Error=SSH ("inxi -A -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Audio/Sound Card Information</b><br><pre>$Error</pre>";
		
		}
		elseif ($Action=="Network")
		{
		$Error=SSH ("inxi -N -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Network Card Information</b><br><pre>$Error</pre>";
		
		}
		elseif ($Action=="Harddisk")
		{
		$Error=SSH ("inxi -D -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Hard Disk Information</b><br><pre>$Error</pre>";
		
		}
		elseif ($Action=="Partition")
		{
		$Error=SSH ("inxi -P -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Hard Disk Partition Details</b><br><pre>$Error</pre>";
		
		}
		
		elseif ($Action=="TotalMemoryUsage")
		{
		$Error=SSH ("inxi -I -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Monitor Linux Processes Memory Usage</b><br><pre>$Error</pre>";
		
		}

		elseif ($Action=="TopMemoryUsage")
		{
		$Error=SSH ("inxi -t m -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Monitoring (TOP 5) Processes by Memory Usage</b><br><pre>$Error</pre>";
		}
		elseif ($Action=="TopCPUUsage")
		{
		$Error=SSH ("inxi -t c -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Monitoring (TOP 5) Processes by CPU Usage</b><br><pre>$Error</pre>";
		}
		elseif ($Action=="CPUTemperature")
		{
		$Error=SSH ("inxi -s -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Monitor Linux CPU Temperature and Fan Speed</b><br><pre>$Error</pre>";
		}
		elseif ($Action=="Weather")
		{
		$Error=SSH ("inxi -w -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Find Weather Report in Linux</b><br><pre>$Error</pre>";
		}				
		elseif ($Action=="NetworkInterfaces")
		{
		$Error=SSH ("inxi -Nni -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Monitor Linux Network Interfaces</b><br><pre>$Error</pre>";
		}
		elseif ($Action=="RAID")
		{
		$Error=SSH ("inxi -R -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>Display RAID Details</b><br><pre>$Error</pre>";
		}
		else
		{
		$Error=SSH ("inxi -c 0",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		$Error="<b>System Information</b><br><pre>$Error</pre>";
		}
	

	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;

?>