<?php
$LNG['BandwidthLimit']="الحد الاقصى لمعدل نقل البيانات";
$LNG['MaxFTPAccounts']="الحد الاقصى لحسابات الـFTP";
$LNG['MaxEmailAccounts']="الحد الاقصى لحسابات البريد الإلكترونى";
$LNG['MaxSQLDatabases']="الحد الاقصى لعدد قواعد البيانات";
$LNG['MaxSubDomains']="الحد الاقصى للنطاقات الفرعية";
$LNG['MaxAliasDomains']="الحد الاقصى  للنطاقات المستعارة (Alias Domains)";
$LNG['MaxAddonDomains']="االحد الاقصى الحد الاقصى للنطاقات الإضافية (Addon Domains)";
$LNG['Domain']="اسم النطاق";
$LNG['Home']="الرئيسية";
$LNG['Welsh']="الولزية";
$LNG['Light']="فاتح";
$LNG['ServerConfiguration']="إعدادات الخادم";
$LNG['ApacheConfiguration']="تاعدادات الاباتشى";
$LNG['ApacheStatus']="حالة سيرفر الاباتشي";
$LNG['ServerInformation']="معلومات عن الخادم";
$LNG['ServerStatus']="متابعة حالة السيرفر";
$LNG['NetworkingSetup']="إعدادات الشبكة";
$LNG['Email']="البريد الإلكتروني";
$LNG['Databases']="قواعد البيانات";
$LNG['Metrics']="التقارير و الرسوم البيانية";
$LNG['Security']="الحماية";
$LNG['Scripts']="السكربتات و البرامج المجانية";
$LNG['Backup']="النسخ الاحتياطي";
$LNG['Help']="المساعدة";
$LNG['SystemReboot']="إعادة تشغيل الخادم";
$LNG['Create']="إنشاء";
$LNG['Turkey']="تركيا";
$LNG['SQLite']="قواعد البيانات SQLite";
$LNG['ListAccounts']="قائمة المواقع";

?>