<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ليس معك ترخيص</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
            text-align: center;
            flex-direction: column; /* عشان العناصر تيجي تحت بعض */
        }
        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px; /* مسافة بين الرسالة والزر */
        }
        h1 {
            color: #dc3545;
        }
        .whatsapp-button {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #25D366;
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .whatsapp-button:hover {
            background-color: #128C7E;
        }
        .trial-button {
            display: inline-block;
            padding: 12px 25px;
            background-color: #007bff; /* لون أزرق للزر */
            color: white;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            font-size: 18px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            margin-top: 15px; /* مسافة بين زر الواتساب وزر التجربة */
        }
        .trial-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ليس معك ترخيص لاستخدام هذه اللوحة</h1>
        <p>قم بالتواصل مع مدير اللوحة عبر واتساب ليتم فتح اللوحة</p>
        <a href="https://wa.me/+201070904250" class="whatsapp-button" target="_blank">تواصل عبر واتساب</a>
    </div>
    <a href="https://license.almutahida-ip.com/" class="trial-button" target="_blank">احصل على ترخيص تجريبي لمدة 7 أيام</a>
</body>
</html>