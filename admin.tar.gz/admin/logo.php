<?php
include "navigator.php";
$Buttons="";
include "title.php";

$Domain=ValidateDomain($_REQUEST['Domain']);

If ($Action=="delete")
{

	echo Error("Delete");

	
}


if ($_REQUEST['AliasDomain']!="")
{

}


	echo "

	<div class='DivInput {$Dir}DivInput'>
	<iframe src='iframe/logo.php' name=Upload frameborder='0' width='250' height=250 marginheight=0 marginwidth=0 scrolling='no'></iframe>
	</div>
	
	<form name=Form method=POST onsubmit='return Logo(this);' ENCTYPE='multipart/form-data' autocomplete='off' action='iframe/logo.php' target=Upload>
	<input type=hidden name=Edit value='$Edit'>

	
	<div class='DivInput {$Dir}DivInput'>Logo<br>
	
	<input type='file' name=FileName>
	
	</div>
	
	<div id=DivSubmit class=DivSubmit>

	<input type=submit value='Upload' Class=InputButton>

	</div>
	

	</form>

";

?>