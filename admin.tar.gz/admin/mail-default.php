<?php



include "navigator.php";
$Buttons="";
include "title.php";
	
Echo "
<div class=UnderNavigator>
<img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>Catch any email that is sent to an invalid email address for your domain.
</div>
";

if ($_REQUEST['Email']!="")
{
include "access.php";

$Domain=ValidateDomain($_REQUEST['Domain']);
$Email=ValidateEmail($_REQUEST['Email']);

	if ($Email=="")
	{
	// Discard the email
	$Email="-";
	
	$Error=SSH ("/go/mail $Email - $Domain default",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	}
	else
	{
	$Error=SSH ("/go/mail $Email - $Domain default",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	}
	
}


	Echo "
	<form name=Form method=POST onsubmit='return DefaultAddress(this);' autocomplete='off' action='$CurrentFileName'>
	";
	
	
	if (stristr($_SESSION['SessionUsername'],"."))
	{
	$Output=SSH ("grep '^@{$_SESSION['SessionUsername']} ' /etc/postfix/vmail_aliases",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	else
	{
		if (filter_var($Domain,FILTER_VALIDATE_IP)) 
		{
			$IPValidate=1;
		}
		else
		{
		$Output=SSH ("grep '^@$Domain ' /etc/postfix/vmail_aliases",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}		
	}
	
	if (stristr($Output," "))
	{
		$OutputArray=explode(" ",$Output);

		$Domain=$OutputArray[0];
		$Domain=str_replace("@","",$Domain);

		$Email=$OutputArray[1];
	}
	else
	{
	$Domain="";
	$Email="";
	}
	
	echo "
	<div <div class='TitleB {$Dir}TitleB'>
	
	Send all unrouted email for the following domain:	
	
	</div>
	
	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}<br>

	";


		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['Domain'];
		}
		
		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['AddonDomain'];
		}
		
		sort($Domains);
		
		echo "
		<select name='Domain' id='Domain' onchange='DefaultEmail()' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{
			if ($Domain==$_REQUEST['Domain'])
			{
			echo "<option value='$Domain' selected>$Domain</option>";
			}
			else
			{
			echo "<option value='$Domain'>$Domain</option>";
			}
		}

		echo "</select>
	

	</div>


	<div class='DivInput {$Dir}DivInput'>{$LNG['ForwardToEmailAddress']}<br>
	<input type='text' name='Email' id='Email' value='$Email' class=InputText maxlength=100>
	</div>

	<Div id=DivSubmit Class=DivSubmit>
	<input type=submit value='{$LNG['Save']}' Class=InputButton>
	</div>

	

</form>

";

?>