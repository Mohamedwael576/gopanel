<?php
include "nav.php";
$Buttons="<a href='javascript:Load(\"$CurrentFileName?Action=Outlook&Page=$Page\")' class='ButtonB {$Dir}ButtonB'>{$LNG['SendIMAPConfiguration']}</a>";
include "title.php";

if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP)) 
{
	$ServerIP=SSH ("wget -qO- checkip.amazonaws.com",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
}
else 
{
    $ServerIP=$_SERVER['HTTP_HOST'];
    $ServerIP=str_replace(":2020","",$ServerIP);
}

if ($_SESSION['SessionUsername']=="root")
{
	if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
	{	
	echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['AccessWebmailDirectly']} <a href='https://{$_SERVER['HTTP_HOST']}:2025' target='_blank'>https://{$_SERVER['HTTP_HOST']}:2025</a></div>";
	}
	else
	{
	echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['AccessWebmailDirectly']} <a href='http://$ServerIP:2024' target='_blank'>http://$ServerIP:2024</a></div>";	
	}
}
else
{	
echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['AccessWebmailDirectly']} <a href='https://webmail.{$_SESSION['SessionDomain']}' target='_blank'>https://webmail.{$_SESSION['SessionDomain']}</a></div>";
}

$Domain=ValidateDomain($_REQUEST['Domain']);

$User=ValidateUsername($_REQUEST['User']);
$Pass=ValidatePassword($_REQUEST['Pass']);
$Email=ValidateEmail($_REQUEST['Email']);

$User=strtolower($User);
$Email=strtolower($Email);

$Restore=intval($_REQUEST['Restore']);
$Mintue=intval($_REQUEST['Mintue']);

if ($_REQUEST['Action']=="Outlook")
{

	if ($_SESSION['SessionType']="Website")
	{
	$Error=SSH ("/go/outlook all {$_SESSION['SessionDomain']}",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);	
	}
	else
	{
	$Error=SSH ("/go/outlook all",$_SESSION['SessionSSHUsename'],$_SESSION['SessionSSHPassword']);
	}
	
	echo Error("Email has been sent");

}

if ($_REQUEST['Action']=="Troubleshoot")
{
	$Error=SSH ("/go/troubleshoot mail $Domain $Email",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	echo Error("$Error");

	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

	exit;
}


if ($_REQUEST['Action']=="Admin")
{

	if ($_REQUEST['Admin']=="1")
	{
		SQL("update Mail set Admin=0 where Email='$Email'");	
	}
	else
	{
		SQL("update Mail set Admin=1 where Email='$Email'");
	}

}

If ($Delete==1 and $Step==1)
{
	echo Error("Delete \"{$Email}\" ? <a href=\"javascript:Load('$CurrentFileName?Delete=1&ControlID=$ServiceID&Domain=$Domain&Username=$Username&Email=$Email&Step=2','$ControlID')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName?ControlID=$ControlID','$ControlID')\" class=Action>No</a>");
	
	exit;
}

if ($Delete==1 and $Step==2)
{
	include "access.php";

	$Error=SSH ("/go/mail $Email AnyPassword $Domain delete --norestart",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Error=Error("$Error");	
}

if ($Action=="suspend" or $Action=="unsuspend")
{
	$Error=SSH ("/go/mail $Email AnyPassword $Domain $Action",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);	
	$Error=Error("$Error");	
}

If ($Restore==1 and $Step==1)
{
	echo "
	<div class='DivInput {$Dir}DivInput'>
	
		<div style='margin-bottom:10px'>Restore Email Messages ($Email):</div>

		<label class=Label onclick='Load(\"$CurrentFileName?Restore=1&Step=2&Domain=$Domain&Email=$Email&Mintue=360&Page=$Page\")'> 6 Hours Ago
			<input type='radio' name='Restore' value='$Email'>
			<span class='Radio'></span>
		</label>

		<label class=Label onclick='Load(\"$CurrentFileName?Restore=1&Step=2&Domain=$Domain&Email=$Email&Mintue=720&Page=$Page\")'> 12 Hours Ago
			<input type='radio' name='Restore' value='$Email'>
			<span class='Radio'></span>
		</label>

		<label class=Label onclick='Load(\"$CurrentFileName?Restore=1&Step=2&Domain=$Domain&Email=$Email&Mintue=1440&Page=$Page\")'> 1 Day Ago
			<input type='radio' name='Restore' value='$Email'>
			<span class='Radio'></span>
		</label>

		<label class=Label onclick='Load(\"$CurrentFileName?Restore=1&Step=2&Domain=$Domain&Email=$Email&Mintue=2880&Page=$Page\")'> 2 Days Ago
			<input type='radio' name='Restore' value='$Email'>
			<span class='Radio'></span>
		</label>
		
		<label class=Label onclick='Load(\"$CurrentFileName?Restore=1&Step=2&Domain=$Domain&Email=$Email&Mintue=4320&Page=$Page\")'> 3 Days Ago
			<input type='radio' name='Restore' value='$Email'>
			<span class='Radio'></span>
		</label>
		
		<label class=Label onclick='Load(\"$CurrentFileName?Restore=1&Step=2&Domain=$Domain&Email=$Email&Mintue=10080&Page=$Page\")'> 1 Week Ago
			<input type='radio' name='Restore' value='$Email'>
			<span class='Radio'></span>
		</label>

		<label class=Label onclick='Load(\"$CurrentFileName?Restore=1&Step=2&Domain=$Domain&Email=$Email&Mintue=0&Page=$Page\")'> All
			<input type='radio' name='Restore' value='$Email'>
			<span class='Radio'></span>
		</label>

	</div>

	";
	
}
	
If ($Restore==1 and $Step==2)
{
	$Error=SSH ("/go/mail $Email $Mintue $Domain restore",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$Error=Error("$Error");	
}

if ($_REQUEST['User']!="")
{

	if ($DemoPassword!="")
	{
	echo Error($LNG['ThisFunctionalityNotAvailableDemoMode']);
	exit;
	}


	$Result = SQL("select Domain,EmailNo from Site where Domain='$Domain'");
	foreach ($Result as $Row)
	{
		$Domain=$Row['Domain'];
		$Username=$Row['Username'];
	
		if ($Row['EmailNo']==-1)
		{
		echo "<div class='UnderTitle'>{$LNG['ThisFeatureHasBeenDisabledYourAdministrator']}</div>";
		exit;
		}
	
	}
	
	include "access.php";

	$Email=$User."@".$Domain;

	if ($Edit==1)
	{
	$Error=SSH ("/go/mail $Email $Pass $Domain edit",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	else
	{
	$Error=SSH ("/go/mail $Email $Pass $Domain add",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	$Error=Error("$Error");
	
	$Edit="";
}

	$User="";
	$Pass="";
	if ($Edit==1)
	{
		$Sql = "select * from Mail where Email='$Email'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{ 
			$EmailArray=explode("@",$Row['Email']);
			$User=$EmailArray[0];
			$Domain=$EmailArray[1];
			
			$Pass="";

		}
		

		if ($_SESSION['SessionPassword']=="demo")
		{
		$Password="********";
		}
		
	}

	$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
	foreach ($Result as $Row)
	{
	$Account['Domain'][]=$Row['Domain'];
	$Account['Username'][]=$Row['Username'];
	}
	
	$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
	foreach ($Result as $Row)
	{
	$Account['Domain'][]=$Row['Domain'];
	$Account['Username'][]=$Row['Username'];		
	}

	if (is_array($Account['Domain']))
	{
		array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);
	

		$SelectDomain.="<select name='Domain' id='Domain' class=Select>";
		for ($E=0;$E<count($Account['Domain']);$E++)
		{
			if ($Account['Domain'][$E]==$_REQUEST['Domain'])
			{
			$SelectDomain.="<option value='{$Account['Domain'][$E]}' selected>{$Account['Domain'][$E]}</option>";
			}
			else
			{
			$SelectDomain.="<option value='{$Account['Domain'][$E]}'>{$Account['Domain'][$E]}</option>";
			}
		}

		$SelectDomain.="</select>";

	}
	else
	{
		echo Error("There are no websites. <a href=\"javascript:Load('site.php')\" class=Action>{$LNG['CreateNewAccount']}</a>");
		exit;
	}

	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;


	if($Edit!=1)
	{
	
		include "search.php";

		$Header=DesignCode($Header,"$Control (Header)");
		echo $Header;

		$Table="Mail";$Field="RecycleBin=0";
		$DefaultSortBy="Email";
		$DefaultDirection=="ASC";
		include "include/sql.php";
		
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		
			$MailID=$Row['MailID'];
			$Domain=$Row['Domain'];
			$Username=$Row['Username'];

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			if ($Row['Suspend']==1)
			{
			$TDColor="TdEr";
			}
			
			$SerialNo=(($Page-1)*$PageNo)+($X+1);
			
			if ($Row['TimeStamp']>=1)
			{
			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);
			}


			if ($Row['Admin']==1)
			{
			$AdminCode= "
			<label class='switch' onclick=\"javascript:Load('$CurrentFileName?Action=Admin&Admin={$Row['Admin']}&Domain={$Row['Domain']}&Email={$Row['Email']}&Page=$Page')\">
			<input type='checkbox' checked>
			<span class='slider round'></span>
			</label>	
			";
			}
			else
			{
			$AdminCode="
			<label class='switch' onclick=\"javascript:Load('$CurrentFileName?Action=Admin&Admin={$Row['Admin']}&Domain={$Row['Domain']}&Email={$Row['Email']}&Page=$Page')\">
			<input type='checkbox'>
			<span class='slider round'></span>
			</label>	
			";
			}


			if ($Row['Suspend']==0)
			{
			$SuspendCode= "
			<label class='switch' onclick=\"javascript:Load('$CurrentFileName?Action=suspend&Domain=$Domain&Username=$Username&Email={$Row['Email']}&Page=$Page')\">
			<input type='checkbox' checked>
			<span class='slider round'></span>
			</label>	
			";
			}
			else
			{
			$SuspendCode="
			<label class='switch' onclick=\"javascript:Load('$CurrentFileName?Action=unsuspend&Domain=$Domain&Username=$Username&Email={$Row['Email']}&Page=$Page')\">
			<input type='checkbox'>
			<span class='slider round'></span>
			</label>	
			";
			}

			echo DesignCode($Loop,"$Control (Loop)");
			
			
			$X++;
			
		}
		


		$Footer=DesignCode($Footer,"$Control (Footer)");
		echo $Footer;
		
		
		
	}


echo "
</div>
";

	
?>