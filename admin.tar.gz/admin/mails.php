<?php




include "navigator.php";

if (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP)) 
{
	$ServerIP=SSH ("wget -qO- checkip.amazonaws.com",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
} 
else 
{
    $ServerIP=$_SERVER['HTTP_HOST'];
    $ServerIP=str_replace(":2020","",$ServerIP);
}


if ($_SESSION['SessionUsername']=="root")
{
	if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
	{	
	echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['AccessWebmailDirectly']} <a href='https://{$_SERVER['HTTP_HOST']}:2025' target='_blank'>https://{$_SERVER['HTTP_HOST']}:2025</a></div>";
	}
	else
	{
	echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['AccessWebmailDirectly']} <a href='http://$ServerIP:2024' target='_blank'>http://$ServerIP:2024</a></div>";	
	}
}
else
{	
echo "<div class=UnderNavigator><img src='theme/{$_SESSION['SessionTheme']}/image/info.svg' height=24 style='vertical-align:middle;padding-$OAlign:8px'>{$LNG['AccessWebmailDirectly']} <a href='https://webmail.{$_SESSION['SessionDomain']}' target='_blank'>https://webmail.{$_SESSION['SessionDomain']}</a></div>";
}


$Buttons="<a href='http://$ServerIP/roundcube' target='_blank' class='ButtonB {$Dir}ButtonB'>Roundcube</a><a href='http://$ServerIP/rainloop' target='_blank' class='ButtonB {$Dir}ButtonB'>RainLoop</a>";

if (file_exists("/panel/horde/index.php"))
{
$Buttons.="<a href='http://$ServerIP/horde' target='_blank' class='ButtonB {$Dir}ButtonB'>Horde</a>";
}

$Buttons.="<a href='http://$ServerIP/squirrelmail' target='_blank' class='ButtonB {$Dir}ButtonB'>SquirrelMail</a>";

include "title.php";

$Pass=ValidatePassword($_REQUEST['Pass']);

$Username=ValidateUsername($_REQUEST['Username']);

$Emails=trim($_REQUEST['Emails']);
$Emails=strtolower($Emails);

if ($_REQUEST['Action']=="Troubleshoot")
{

	$Email=trim($_REQUEST['Email']);
	
	$Error=SSH ("/go/troubleshoot mail $Username $Email",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	echo Error("$Error");

	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

	exit;
}


if ($_REQUEST['Action']=="Admin")
{

	$Email=trim($_REQUEST['Email']);

	if ($_REQUEST['Admin']=="1")
	{
		$Sql = "update Mail set Admin=0 where Email='$Email'";
		$Result = SQL($Sql);	
	}
	else
	{
		$Sql = "update Mail set Admin=1 where Email='$Email'";
		$Result = SQL($Sql);		
	}

}

If ($Delete==1 and $Step==1)
{
	$Email=trim($_REQUEST['Email']);

	echo Error("Delete \"{$Email}\" ? <a href=\"javascript:Load('$CurrentFileName?Delete=1&ControlID=$ServiceID&Username=$Username&Email=$Email&Step=2','$ControlID')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName?ControlID=$ControlID','$ControlID')\" class=Action>No</a>");
	
	exit;
}

if ($Delete==1 and $Step==2)
{
	$Email=trim($_REQUEST['Email']);
	
	include "access.php";

	$Error=SSH ("/go/mail $Email AnyPassword $Username delete",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
	
}

if ($_REQUEST['Emails']!="")
{

	if ($DemoPassword!="")
	{
	echo Error("This functionality is not available in demo mode.");
	exit;
	}

	$Sql = "select EmailNo from Site where Username='$Username'";
	$Result = SQL($Sql);
	foreach ($Result as $Row)
	{
		if ($Row['EmailNo']==-1)
		{
		echo "<div class='UnderTitle'>This feature has been disabled by your administrator.</div>";
		exit;
		}
	
	}
	
	$EmailsArray=explode(",",$Emails);
	
	foreach ($EmailsArray as &$Email) 
	{
		if ($_SESSION['SessionUserID']==1 or stristr($Email,$_SESSION['SessionDomain']) or stristr($Owner,"'$Domain'"))
		{
		
			$DomainArray=explode("@",$Email);
			$Domain=$DomainArray[1];
			
			$Sql = "select Username from Site where Domain='$Domain'";
			$Result = SQL($Sql);
			foreach ($Result as $Row)
			{
			$Username=$Row['Username'];
			}
			
			$Error=SSH ("/go/mail $Email $Pass $Username add --norestart",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
			echo Error("$Error");
			
		}
		
		$Error=SSH ("/go/webmail restart",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		
	}

}


	Echo "

	<form name=Form method=POST onsubmit='return CreateMultipleEmail(this);' autocomplete='off' action='$CurrentFileName'><input type=hidden name=ServiceControl value='$ServiceControl'>
	<input type=hidden name=ServiceControl value='$ServiceControl'>

	<div class='DivInput {$Dir}DivInput'>{$LNG['EmailAccounts']}<br>	
	<textarea type='text' rows=10 name='Emails' maxlength=1000 placeholder='info@domain.com\nsales@domain.com\nsupport@domain.com' class='TextArea DivScroll'></textarea>
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Password']}<br>
	<input type='text' name='Pass' id='Password' pattern='(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}' title='Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters' required maxlength=100 class=InputText>
	</div>
	
	<div id='message'>
	  <p id='letter' 	class='invalid'>A <b>lowercase</b> letter</p>
	  <p id='capital'	class='invalid'>A <b>capital (uppercase)</b> letter</p>
	  <p id='number' 	class='invalid'>A <b>number</b></p>
	  <p id='length' 	class='invalid'>Minimum <b>8 characters</b></p>
	</div>

	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['Create']}' Class=InputButton>
	</div>

</form>


";


	
		include "search.php";

		Echo "
		<div class=DivXTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

		<THEAD>
		
		<tr>
	
		<th width='2%' height=40>

		</th>
		
		<th align='$DAlign' width='38%'>
		<a href=\"javascript:Load('$CurrentFileName?&SortBy=Email')\">{$LNG['Email']}</a>
		</th>
		
		<th align='$DAlign' width='20%'>
		<a href=\"javascript:Load('$CurrentFileName?&SortBy=TimeStamp')\">{$LNG['CreatedDate']}</a>
		</th>

		<th width='40%'>
		
		</span>
		</th>

		</tr>
		
		</THEAD>

		";



		$Table="Mail";$Field="RecycleBin=0";
		$DefaultSortBy="Email";
		$DefaultDirection=="ASC";
		include "include/sql.php";
		
		$X=0;
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
			
			$MailID=$Row['MailID'];
		
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$SerialNo=(($Page-1)*$PageNo)+($X+1);
			
			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

			if ($Row['Admin']==1)
			{
			$AdminStyle="ActionB";
			}
			else
			{
			$AdminStyle="Action";
			}
			
			Echo "
			<tr name=R$i id=R$i divid=Find find='{$Row['Email']}' class='$TDColor'>

			<TD align='middle'>
			$SerialNo
			</TD>

			<TD><a href='http://{$Row['Domain']}/mail' target='_blank'>{$Row['Email']}</a></TD>

			<TD>$CreatedDate</TD>
			
			<TD align='$OAlign'>
			
			<a href=\"javascript:Load('mail.php?Edit=1&Username={$Row['Username']}&Email={$Row['Email']}&Page=$Page')\" class=Action>Edit</a>
			<a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=1&Username={$Row['Username']}&Email={$Row['Email']}&Page=$Page')\" class=Action>Delete</a>
			
			<a href=\"javascript:Load('$CurrentFileName?Action=Admin&Admin={$Row['Admin']}&Username={$Row['Username']}&Email={$Row['Email']}&Page=$Page')\" class=$AdminStyle>Admin</a>
			
			<a href=\"javascript:Load('contact.php?EmailTo={$Row['Email']}')\" class=Action>Contacts</a>
			<a href=\"javascript:Load('$CurrentFileName?Action=Troubleshoot&Username={$Row['Username']}&Email={$Row['Email']}&Page=$Page')\" class=Action>Troubleshoot Problems</a>
			
			</TD>
			";
			
		$X++;
		}
		

		if ($X!=0)
		{
		echo "</TBODY>";
		}

		echo "
		<TFOOT>

		<tr>

		<th align='$DAlign' colspan=2>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=2>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>

		</TABLE>
		</div>
		</form>


</div>
";

	
?>