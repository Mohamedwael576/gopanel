<?php
include "navigator.php";
$Buttons="";
include "title.php";

$SiteID=intval($_REQUEST['SiteID']);
$CheckList=$_REQUEST['CheckList'];

if (intval($PageNo)==0) {$PageNo=20;}

if ($_SESSION['SessionBlackhostUsername']!="root" and $_SESSION['SessionBlackhostUsername']!=$BlackhostUsername)
{

	if ($_SESSION['SessionResellerUsername']=="")
	{
	echo "
	Sorry, You Are Not Allowed to Access This Page
	";

	exit;
	}
}


$Date=date ("Y-m-d",mktime (date("G"),date("i")+$GMT,date("s"),date("m"),date("d"),date("Y")));

    
	include "search.php";
	
    Echo "
	<form name=CheckForm id=CheckForm action='$CurrentFileName'>
	<input type=hidden name=Action id=Action>
	

	
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing=0 width=100% class=Table>

	<THEAD>
	
	<tr>
	
    <TH align='$DAlign' width='35%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=Domain')\">{$LNG['Domain']}</a>
    </TH>

    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=SpaceUsed')\">{$LNG['DiskUsage']}</a>
    </TH>
	
    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=BandwidthUsed')\">{$LNG['BandwidthUsage']}</a>
    </TH>

    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=TimeStamp')\">{$LNG['CreatedDate']}</a>
    </TH>

    <TH width='5%'>
 
    </TH>
	
	</tr>
	
	</THEAD>
	
	";
	


	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";
    

	$X=0;
    $Result = $PDO->query($Sql)->fetchAll();
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	$Domain=$Row['Domain'];
		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}





    ECHO "
	<tr class='$TDColor' divid=Find find='{$Row['Domain']}-{$Row['Email']}'>

    <TD>
    <a href='http://{$Row['Domain']}' target='_blank'>{$Row['Domain']}</a>
    </td>
	";
	
	$SpaceUsed=FormatSize($Row['SpaceUsed']);
	
	if ($Row['DiskSpace']==0) 
	{
	$DiskSpace=$LNG['Unlimited'];
	}
	else
	{
	$DiskSpace=FormatSize($Row['DiskSpace']);
	}
	
	echo "
	<TD>
    
    $SpaceUsed / $DiskSpace
    </td>
	";

	$BandwidthUsed=FormatSize($Row['BandwidthUsed']);
	
	if ($Row['Bandwidth']==0) 
	{
	$Bandwidth=$LNG['Unlimited'];
	}
	else
	{
	$Bandwidth=FormatSize($Row['Bandwidth']);
	}

	echo "
	<TD>
    $BandwidthUsed / $Bandwidth
    </td>
	";

	$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);
	
	echo "
	<TD>
    $CreatedDate
    </td>
	
	<TD align='$OAlign'>
	<a title='Modify $Domain' href=\"javascript:Load('site.php?Edit=1&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\" class=Action>{$LNG['Modify']}</a>
    </td>
    
	</tr>
	";
	
	$X++;
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "
	<TFOOT>



	<th align='$DAlign' colspan=2>
	Showing $X of $RowsNo records.
	</th>
	
	<th align='$OAlign' colspan=3>
	";
			
	include "pages.php";

	echo "
	</th>



	</TFOOT>

	</TABLE>
	</div>
	</form>
	";
	



	
?>