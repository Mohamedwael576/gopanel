<?php



include "nav.php";
$Buttons="<a href='javascript:Load(\"$CurrentFileName?Action=GetZoneID&Page=$Page\")' class='ButtonB {$Dir}ButtonB'>{$LNG['GetAllZoneID']}</a>";
include "title.php";



$SiteID=intval($_REQUEST['SiteID']);
$CheckList=$_REQUEST['CheckList'];

if (intval($PageNo)==0) {$PageNo=20;}

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	if ($_SESSION['SessionResellerUsername']=="")
	{
	echo "
	Sorry, You Are Not Allowed to Access This Page
	";

	exit;
	}
}



$Date=date ("Y-m-d",mktime (date("G"),date("i")+$GMT,date("s"),date("m"),date("d"),date("Y")));

    
	include "search.php";
	
	$Header=DesignCode($Header,"$Control (Header)");
	echo $Header;

	

	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";


	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	
	
	$SiteID=$Row['SiteID'];
	$Domain=$Row['Domain'];
	$Username=$Row['Username'];

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}

		$SpaceUsed=FormatSize($Row['SpaceUsed']);
		if ($Row['DiskSpace']==0) 
		{
		$DiskSpace=$LNG['Unlimited'];
		}
		else
		{
		$DiskSpace=FormatSize($Row['DiskSpace']);
		}
		
		$BandwidthUsed=FormatSize($Row['BandwidthUsed']);
		if ($Row['Bandwidth']==0) 
		{
		$Bandwidth=$LNG['Unlimited'];
		}
		else
		{
		$Bandwidth=FormatSize($Row['Bandwidth']);
		}

		$FTPNoUsed=RowCount("SELECT * FROM Ftp where Username='$Username'");
		if ($Row['FTPNo']==0)
		{
		$FTPNo=$LNG['Unlimited'];
		}
		elseif ($Row['FTPNo']==-1)
		{
		$FTPNo=$LNG['Disabled'];
		}
		else
		{
		$FTPNo=$Row['FTPNo'];
		}


		$EmailNoUsed=RowCount("SELECT * FROM Mail where Username='$Username'");
		if ($Row['EmailNo']==0)
		{
		$EmailNo=$LNG['Unlimited'];
		}
		elseif ($Row['EmailNo']==-1)
		{
		$EmailNo=$LNG['Disabled'];
		}
		else
		{
		$EmailNo=$Row['EmailNo'];
		}
		
		
		$DatabaseNoUsed=RowCount("SELECT * FROM Mysql where Username='$Username'");
		if ($Row['DatabaseNo']==0)
		{
		$DatabaseNo=$LNG['Unlimited'];
		}
		elseif ($Row['DatabaseNo']==-1)
		{
		$DatabaseNo=$LNG['Disabled'];
		}
		else
		{
		$DatabaseNo=$Row['DatabaseNo'];
		}
		
		$SubDomainNoUsed=RowCount("SELECT * FROM Subdomain where Username='$Username'");
		if ($Row['SubDomainNo']==0)
		{
		$SubDomainNo=$LNG['Unlimited'];
		}
		elseif ($Row['SubDomainNo']==-1)
		{
		$SubDomainNo=$LNG['Disabled'];
		}
		else
		{
		$SubDomainNo=$Row['SubDomainNo'];
		}

		$AliasNoUsed=RowCount("SELECT * FROM Alias where Domain='$Domain'");
		if ($Row['AliasNo']==0)
		{
		$AliasNo=$LNG['Unlimited'];
		}
		elseif ($Row['AliasNo']==-1)
		{
		$AliasNo=$LNG['Disabled'];
		}
		else
		{
		$AliasNo=$Row['AliasNo'];
		}
		
		$AddonNoUsed=RowCount("SELECT * FROM Addon where Username='$Username'");
		if ($Row['AddonNo']==0)
		{
		$AddonNo=$LNG['Unlimited'];
		}
		elseif ($Row['AddonNo']==-1)
		{
		$AddonNo=$LNG['Disabled'];
		}
		else
		{
		$AddonNo=$Row['AddonNo'];
		}
		

	echo DesignCode($Loop,"$Control (Loop)");

	
	$X++;
	}
	
	$Footer=DesignCode($Footer,"$Control (Footer)");
	echo $Footer;	

	
?>