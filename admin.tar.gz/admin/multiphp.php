<?php
include "nav.php";
$Buttons="";
include "title.php";



$SiteID=intval($_REQUEST['SiteID']);
$Domain=ValidateDomain($_REQUEST['Domain']);

if (intval($PageNo)==0) {$PageNo=20;}

if ($_REQUEST['PHPVersion']!="")
{
$Username=ValidateUsername($_REQUEST['Username']);
$Domain=ValidateDomain($_REQUEST['Domain']);
$PHPVersion=ValidateVersion($_REQUEST['PHPVersion'],"Invalid PHP Version.");

include "access.php";

	$Error=SSH ("/go/multiphp $Domain $PHPVersion",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	
}


	if ($Action=="Enable")
	{
		$Result = SQL("select * from Site where Domain='$Domain'");
		foreach ($Result as $Row)
		{
		$PHPVersion=$Row['PHPVersion'];
		}

	
		SQL("UPDATE Site set FPM='1' where Domain='$Domain'");
	
		$Error=SSH ("/go/apache $Domain $PHPVersion",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	
	if ($Action=="Disable")
	{
		$Result = SQL("select * from Site where Domain='$Domain'");
		foreach ($Result as $Row)
		{
		$PHPVersion=$Row['PHPVersion'];
		}

		SQL("UPDATE Site set FPM='0' where Domain='$Domain'");
	
		$Error=SSH ("/go/apache $Domain $PHPVersion",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("$Error");
	}
	

    
	include "search.php";
	
	$Header=DesignCode($Header,"$Control (Header)");
	echo $Header;
	
	$Output=SSH ("/go/multiphp Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	if (stristr($Output,"|"))
	{
	$OutputArray=explode("|",$Output);
	}
	else
	{
	$OutputArray[]=$Output;
	}
	
	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";


	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	
	$Username=$Row['Username'];
	$Domain=$Row['Domain'];
	$FPM=$Row['FPM'];

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}
		
		if ($FPM==1)
		{
		$FPMStatusCode="✔";
		}
		else
		{
		$FPMStatusCode="✖";
		}
		

		if ($FPM==1)
		{	
		$FPMCode="
		<label class='switch' onclick=\"Load('$CurrentFileName?Action=Disable&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
		<input type='checkbox' checked>
		<span class='slider round'></span>
		</label>
		";
		}
		else
		{
		$FPMCode="
		<label class='switch' onclick=\"Load('$CurrentFileName?Action=Enable&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
		<input type='checkbox'>
		<span class='slider round'></span>
		</label>
		";
		}
				
		$SelectVersion="";
		if ($FPM==1)
		{
			foreach ($OutputArray as &$PHPVersion) 
			{
				$PHPVersion=trim($PHPVersion);
				$ShowPHPVersion=str_replace("php","",$PHPVersion);
				$ShowPHPVersion=str_replace(".","",$ShowPHPVersion);

				$Version=substr($ShowPHPVersion,0,1).".".substr($ShowPHPVersion,1,1);

				if ($Row['PHPVersion']==$PHPVersion)
				{
				$SelectVersion.="
				<label class=Label>PHP $Version
					<input type='radio' name=PHPVersion{$SiteID} id=PHPVersion{$SiteID} value='$PHPVersion' checked='checked'>
					<span class='Radio'></span>
				</label>
				";
				}
				else
				{
				$SelectVersion.="
				<label class=Label onclick=\"Load('$CurrentFileName?Username=$Username&Domain=$Domain&PHPVersion=$PHPVersion&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">PHP $Version
					<input type='radio' name=PHPVersion{$SiteID} id=PHPVersion{$SiteID} value='$PHPVersion'>
					<span class='Radio'></span>
				</label>
				";
				}
				
			}

		}
	
		echo DesignCode($Loop,"$Control (Loop)");
	
		$X++;
	}
	

	$Footer=DesignCode($Footer,"$Control (Footer)");
	echo $Footer;


	
?>