<?php
include "nav.php";
$Buttons="";
include "title.php";



if ($_REQUEST['Domain']!="")
{
$Domain=ValidateDomain($_REQUEST['Domain']);


		if (!function_exists("ssh2_connect"))
		{
			echo Error("SSH2 PHP extension is not available.");
			exit;
		}


		$Error=SSH ("dig +noall +answer -t mx $Domain",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("<pre>MX Record(s): $Domain\n$Error</pre>");
		
exit;

}


	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;
?>