<?php




include "nav.php";
$Buttons="<a href=\"phpmyadmin.php\" target='_blank' class='ButtonB {$Dir}ButtonB'>phpMyAdmin</a>";
include "title.php";


if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Go Panel Path";
	exit;
}

$Domain=ValidateDomain($_REQUEST['Domain']);

$Name=ValidateDatabaseName($_REQUEST['Name']);
$User=ValidateUsername($_REQUEST['User']);
$Pass=ValidatePassword($_REQUEST['Pass']);
$PHPMyAdmin=intval($_REQUEST['PHPMyAdmin']);
$Remote=intval($_REQUEST['Remote']);
$MysqlID=intval($_REQUEST['MysqlID']);

If ($Delete==1 and $Step==1)
{

	echo Error("Delete Database \"$Name\" ? <a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=2&Domain={$_REQUEST['Domain']}&Name={$_REQUEST['Name']}&ControlID=$ControlID&Page=$Page')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName?ServiceControl=$CurrentFileName?ControlID=$ControlID')\" class=Action>No</a>");
	exit;
	
}

if ($Delete==1 and $Step==2)
{
	include "access.php";

	$Error=SSH ("/go/mysql $Domain $Name AnyUser AnyPass AnyRemote delete",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");

	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

exit;
}

if ($User!="")
{
	include "access.php";

	if ($Edit==1)
	{
	$Error=SSH ("/go/mysql $Domain $Name $User $Pass $Remote edit",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
	}
	else
	{
	$Error=SSH ("/go/mysql $Domain $Name $User $Pass $Remote",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");	
	}

	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

exit;
}


	if ($Edit==1)
	{
		$Readonly="readonly";
	
		$Result = SQL("select * from Mysql where MysqlID='$MysqlID'");
		foreach ($Result as $Row)
		{
			$Domain=$Row['Domain'];
			$Username=$Row['Username'];
			$Name=$Row['Name'];
			$User=$Row['User'];
			$Pass="";
			$Remote=$Row['Remote'];
		
			if ($Remote==1)
			{
			$RemoteConnectionChecked="checked";
			}
		
		}
	}
	else
	{
		if ($_SESSION['SessionType']=="Website")
		{
		$NameArray=explode(".",$_SESSION['SessionUsername']);
		$Name=$NameArray[0]."_";
		$Name=str_replace("-","",$Name);
		
		$User=$Name;
		}
	}


	

	$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
	foreach ($Result as $Row)
	{
	$Account['Domain'][]=$Row['Domain'];
	$Account['Username'][]=$Row['Username'];
	}
	
	$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
	foreach ($Result as $Row)
	{
	$Account['Domain'][]=$Row['Domain'];
	$Account['Username'][]=$Row['Username'];
	}
	
	if (is_array($Account['Domain']))
	{
		array_multisort($Account['Domain'], SORT_ASC, SORT_STRING,$Account['Username'], SORT_NUMERIC, SORT_DESC);
		
		$SelectDomain="<select name='Domain' id='Domain' class=Select>";
		for ($E=0;$E<count($Account['Domain']);$E++)
		{
			if ($Account['Domain'][$E]==$_REQUEST['Domain'])
			{
			$SelectDomain.="<option value='{$Account['Domain'][$E]}' selected>{$Account['Domain'][$E]}</option>";
			}
			else
			{
			$SelectDomain.="<option value='{$Account['Domain'][$E]}'>{$Account['Domain'][$E]}</option>";
			}
		}
		
		$SelectDomain.="</select>";

		$Content=DesignCode($Content,"$Control (Content)");
		echo $Content;

	}
	else
	{

		echo Error("There are no websites. <a href=\"javascript:Load('site.php')\" class=Action>{$LNG['CreateNewAccount']}</a>");
		exit;
	}
		





	if($Edit!=1)
	{

		include "search.php";
				
		$Header=DesignCode($Header,"$Control (Header)");
		echo $Header;

		$Table="Mysql";$Field="MysqlID>=1";
		$DefaultSortBy="Name";
		$DefaultDirection=="ASC";
		include "include/sql.php";
		

		$X=0;		
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
			
		
			$MysqlID=$Row['MysqlID'];
			
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$SerialNo=(($Page-1)*$PageNo)+($X+1);

			$Size=FormatSize($Row['Size']);

			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);



			echo DesignCode($Loop,"$Control (Loop)");
			
			
		$X++;
		}
				
		$Footer=DesignCode($Footer,"$Control (Footer)");
		echo $Footer;
		
		
	}

?>