<?php
include "nav.php";
$Buttons="";
include "title.php";



if ($_REQUEST['Domain']!="")
{
$Domain=ValidateDomain($_REQUEST['Domain']);

		$Error=SSH ("dig +noall +answer -t ns $Domain",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error("<pre>Nameserver: $Domain\n\n$Error</pre>");
		


exit;

}

	
	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;




?>