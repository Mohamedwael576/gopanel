<?php
include "navigator.php";
$Buttons="	<a href=\"javascript:Load('httplog.php')\" class='ButtonB {$Dir}ButtonB'>HTTP Logs</a>";
include "title.php";

	Echo "
	<div class=DivInfo>
	";
	
		$OS=@file_get_contents("/panel/linux/os.db");
		$OS=trim($OS);
		if ($OS=="CentOS" or $OS=="Fedora")
		{
		$Error=SSH ("systemctl status nginx",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}
		else
		{
		$Error=SSH ("systemctl status nginx",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		}
		echo "<b>NGINX Status</b><pre style='width:100%;overflow:hidden'>$Error</pre>";
		
		
	echo "
	</div>
	";

?>