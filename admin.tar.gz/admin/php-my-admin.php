<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
$CurrentFileName=basename ($_SERVER['PHP_SELF']);
include("include/function/function.php");
include("../include/config/config.php");





$Name=$_REQUEST['Name'];
$Username=ValidateUsername($_REQUEST['Username']);
$Password=ValidatePassword($_REQUEST['Password']);
$PHPMyAdmin=$_REQUEST['PHPMyAdmin'];

$MysqlID=trim($_REQUEST['MysqlID']);

$Domain = preg_replace("/^www\./","",$_SERVER['SERVER_NAME']);

	if ($_SESSION['SessionSSHUsername']=="root")
	{
		
		if ($DemoPassword!="")
		{
		echo Error("This functionality is not available in demo mode.");
		exit;
		}
		
		setcookie ("CookiesMySQLUsername","root",time() + (86400 * 30), "/");
		setcookie ("CookiesMySQLPassword",$DBPass,time() + (86400 * 30), "/");
		
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
		{
			header("Location: https://$Domain/phpmyadmin");
		} 
		else 
		{
			header("Location: http://$Domain:2001");
		}
		
		
	}
	else
	{
		$RowsNo=RowCount("SELECT * FROM Mysql where Username='{$_SESSION['SessionUsername']}'");
	
		if ($RowsNo>=1)
		{			
			setcookie ("CookiesMySQLUsername",$_SESSION['SessionUsername'],time() + (86400 * 30), "/");
			setcookie ("CookiesMySQLPassword",$_SESSION['SessionSalt'],time() + (86400 * 30), "/");

			if (isset($_SERVER['HTTPS'])) 
			{
				header("Location: https://$Domain/phpmyadmin");
			} 
			else 
			{
				header("Location: http://$Domain:2001");
			}
		
		}
		else
		{
			echo Error("There are no databases associated with your account.");
		}
		
	}

?>