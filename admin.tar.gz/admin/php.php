<?php
include "nav.php";
$Buttons="<a href=\"javascript:Load('$CurrentFileName?Action=RestorePHPConfiguration&ControlID=$ControlID&Page=$Page','$ControlID')\" class='ButtonB {$Dir}ButtonB'>{$LNG['RestoreDefault']}</a>";
include "title.php";



if ($_REQUEST['Action']=="RestorePHPConfiguration")
{

	$Error=SSH ("/go/phpini restore",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	echo Error ("Restore default, Please wait...");
	
exit;
}


	$ErrorReporting = SSH ("/go/errorreporting Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$MemoryLimit=ini_get('memory_limit');
	$DisableFunctions=ini_get('disable_functions');
	$MaxExecutionTime=ini_get('max_execution_time');
	$MaxInputTime=ini_get('max_input_time');
	$MaxInputVars=ini_get('max_input_vars');
	$PostMaxSize=ini_get('post_max_size');
	$UploadMaxFilesize=ini_get('upload_max_filesize');
	$MaxFileUploads=ini_get('max_file_uploads');
	$SessionGcMaxlifetime=ini_get('session.gc_maxlifetime');
	$SessionSavePath=ini_get('session.save_path');

	$AllowUrlFopen=ini_get('allow_url_fopen');
	if ($AllowUrlFopen=="1" or $AllowUrlFopen=="on" or $AllowUrlFopen=="On") {$AllowUrlFopen="On";} else {$AllowUrlFopen="Off";}
	
	$AllowUrlInclude=ini_get('allow_url_include');
	if ($AllowUrlInclude=="1" or $AllowUrlInclude=="on" or $AllowUrlInclude=="On") {$AllowUrlInclude="On";} else {$AllowUrlInclude="Off";}

	$DisplayErrors=	SSH ("/go/displayerrors Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$DisplayErrors=trim($DisplayErrors);
	if ($DisplayErrors=="1" or $DisplayErrors=="on" or $DisplayErrors=="On") {$DisplayErrors="On";} else {$DisplayErrors="Off";}
	
	$DisplayStartupErrors=SSH ("/go/displaystartuperrors Return",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	$DisplayStartupErrors=trim($DisplayStartupErrors);
	if ($DisplayStartupErrors=="1" or $DisplayStartupErrors=="on" or $DisplayStartupErrors=="On") {$DisplayStartupErrors="On";} else {$DisplayStartupErrors="Off";}
	
	$EnableDl=ini_get('enable_dl');
	if ($EnableDl=="1" or $EnableDl=="on" or $EnableDl=="On") {$EnableDl="On";} else {$EnableDl="Off";}
	
	$FileUploads=ini_get('file_uploads');
	if ($FileUploads=="1" or $FileUploads=="on" or $FileUploads=="On") {$FileUploads="On";} else {$FileUploads="Off";}

	$ZlibOutputCompression=ini_get('zlib.output_compression');
	if ($ZlibOutputCompression=="1" or $ZlibOutputCompression=="on" or $ZlibOutputCompression=="On") {$ZlibOutputCompression="On";} else {$ZlibOutputCompression="Off";}
			


	$Content=DesignCode($Content,"$Control (Content)");
	echo $Content;


// End Scroll 
echo "
</div>
";


?>