<?php
include "nav.php";
$Buttons="";
include "title.php";



$Publish=$_REQUEST['Publish'];
$Unpublish=$_REQUEST['Unpublish'];
$SiteID=$_REQUEST['SiteID'];
$Action=$_REQUEST['Action'];
$CheckList=$_REQUEST['CheckList'];

$UserNo=RowCount("select * from Site where RecycleBin=0 $SearchSql");
    
If ($Publish==1)
{
include "access.php";

$Domain=ValidateDomain($_REQUEST['Domain']);


	$Error=SSH ("/go/publish $Domain publish $DBPassword",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	$Error=str_replace("\r","",$Error);
	$Error=str_replace("\n","",$Error);
	echo Error($Error);
	
	

	
}
	

If ($Unpublish==1)
{
include "access.php";
$Domain=ValidateDomain($_REQUEST['Domain']);

	$Error=SSH ("/go/publish $Domain unpublish $DBPassword",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	if (stristr($Error,"unpublished"))
	{
	$Error=str_replace("\r","",$Error);
	$Error=str_replace("\n","",$Error);
	echo Error($Error." &nbsp;&nbsp;&nbsp; <a href='$CurrentFileName?Publish=1&Domain=$Domain' class=Action>Undo</a>");	
	}
	else
	{
	echo Error($Error);
	}	
}


If ($Action=="Publish")
{
include "access.php";

	$CountCheckList=count($CheckList);

	for ($i=0 ;$i<$CountCheckList ; $i++)
	{

		$Sql = "delete from Site where SiteID='$CheckList[$i]'";
		$Result = SQL($Sql);
		
	}

	echo Error("Site(s) has been deleted.");
    

}



	include "search.php";

	$Header=DesignCode($Header,"$Control (Header)");
	echo $Header;

	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";


	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
		$SiteID=$Row['SiteID'];
		$Domain=$Row['Domain'];
		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}

		if ($Row['Unpublish']==1)
		{
		$TDColor="TdEr";
		}
			
		$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);
		
		$Status="Active";
		if ($Row['Suspend']==1)
		{
		$Status=$LNG['Suspended'];
		}
		elseif ($Row['Unpublish']==1)
		{
		$Status=$LNG['Unpublished'];
		}
		
		if ($Row['Suspend']==0)
		{
			if ($Row['Unpublish']==1)
			{
			$SuspendAction="<a href=\"javascript:Load('$CurrentFileName?Publish=1&Step=1&SiteID=$SiteID&Domain=$Domain')\" class=Action>{$LNG['Publish']}</a>";
			}
			else
			{
			$SuspendAction="<a href=\"javascript:Load('$CurrentFileName?Unpublish=1&Step=1&SiteID=$SiteID&Domain=$Domain')\" class=Action>{$LNG['Unpublish']}</a>";
			}
		}
		else
		{
			$SuspendAction=$LNG['Suspended'];
		}
		
		echo DesignCode($Loop,"$Control (Loop)");

	
	$X++;
	}
	
	$Footer=DesignCode($Footer,"$Control (Footer)");
	echo $Footer;	
	
?>