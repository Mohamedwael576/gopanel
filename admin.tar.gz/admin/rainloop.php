<?php
session_start();

include("include/function/function.php");
include("/panel/include/config/config.php");

$Domain = preg_replace("/^www\./","",$_SERVER['SERVER_NAME']);
$Domain = preg_replace("/^go\./","",$Domain);
$Domain = preg_replace("/^webmail\./","",$Domain);

$MailID=$_REQUEST['MailID'];

$Result = SQL("select * from Mail where MailID='$MailID'");
foreach ($Result as $Row)
{ 

	$Pass=$Row['Pass'];
	$Email=$Row['Email'];
	$EmailArray=explode("@",$Row['Email']);
	

}

if ($EmailArray[1]!=$_SESSION['SessionUsername'] and $_SESSION['SessionUsername']!="root")
{
echo "Please login...";
exit;
}


// Enable RainLoop Api and include index file 
$_ENV['RAINLOOP_INCLUDE_AS_API'] = true;
include '/panel/webmail/rainloop/index.php';

//
// Get sso hash
//
// @param string $email
// @param string $password
// @return string 
//

$ssoHash = \RainLoop\Api::GetUserSsoHash($Email, $Pass);


	if (stripos($_SERVER['HTTP_HOST'],"webmail.")===0)
	{
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
		{
			$URL="https://webmail.$Domain/rainloop/";
		}
		else
		{
			$URL="http://webmail.$Domain/rainloop/";	
		}
	}
	elseif (stristr($_SERVER['HTTP_HOST'],":2025"))
	{
		$URL="https://$Domain:2025/rainloop/";
	}
	elseif (stristr($_SERVER['HOST'],":2021") and stristr($Type,"|2021|"))
	{
		$URL="https://$Domain:2021/rainloop/";	
	}
	elseif (stripos($_SERVER['HTTP_HOST'],"go.")===0)
	{
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
		{
			$URL="https://go.$Domain/rainloop/";	
		}
		else
		{
			$URL="http://go.$Domain/rainloop/";	
		}
	}
	elseif (stristr($_SERVER['HTTP_HOST'],":2024"))
	{
		$URL="http://$Domain:2024/rainloop/";	
	}	
	elseif (stristr($_SERVER['HTTP_HOST'],":2020"))
	{
		$URL="http://$Domain:2020/rainloop/";
	}
	elseif (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP))
	{
		$URL="http://{$_SERVER['HTTP_HOST']}/rainloop/";
	}
	elseif (stristr($_SERVER['REQUEST_URI'],"/go/"))
	{
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
		{
			$URL="https://{$_SERVER['HTTP_HOST']}/rainloop/";
		}
		else
		{
			$URL="http://{$_SERVER['HTTP_HOST']}/rainloop/";	
		}
	}

	header("Location: $URL?sso&hash=".$ssoHash);

?>