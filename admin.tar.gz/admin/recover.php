<?php
include "nav.php";
$Buttons="";
include "title.php";



$SiteID=intval($_REQUEST['SiteID']);
$Restore=intval($_REQUEST['Restore']);
$Remove=intval($_REQUEST['Remove']);
$Action=$_REQUEST['Action'];
$CheckList=$_REQUEST['CheckList'];

	
$Username=ValidateUsername($_REQUEST['Username']);
$Domain=ValidateDomain($_REQUEST['Domain']);
	
	
	
// Remove forever
If ($Remove==1)
{
	include "access.php";

	$Error=SSH ("/go/delete $Username",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	
	
}


If ($Restore==1)
{
include "access.php";

		$Error=SSH ("/go/recover $Username",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		echo Error($Error);
		
}
	
	
	
If ($Action=="Delete")
{
	$CountCheckList=count($CheckList);

	for ($i=0 ;$i<$CountCheckList ; $i++)
	{
		$Domain=$CheckList[$i];

		include "access.php";

		$Sql = "select * from Site where SiteID='$Domain'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{

		$Error=SSH ("/go/delete {$Row['Domain']}",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		Echo Error("<h1>{$Row['Domain']}</h1>$Error");

		}

	}
	
	$Error=SSH ("/go/fpm",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
}

	
If ($Action=="Restore")
{
	$CountCheckList=count($CheckList);

	for ($i=0 ;$i<$CountCheckList ; $i++)
	{
		$Sql = "select * from Site where SiteID='{$CheckList[$i]}'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		$Error=SSH ("/go/recover {$Row['Domain']} $DBPassword bulk",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		Echo Error("<h1>{$Row['Domain']}</h1>$Error");
		}

	}
	
	$Error=SSH ("/go/fpm.sh",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

}


	include "search.php";
	
	
	$Header=DesignCode($Header,"$Control (Header)");
	echo $Header;
	
	
	
	$Table="Site";$Field="RecycleBin=1";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";

    

	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	$Domain=$Row['Domain'];
	$Username=$Row['Username'];
		
		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}
		
		$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

		$Status="Active";
		
		if ($Row['RecycleBin']==1)
		{
		$Status="Terminated";
		}
		elseif ($Row['Suspend']==1)
		{
		$Status="Suspended";
		}
		elseif ($Row['Unpublish']==1)
		{
		$Status="Unpublished";
		}

		echo DesignCode($Loop,"$Control (Loop)");

	
	$X++;
	}
	

	$Footer=DesignCode($Footer,"$Control (Footer)");
	echo $Footer;
	
	
?>