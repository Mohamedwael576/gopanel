<?php




include "navigator.php";
$Buttons="";
include "title.php";

$StartDate=substr($_REQUEST['StartDate'],6,4)."-".substr($_REQUEST['StartDate'],3,2)."-".substr($_REQUEST['StartDate'],0,2);
$EndDate=substr($_REQUEST['EndDate'],6,4)."-".substr($_REQUEST['EndDate'],3,2)."-".substr($_REQUEST['EndDate'],0,2);

$Domain=ValidateDomain($_REQUEST['Domain']);

$Email=ValidateEmail($_REQUEST['Email']);
$Subject=$_REQUEST['Subject'];
$Message=$_REQUEST['Message'];

$Active=intval($_REQUEST['Active']);


If ($Delete==1 and $Step==1)
{
	echo Error("Are you sure you want to delete the autoresponder for $Email? <a href=\"javascript:Load('$CurrentFileName?Delete=1&ServiceControl=$ServiceControl&Email=$Email&Step=2')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName')\" class=Action>No</a>");
	
	exit;
}

if ($Delete==1 and $Step==2)
{
include "access.php";

	$Error=SSH ("/go/responder $Email delete $DBPassword",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
	
	echo Error("<a href=\"javascript:Load('$CurrentFileName')\"><img src='theme/{$_SESSION['SessionTheme']}/image/back.svg' height=24 style='padding-right:8px;vertical-align:middle'>Go Back</a>");

	exit;

}

if ($Message!="")
{
include "access.php";
	
	if ($Edit==1)
	{
	
		$Sql = "UPDATE Responder Set Email='$Email',Subject='$Subject',Message='$Message',StartDate='$StartDate',EndDate='$EndDate',Active='$Active',Domain='$Domain' where Email='$Email'";
		$Result = SQL($Sql);
	
	}
	else
	{

		$Sql = "INSERT INTO Responder (Email,Subject,Message,StartDate,EndDate,Active,Domain,TimeStamp) VALUES ('$Email','$Subject','$Message','$StartDate','$EndDate','$Active','$Domain','$TimeStamp')";
		$Result = SQL($Sql);
		If ($Result)
		{
			
		}
	}
	
	$Error=SSH ("/go/responder $Email add",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
	
	$Edit=0;

}


	if ($Edit==1)
	{
		$Sql = "select * from Responder where Email='$Email'";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{ 
			$EmailArray=explode("@",$Row['Email']);
			$User=$EmailArray[0];
			$Domain=$EmailArray[1];
			
			$Subject=$Row['Subject'];
			$Message=$Row['Message'];
			
			$StartDate=substr($Row['StartDate'],8,2)."/".substr($Row['StartDate'],5,2)."/".substr($Row['StartDate'],0,4);
			$EndDate=substr($Row['EndDate'],8,2)."/".substr($Row['EndDate'],5,2)."/".substr($Row['EndDate'],0,4);

			if ($Row['Active']==0)
			{
			$ResponderOffChecked="checked";
			}
			

		}
	}
	else
	{
	
			$User="";
			$Domain="";
			
			$Subject="";
			$Message="";
			
			$StartDate="";
			$EndDate="";

	
	}


	Echo "
	<div>
	";
	
	if ($Edit==1)
	{
	echo "Editing Email \"$Email\"";
	}
	else
	{
	echo "$PageTabName";
	}
	
	
	echo "
	</div>
	

	
	<form name=Form method=POST onsubmit='return Responder(this);' autocomplete='off' action='$CurrentFileName'><input type=hidden name=ServiceControl value='$ServiceControl'>
	<input type=hidden name=Edit value='$Edit'><input type=hidden name=ServiceControl value='$ServiceControl'>
	<input type=hidden name=ResponderID value='$ResponderID'>

	
	<div class='DivInput {$Dir}DivInput'>{$LNG['Email']}<br>
	";
	
	if ($Edit==1)
	{
		echo "
		<input type='hidden' name='User' value='$User'>
		<input type='hidden' name='Domain' value='$Domain'>
		$User@$Domain
		";
	}
	else
	{
		Echo "<input type='Text' name='User' maxlength=100 class=InputText style='width:40%'>@";
		

		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['Domain'];
		}
		

		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['AddonDomain'];
		}
		
		if (is_array($Domains))
		{
			sort($Domains);
		}
		else
		{
			$Domains[]="";
		}
		
		echo "
		<select name='Domain' id='Domain' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{
			if ($Domain==$_REQUEST['Domain'])
			{
			echo "<option value='$Domain' selected>$Domain</option>";
			}
			else
			{
			echo "<option value='$Domain'>$Domain</option>";
			}
		}

		echo "</select>";
	
	}
	Echo "
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Subject']}<br>
	<input type='text' name='Subject' value='$Subject' maxlength=100 class=InputText size=40>
	</div>
	
	<div class='DivInput {$Dir}DivInput'>
	{$LNG['Message']}
	</div>

	<div class='DivInput {$Dir}DivInput'>
	<textarea rows='10' name='Message' id='Message' cols=80 class=TextArea>$Message</Textarea>
	</div>
	
	<div class='DivInput {$Dir}DivInput'>{$LNG['FirstDay']}<br>
	<input type='Text' name='StartDate' id='StartDate' value='$StartDate' readonly autocomplete='off' maxlength=100 class=InputText style='width:30%'> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {$LNG['LastDay']}: <input type='Text' name='EndDate' id='EndDate' value='$EndDate' readonly autocomplete='off' maxlength=100 class=InputText style='width:30%'>
	</div>

	";
	
	if ($ResponderOffChecked!="checked")
	{
	$ResponderOnChecked="checked";
	}

	Echo "
	<div class='DivInput {$Dir}DivInput'>
	<input type='radio' name='Active' id='Active' value='0' $ResponderOffChecked> {$LNG['VacationResponderOff']} &nbsp;&nbsp;&nbsp;&nbsp; <input type='radio' name='Active' id='Active' value='1' $ResponderOnChecked> {$LNG['VacationResponderOn']}
	</div>
	
	<div id=DivSubmit class=DivSubmit>
	";


	if ($Edit==1)
	{
		Echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
	}
	else
	{
		Echo "<input type=submit value='{$LNG['Create']}' Class=InputButton>";
	}
	
	Echo "
	</div>

</form>


";



	if($Edit!=1)
	{

		Echo "
		<div class=DivTable>
		<table cellPadding='8' cellSpacing=0 width='100%' class=Table>


		<THEAD>
		
		<tr>
	
		<th align='center' width='2%' height=40>
		ID
		</TD>
		
		<th align='$DAlign' width='20%'>
		Email
		</th>
		
		<th align='$DAlign' width='10%'>
		Subject
		</th>

		<th align='$DAlign' width='10%'>
		First Day
		</th>
		
		<th align='$DAlign' width='10%'>
		Last Day
		</th>


		<th align='$DAlign' width='10%'>
		Status
		</th>

		<th align='$OAlign' width='28%'>
		
		</th>

		";
		
		$Table="Responder";$Field="ResponderID>=1";
		$DefaultSortBy="Email";
		$DefaultDirection=="ASC";
		include "include/sql.php";

		$X=0;
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{

		
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$StartDate=substr($Row['StartDate'],8,2)."/".substr($Row['StartDate'],5,2)."/".substr($Row['StartDate'],0,4);
			$EndDate=substr($Row['EndDate'],8,2)."/".substr($Row['EndDate'],5,2)."/".substr($Row['EndDate'],0,4);


			$SerialNo=(($Page-1)*$PageNo)+$x;
		

			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

			if ($Row['Active']==1)
			{
			$ActiveStatus="<img src='image/true.svg' style='width:24px;height:24px;'>";
			}
			else
			{
			$ActiveStatus="";
			}
		
			Echo "<tr class='$TDColor' divid=Find find='{$Row['Email']}-{$Row['Domain']}-{$Row['Country']}'>";

			Echo "<TD width='2%' height=40>{$Row['ResponderID']}</TD>";
			
			Echo "<TD><a  href='http://{$Row['Domain']}/mail' target='_blank'>{$Row['Email']}</a></TD>";

			Echo "<TD>{$Row['Subject']}</TD>";
			Echo "<TD>$StartDate</TD>";
			Echo "<TD>$EndDate</TD>";
			
			Echo "<TD width='15%'>$ActiveStatus</TD>";
			
			Echo "<TD align=middle width='20%'>";
			
			echo "
			<a href=\"javascript:Load('$CurrentFileName?Edit=1&Step=1&Email={$Row['Email']}&Username={$Row['Username']}')\" class=Action>Edit</a>
			<a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=1&Email={$Row['Email']}&Username={$Row['Username']}')\" class=Action>Delete</a>
			";
			
			echo "</TD>"; 
			
			$X++;
		}
		
		if ($X!=0)
		{
		echo "</TBODY>";
		}

		echo "
		<TFOOT>

		<tr>

		<th align='$DAlign' colspan=3>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=4>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>
		

		
		</TABLE>
		</div>
		</form>

		";
		
	}


	
?>