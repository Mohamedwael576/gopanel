<?php
session_start();

include("include/function/function.php");
include("/panel/include/config/config.php");

$Domain = preg_replace("/^www\./","",$_SERVER['SERVER_NAME']);
$Domain = preg_replace("/^go\./","",$Domain);
$Domain = preg_replace("/^webmail\./","",$Domain);

$MailID=$_REQUEST['MailID'];

$Result = SQL("select * from Mail where MailID='$MailID'");
foreach ($Result as $Row)
{ 

	$Pass=$Row['Pass'];
	$Email=$Row['Email'];
	$EmailArray=explode("@",$Row['Email']);
	

}

if ($EmailArray[1]!=$_SESSION['SessionUsername'] and $_SESSION['SessionUsername']!="root")
{
echo "Please login...";
exit;
}



if ($Email=="" or $Pass=="")
{
	echo "Please Login.";
	exit;
}


// a roundcube exception class
class RoundCubeException extends Exception {}

// main class
class RoundcubeAutoLogin
{
	// roundcube link (with a trailing slash)
	private $_rc_link = '';
	
	private $ch;
	
	public function __construct($roundcube_link)
	{
		$this->_rc_link = $roundcube_link;
		$this->ch = curl_init();
	}
	
	public function login($email, $password)
	{
		try
		{
			$token = $this->_get_token();
			
			if($token === FALSE) 
			{
				throw new RoundCubeException('Unable to get token, is your RC link correct?');
			}
			
			// make the request to roundcube
			$post_params = array(
			'_token' => $token,
			'_task' => 'login',
			'_action' => 'login',
			'_timezone' => '',
			'_url' => '_task=login',
			'_user' => $email,
			'_pass' => $password
			);
			
			
			curl_setopt($this->ch, CURLOPT_URL, $this->_rc_link . '?_task=login');
			curl_setopt($this->ch, CURLOPT_COOKIEFILE, '');
			curl_setopt($this->ch, CURLOPT_COOKIEJAR, '');
			curl_setopt($this->ch, CURLOPT_POST, TRUE);
			curl_setopt($this->ch, CURLOPT_HEADER, TRUE);
			curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, TRUE);
			
			$Timeout=3;
			curl_setopt($this->ch, CURLOPT_TIMEOUT, $Timeout);
			curl_setopt($this->ch, CURLOPT_CONNECTTIMEOUT, $Timeout);
			
			curl_setopt($this->ch, CURLOPT_POSTFIELDS, http_build_query($post_params));
			$response = curl_exec($this->ch);
			$response_info = curl_getinfo($this->ch);
			
			if($response_info['http_code'] == 302)
			{
				// find all relevant cookies to set (php session + rc auth cookie)
				preg_match_all('/Set-Cookie: (.*)\b/', $response, $cookies);
				
				$cookie_return = array();
				
				foreach($cookies[1] as $cookie)
				{
					preg_match('|([A-z0-9\_]*)=([A-z0-9\_\-]*);|', $cookie, $cookie_match);
					if($cookie_match) 
					{
						$cookie_return[$cookie_match[1]] = $cookie_match[2];
					}
				}
				
				return $cookie_return;
			}
			else
			{
				throw new RoundCubeException('Login failed, please check your credentials.');
			}
			
		}
		catch(RoundCubeException $e)
		{
			echo 'RC error: ' . $e->getMessage();
		}
		catch(Exception $e)
		{
			echo 'General error: ' . $e->getMessage();
		}
	}
	
	public function redirect()
	{
		header('Location: ' . $this->_rc_link . '?task=mail');
	}
	
	private function _get_token()
	{
		curl_setopt($this->ch, CURLOPT_URL, $this->_rc_link);
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($this->ch, CURLOPT_COOKIEFILE, '');
		curl_setopt($this->ch, CURLOPT_COOKIEJAR, '');

		$Timeout=3;
		curl_setopt($this->ch, CURLOPT_TIMEOUT, $Timeout);
		curl_setopt($this->ch, CURLOPT_CONNECTTIMEOUT, $Timeout);

		$response = curl_exec($this->ch);
		
		preg_match('|<input type="hidden" name="_token" value="([A-z0-9]*)">|', $response, $matches);
		
		if($matches) 
		{
			return $matches[1];
		}
		else 
		{
			return FALSE;
		}
	}
}

$rc = new RoundcubeAutoLogin("https://webmail.$Domain/roundcube/");
$cookies = $rc->login($Email,$Pass);
if (!empty($cookies))
{
	$Login=1;
	foreach($cookies as $cookie_name => $cookie_value)
	{
		setcookie($cookie_name, $cookie_value,0, '/', '');
		setcookie($cookie_name, $cookie_value,0, '/', '', true);
	}
}

$rc = new RoundcubeAutoLogin("https://$Domain:2025/roundcube/");
$cookies = $rc->login($Email,$Pass);
if (!empty($cookies))
{
	$Login=1;
	foreach($cookies as $cookie_name => $cookie_value)
	{
		setcookie($cookie_name, $cookie_value,0, '/', '');
		setcookie($cookie_name, $cookie_value,0, '/', '', true);
	}
}

$Login=0;
$rc = new RoundcubeAutoLogin("http://{$_SERVER['HTTP_HOST']}/roundcube/");
$cookies = $rc->login($Email,$Pass);
if (!empty($cookies))
{
	$Login=1;
	foreach($cookies as $cookie_name => $cookie_value)
	{
		setcookie($cookie_name, $cookie_value,0, '/', '');
		setcookie($cookie_name, $cookie_value,0, '/', '', true);
	}
}

$rc = new RoundcubeAutoLogin("http://$Domain:2020/roundcube/");
$cookies = $rc->login($Email,$Pass);
if (!empty($cookies))
{
	$Login=1;
	$Type.="|2020|";
	foreach($cookies as $cookie_name => $cookie_value)
	{
		setcookie($cookie_name, $cookie_value,0, '/', '');
		setcookie($cookie_name, $cookie_value,0, '/', '', true);
	}
}

if ($Login==1)
{
	if (stripos($_SERVER['HTTP_HOST'],"webmail.")===0)
	{
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
		{
			$URL="https://webmail.$Domain/roundcube/";
		}
		else
		{
			$URL="http://webmail.$Domain/roundcube/";	
		}
	}
	elseif (stristr($_SERVER['HTTP_HOST'],":2025"))
	{
		$URL="https://$Domain:2025/roundcube/";
	}
	elseif (stristr($_SERVER['HOST'],":2021"))
	{
		$URL="https://$Domain:2021/roundcube/";	
	}
	elseif (stripos($_SERVER['HTTP_HOST'],"go.")===0)
	{
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
		{
			$URL="https://go.$Domain/roundcube/";	
		}
		else
		{
			$URL="http://go.$Domain/roundcube/";	
		}
	}
	elseif (stristr($_SERVER['HTTP_HOST'],":2024"))
	{
		$URL="http://$Domain:2024/roundcube/";	
	}	
	elseif (stristr($_SERVER['HTTP_HOST'],":2020"))
	{
		$URL="http://$Domain:2020/roundcube/";
	}
	elseif (filter_var($_SERVER['HTTP_HOST'], FILTER_VALIDATE_IP))
	{
		$URL="http://{$_SERVER['HTTP_HOST']}/roundcube/";
	}
	elseif (stristr($_SERVER['REQUEST_URI'],"/go/"))
	{
		if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') 
		{
			$URL="https://{$_SERVER['HTTP_HOST']}/roundcube/";
		}
		else
		{
			$URL="http://{$_SERVER['HTTP_HOST']}/roundcube/";	
		}
	}
	
	if ($URL!="")
	{
		header("Location: $URL");	
	}
	else
	{
		$rc->redirect();
	}
}
else
{
	echo "Authentication Failed";
	
}

?>