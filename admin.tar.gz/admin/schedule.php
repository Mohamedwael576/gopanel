<?php
include "navigator.php";
$Buttons="";
include "title.php";

$SiteID=intval($_REQUEST['SiteID']);
$Storage=trim($_REQUEST['Storage']);

if (intval($PageNo)==0) {$PageNo=20;}

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	echo "
	Sorry, You Are Not Allowed to Access This Page
	";

	exit;
	
}

if ($_REQUEST['Domain']!="")
{
$Domain=$_REQUEST['Domain'];
$Destination=trim($_REQUEST['Destination']);
$Type=trim($_REQUEST['Type']);
$RemoteServer=trim($_REQUEST['RemoteServer']);
$RemoteUser=trim($_REQUEST['RemoteUser']);
$RemotePassword=trim($_REQUEST['RemotePassword']);
$Port=trim($_REQUEST['Port']);

if ($RemoteServer=="")
{
$RemoteServer="-";
}

if ($RemoteUser=="")
{
$RemoteUser="root";
}

if ($RemotePassword=="")
{
$RemotePassword="-";
}

if ($Port=="")
{
$Port="22";
}


$RemoteDir=trim($_REQUEST['RemoteDir']);
$Email=trim($_REQUEST['Email']);
	
	
	$Error=SSH ("/go/backup $Domain $Type $Destination $RemoteServer $RemoteUser $RemotePassword $Port $RemoteDir $Email --storage $Storage --setup",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	
	exit;

}


if ($Action=="EnableBackup")
{
	SQL("UPDATE Site SET Backup='1' where SiteID='$SiteID'");
}

if ($Action=="DisableBackup")
{
	SQL("UPDATE Site SET Backup='0' where SiteID='$SiteID'");
}

	if ($Storage=="" or $Storage=="primary")
	{
	$PrimaryCheck="checked";
	$StorageFile="primary.db";
	}
	elseif ($Storage=="secondary")
	{
	$SecondaryCheck="checked";
	$StorageFile="secondary.db";
	}
	else
	{
	$ManuallyCheck="checked";
	$StorageFile="manually.db";
	}

	$Schedule=@file_get_contents("/panel/db/$StorageFile");
	$ScheduleArray=explode("|",$Schedule);

	if ($ScheduleArray[0]=="1")
	{
	$DailySelected="selected";
	}
	elseif ($ScheduleArray[0]=="2")
	{
	$TwoSelected="selected";
	}
	elseif ($ScheduleArray[0]=="3")
	{
	$ThereSelected="selected";
	}
	elseif ($ScheduleArray[0]=="4")
	{
	$FourSelected="selected";
	}
	elseif ($ScheduleArray[0]=="5")
	{
	$FiveSelected="selected";
	}
	elseif ($ScheduleArray[0]=="6")
	{
	$SixSelected="selected";
	}
	elseif ($ScheduleArray[0]=="7")
	{
	$WeeklySelected="selected";
	}	
	elseif ($ScheduleArray[0]=="Sat")
	{
	$SATSelected="selected";
	}
	elseif ($ScheduleArray[0]=="Sun")
	{
	$SUNSelected="selected";
	}
	elseif ($ScheduleArray[0]=="Mon")
	{
	$MONSelected="selected";
	}
	elseif ($ScheduleArray[0]=="Tue")
	{
	$TUESelected="selected";
	}
	elseif ($ScheduleArray[0]=="Wed")
	{
	$WEDSelected="selected";
	}
	elseif ($ScheduleArray[0]=="Thu")
	{
	$THUSelected="selected";
	}
	elseif ($ScheduleArray[0]=="Fri")
	{
	$FRISelected="selected";
	}
	elseif ($ScheduleArray[0]=="Sat-Tue")
	{
	$SatTueSelected="selected";
	}
	elseif ($ScheduleArray[0]=="Sun-Wed")
	{
	$SunWedSelected="selected";
	}
	elseif ($ScheduleArray[0]=="Mon-Thu")
	{
	$MonThuSelected="selected";
	}
	elseif ($ScheduleArray[0]=="30")
	{
	$MonthlySelected="selected";
	}

	if ($ScheduleArray[1]=="full" or stristr($ScheduleArray[1],"www"))
	{
	$WWWChecked="checked";
	}
	
	if ($ScheduleArray[1]=="full" or stristr($ScheduleArray[1],"mail"))
	{
	$MailChecked="checked";
	}
	
	if ($ScheduleArray[1]=="full" or stristr($ScheduleArray[1],"database"))
	{
	$DatabaseChecked="checked";
	}

	if ($ScheduleArray[2]=="LOCAL")
	{
	$LOCALSelected="selected";
	}
	elseif ($ScheduleArray[2]=="FTP")
	{
	$FTPSelected="selected";
	}
	elseif ($ScheduleArray[2]=="PASSIVEFTP")
	{
	$PASSIVEFTPSelected="selected";
	}
	elseif ($ScheduleArray[2]=="SCP")
	{
	$SCPSelected="selected";
	}
	elseif ($ScheduleArray[2]=="Rclone")
	{
	$RcloneSelected="selected";
	}

	if ($ScheduleArray[6]=="")
	{
	$ScheduleArray[6]="22";
	}

	if ($ScheduleArray[7]=="")
	{
	$ScheduleArray[7]="/backup";
	}

	echo "
	<form name=Form method=POST onsubmit='return ScheduleBackup(this);' autocomplete='off' action='$CurrentFileName'>
	<input type=hidden name=ControlID value='$ControlID'>

	<div class='DivInput {$Dir}DivInput'>{$LNG['StorageBox']}<br>


		<label class=Label onclick=\"Load('schedule.php?ControlID=$ControlID&Storage=primary')\" style='margin-top:8px'>{$LNG['PrimaryBackup']}
			<input type='radio' name='Storage' value='primary' $PrimaryCheck>
			<span class='Radio RadioRadius'></span>
		</label>
		

		<label class=Label onclick=\"Load('schedule.php?ControlID=$ControlID&Storage=secondary')\">{$LNG['SecondaryBackup']}
			<input type='radio' name='Storage' value='secondary' $SecondaryCheck>
			<span class='Radio RadioRadius'></span>
		</label>
		

		<label class=Label onclick=\"Load('schedule.php?ControlID=$ControlID&Storage=manually')\">{$LNG['ManuallyBackup']}
			<input type='radio' name='Storage' value='manually' $ManuallyCheck>
			<span class='Radio RadioRadius'></span>
		</label>
		
		
		
		
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['BackupEvery']}<br>

	<select name='Domain' class=Select>
	<option value='0'>{$LNG['DisableBackup']}</option>
	<option value='1' $DailySelected>Daily</option>
	<option value='2' $TwoSelected>2 Days</option>
	<option value='3' $ThereSelected>3 Days</option>
	<option value='4' $FourSelected>4 Days</option>
	<option value='5' $FiveSelected>5 Days</option>
	<option value='6' $SixSelected>6 Days</option>
	<option value='7' $WeeklySelected>Weekly</option>
	<option value='Sat' $SATSelected>Sat</option>
	<option value='Sun' $SUNSelected>Sun</option>
	<option value='Mon' $MONSelected>Mon</option>
	<option value='Tue' $TUESelected>Tue</option>
	<option value='Wed' $WEDSelected>Wed</option>
	<option value='Thu' $THUSelected>Thu</option>
	<option value='Fri' $FRISelected>Fri</option>
	
	<option value='Sat-Tue' $SatTueSelected>Sat & Tue</option>
	<option value='Sun-Wed' $SunWedSelected>Sun & Wed</option>
	<option value='Mon-Thu' $MonThuSelected>Mon & Thu</option>
	
	<option value='30' $MonthlySelected>Monthly</option>
	</select> 
	
	</div>

	<div class='DivInput {$Dir}DivInput' >{$LNG['Type']}<br>

		<label class=Label style='margin-top:10px'> {$LNG['WWWBackup']}
			<input type='checkbox' name='WWWBackup' id='WWWBackup' value='www' $WWWChecked>
			<span class='Checkbox'></span>
		</label>

		<label class=Label> {$LNG['MailBackup']}
			<input type='checkbox' name='MailBackup' id='MailBackup' value='mail' $MailChecked>
			<span class='Checkbox'></span>
		</label>

		<label class=Label> {$LNG['DatabaseBackup']}
			<input type='checkbox' name='DatabaseBackup' id='DatabaseBackup' value='database' $DatabaseChecked>
			<span class='Checkbox'></span>
		</label>

	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Destination']}<br>

	<select name='Destination' class=Select>
	<option value='LOCAL' $LOCALSelected>{$LNG['Local']}</option>
	<option value='FTP' $FTPSelected>{$LNG['RemoteFTPServer']}</option>
	<option value='PASSIVEFTP' $PASSIVEFTPSelected>{$LNG['RemoteFTPServerPassive']}</option>
	<option value='SCP' $SCPSelected>{$LNG['SecureCopySCP']}</option>	
	<option value='Rclone' $RcloneSelected>{$LNG['Rclone']}</option>
	</select>
	
	</div>


	<div class='DivInput {$Dir}DivInput'>{$LNG['Email']}<br>
	<input type='text' name='Email' value='{$ScheduleArray[8]}' maxlength=100 class=InputText>
	</div>

	<div class=DivInput id=RemoteServer>{$LNG['RemoteServer']}<br>
	<input type='text' name='RemoteServer' value='{$ScheduleArray[3]}' maxlength=100 class=InputText size=40>
	</div>

	<div class=DivInput id=RemoteUser>{$LNG['RemoteUser']}<br>
	<input type='text' name='RemoteUser' value='{$ScheduleArray[4]}' maxlength=100 class=InputText> 
	</div>

	<div class=DivInput id=RemotePassword>{$LNG['RemotePassword']}<br>
	<input type='text' name='RemotePassword' maxlength=100 class=InputText>
	</div>

	<div class=DivInput id=Port>{$LNG['Port']}<br>
	<input type='text' name='Port' value='{$ScheduleArray[6]}' maxlength=5 class=InputText>
	</div>

	<div class=DivInput id=RemoteDir>{$LNG['RemoteDir']}<br>
	<input type='text' name='RemoteDir' value='{$ScheduleArray[7]}' maxlength=100 class=InputText size=40>
	</div>

	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['Save']}' Class=InputButton>
	</div>

</form>
";

    
	include "search.php";
	
    Echo "
	<form name=CheckForm id=CheckForm action='$CurrentFileName'>
	<input type=hidden name=Action id=Action>
	
	<div class=DivXTable>
	<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

	<THEAD>
	
	<tr>
	
    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=Domain')\">{$LNG['Domain']}</a>
    </TH>

    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=Backup')\">{$LNG['BackupStatus']}</a>
    </TH>

    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=BackupStamp')\">{$LNG['BackupDate']}</a>
    </TH>

    <TH align='$DAlign' width='20%'>
    <a href=\"javascript:Load('$CurrentFileName?&SortBy=SpaceUsed')\">{$LNG['DiskUsage']}</a>
    </TH>
	
    <TH width='20%'>
 
    </TH>
	
	</tr>
	
	</THEAD>
	
	";
	


	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";

	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	
	$Domain=$Row['Domain'];
	$Backup=$Row['Backup'];
	

	$BackupDate=date("D j M Y g:i a", $Row['BackupStamp']);

	$SpaceUsed=FormatSize($Row['SpaceUsed']);


		
		if ($X==0)
		{
		echo "<TBODY>";
		}

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}

		if ($Backup==1)
		{
		$BackupCode="✔";
		}
		else
		{
		$BackupCode="✖";
		}
		

		if ($Backup==1)
		{
		$BackupStatus= "
		<label class='switch' onclick=\"javascript:Load('$CurrentFileName?Action=DisableBackup&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
		<input type='checkbox' checked>
		<span class='slider round'></span>
		</label>	
		";
		}
		else
		{
		$BackupStatus="
		<label class='switch' onclick=\"javascript:Load('$CurrentFileName?Action=EnableBackup&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
		<input type='checkbox'>
		<span class='slider round'></span>
		</label>	
		";
		}



    ECHO "
	<tr class='$TDColor' divid=Find find='{$Row['Domain']}-{$Row['Email']}'>

    <TD>
    <a href='http://{$Row['Domain']}' target='_blank'>{$Row['Domain']}</a>
    </td>
	
	<TD>
    $BackupCode
    </td>
	
	<TD>
    $BackupDate
    </td>
	
	<TD>
	$SpaceUsed
	</td>
	
	<TD align='$OAlign'>
	$BackupStatus
	</td>
    
	</tr>
	";
	
	$X++;
	}
	
	if ($X!=0)
	{
	echo "</TBODY>";
	}

	echo "
	<TFOOT>

	<tr class=TdDown>

	<th align='$DAlign' colspan=3>
	Showing $X of $RowsNo records.
	</th>

	<th align='$OAlign' colspan=3>
	";
	
	include "pages.php";

	echo "
	</th>
	
	</tr>

	</TFOOT>

	</TABLE>
	</div>
	</form>
	";
	
	


	
?>