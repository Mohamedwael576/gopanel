<?php

if ($DisableSearch!=1)
{
echo "<form name=FormSearch method=POST onsubmit=\"return SearchPost('$CurrentFileName');\" action='$CurrentFileName'>";
}

echo "
<div class=DivTable>
<table width=100% cellPadding='0' cellSpacing=0 class=TableSearch>
<TD width='95%'>
<input type=text name='SearchFor' id='SearchFor' value='{$_REQUEST['SearchFor']}' placeholder='{$LNG['Search']}' autocomplete='off' onkeyup=\"Search('tr')\" onfocus=\"actb(this,event,customarray,'#FFFFFF','#000000','#c0c0c0','Tahoma','11px');\" class=InputSearch>
</TD>
<TD align='center' width='5%'>
<input type='image' src='theme/{$_SESSION['SessionTheme']}/image/search.svg' height=32 style='margin-left:8px;margin-right:8px'>
</TD>
</table>
</div>
";

if ($DisableSearch!=1)
{
echo "</form>";
}

?>