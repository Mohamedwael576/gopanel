<?php
include "navigator.php";

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{

	Echo "
	Sorry, You Are Not Allowed to Access This Page
	";

exit;
}

if ($DemoPassword!="")
{
echo Error($LNG['ThisFunctionalityNotAvailableDemoMode']);
exit;
}

$Domain = preg_replace("/^go\./","",$_SERVER['SERVER_NAME']);

if ($Domain=="")
{
$Domain="-";
}

$ServerIP=ServerIP();

Echo "
<div class=UnderNavigator>
To access Terminal directly, navigate to <a href='http://$Domain:2222' target='_blank'>http://$ServerIP:2222</a></span>
</div>
";

include "title.php";

$SSH=$_REQUEST['SSH'];
$SSHFontSize=$_REQUEST['SSHFontSize'];

if ($SSHFontSize!="")
{
	$Sql = "UPDATE Config Set SSHFontSize='$SSHFontSize' where ConfigID=1";
	$Result = SQL($Sql);
}


if ($SSH!="")
{
	$Sql = "UPDATE Config Set SSH='$SSH' where ConfigID=1";
	$Result = SQL($Sql);

}


	$Result = SQL("select * from Config where ConfigID=1");
	foreach ($Result as $Row)
	{
		$SSH=$Row['SSH'];
		$SSHFontSize=$Row['SSHFontSize'];
		unset($_SESSION['SessionShellPassword']);
	}

	if ($SSH=="Black") {$CheckedBlack="checked";}
	if ($SSH=="White") {$CheckedWhite="checked";}
	if ($SSH=="Blue") {$CheckedBlue="checked";}
	if ($SSH=="Gray") {$CheckedGray="checked";}

	if ($SSHFontSize=="8") {$Checked8="checked";}
	if ($SSHFontSize=="10") {$Checked10="checked";}
	if ($SSHFontSize=="12") {$Checked12="checked";}
	if ($SSHFontSize=="14") {$Checked14="checked";}
	if ($SSHFontSize=="16") {$Checked16="checked";}
	if ($SSHFontSize=="18") {$Checked18="checked";}
	if ($SSHFontSize=="20") {$Checked20="checked";}



	if (strlen($_SESSION['SessionShellPassword'])!=16)
	{
	$_SESSION['SessionShellPassword']=GeneratePassword(16);
	SSH ("/go/shell $Domain {$_SESSION['SessionShellPassword']}",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	}
	
	Echo "
	<form name=Form method=POST onsubmit='return Save(this);' autocomplete='off' action='$CurrentFileName'>

	<div class='DivInput {$Dir}DivInput'>
	Font Size
	<br>
	<input type='radio' name='SSHFontSize' value='8' onclick=\"Load('$CurrentFileName?SSHFontSize=8')\" $Checked8> 8 PX &nbsp;&nbsp 
	<input type='radio' name='SSHFontSize' value='10' onclick=\"Load('$CurrentFileName?SSHFontSize=10')\" $Checked10> 10 PX &nbsp;&nbsp
	<input type='radio' name='SSHFontSize' value='12' onclick=\"Load('$CurrentFileName?SSHFontSize=12')\" $Checked12> 12 PX &nbsp;&nbsp
	<input type='radio' name='SSHFontSize' value='14' onclick=\"Load('$CurrentFileName?SSHFontSize=14')\" $Checked14> 14 PX &nbsp;&nbsp
	<input type='radio' name='SSHFontSize' value='16' onclick=\"Load('$CurrentFileName?SSHFontSize=16')\" $Checked16> 16 PX &nbsp;&nbsp
	<input type='radio' name='SSHFontSize' value='18' onclick=\"Load('$CurrentFileName?SSHFontSize=18')\" $Checked18> 18 PX &nbsp;&nbsp
	<input type='radio' name='SSHFontSize' value='20' onclick=\"Load('$CurrentFileName?SSHFontSize=20')\" $Checked20> 20 PX &nbsp;&nbsp

	</div>

	<div class='DivInput {$Dir}DivInput'>
	{$LNG['Style']}
	<br>
	<input type='radio' name='SSH' value='Black' onclick=\"Load('$CurrentFileName?SSH=Black')\" $CheckedBlack> {$LNG['Black']} &nbsp;&nbsp 
	<input type='radio' name='SSH' value='White' onclick=\"Load('$CurrentFileName?SSH=White')\" $CheckedWhite> {$LNG['White']} &nbsp;&nbsp
	<input type='radio' name='SSH' value='White' onclick=\"Load('$CurrentFileName?SSH=Blue')\" $CheckedBlue> {$LNG['Blue']} &nbsp;&nbsp
	<input type='radio' name='SSH' value='White' onclick=\"Load('$CurrentFileName?SSH=Gray')\" $CheckedGray> {$LNG['Gray']} &nbsp;&nbsp
	</div>


	<div class='DivInput {$Dir}DivInput'>
	</div>

	<div id=DivSubmit class=DivSubmit>
	";
	

	if (strpos($_SERVER['SERVER_NAME'],"go.") === 0)
	{
	echo "<input type=button value='{$LNG['Start']}' class=InputButton onclick=\"window.open('https://root:{$_SESSION['SessionShellPassword']}@$Domain:2222')\">";
	}
	else
	{
	echo "<input type=button value='{$LNG['Start']}' class=InputButton onclick=\"window.open('http://root:{$_SESSION['SessionShellPassword']}@$ServerIP:2222')\">";		
	}
	
	echo "
	</div>

	</form>
	

</div>


";
	


?>