<?php



include "navigator.php";
$Buttons="<a href=\"javascript:Load('$CurrentFileName?Action=RestoreSMTPConfiguration&ControlID=$ControlID&Page=$Page','$ControlID')\" class='ButtonB {$Dir}ButtonB'>{$LNG['RestoreDefault']}</a>";
include "title.php";

if ($_REQUEST['Action']=="RestoreSMTPConfiguration")
{
	SQL("update Config set SMTPHostname='',SMTPPort='587',SMTPUsername='',SMTPPassword='' where ConfigID=1");
}

			$Result = SQL("select * from Config where ConfigID='1'");
			foreach ($Result as $Row)
			{
				$SMTPHostname=$Row['SMTPHostname'];
				$SMTPPort=$Row['SMTPPort'];
				$SMTPUsername=$Row['SMTPUsername'];
				$SMTPPassword=$Row['SMTPPassword'];
			}


			
			Echo "
			<form name=Form method=POST onsubmit='return SMTP(this);' autocomplete='off' action='$CurrentFileName'>

			<div class='DivInput {$Dir}DivInput'>{$LNG['Hostname']}<br>
			
			<input type='text' value='$SMTPHostname' id='SMTPHostname' onchange=\"SMTP('SMTPHostname',encodeURI(document.getElementById('SMTPHostname').value))\" class=InputText>
			
			</div>


			<div class='DivInput {$Dir}DivInput'>{$LNG['Port']}<br>
			
			<input type='text' value='$SMTPPort' id='SMTPPort' onchange=\"SMTP('SMTPPort',encodeURI(document.getElementById('SMTPPort').value))\" class=InputText>
			
			</div>

			<div class='DivInput {$Dir}DivInput'>{$LNG['SMTPUsername']}<br>
			
			<input type='text' value='$SMTPUsername' id='SMTPUsername' onchange=\"SMTP('SMTPUsername',encodeURI(document.getElementById('SMTPUsername').value))\" class=InputText>
						
			</div>

			<div class='DivInput {$Dir}DivInput'>{$LNG['SMTPPassword']}<br>
			
			<input type='text' value='$SMTPPassword' id='SMTPPassword' onchange=\"SMTP('SMTPPassword',encodeURI(document.getElementById('SMTPPassword').value))\" class=InputText>
			
			</div>
			
			</form>

";

// End Scroll 
echo "
</div>
";


?>