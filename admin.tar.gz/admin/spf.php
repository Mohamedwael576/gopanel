<?php



include "navigator.php";
$Buttons="";
include "title.php";

	Echo "
	<form name=Form method=POST onsubmit='return Save(this);' autocomplete='off' action='$CurrentFileName'>

	";
	
	if (stristr($Output," "))
	{
	$OutputArray=explode(" ",$Output);

	$Domain=$OutputArray[0];
	$Domain=str_replace("@","",$Domain);

	$Email=$OutputArray[1];
	}
	else
	{
	$Domain="";
	$Email="";
	}
	
	echo "
	<div class=UnderTitle>
	
	{$LNG['SPFDescription']}

	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}<br>
	";
	
		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['Domain'];
		}
		
		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['AddonDomain'];
		}
		
		if (is_array($Domains))
		{
			sort($Domains);
		}
		else
		{
			$Domains[]="";
		}
		
		echo "
		<select name='Domain' id='Domain' onchange='SPF()' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{
			if ($Domain==$_REQUEST['Domain'])
			{
			echo "<option value='$Domain' selected>$Domain</option>";
			}
			else
			{
			echo "<option value='$Domain'>$Domain</option>";
			}
		}

		echo "</select>
	
	</div>

	<div id=DivSPF style='margin:10px' ></div>

</form>
";

?>