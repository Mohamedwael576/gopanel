<?php


include "navigator.php";
$Buttons="";
include "title.php";

$phpLiteAdmin=$_REQUEST['phpLiteAdmin'];

$Directory=ValidateDirectory($_REQUEST['Directory']);
$SQLiteID=$_REQUEST['SQLiteID'];

if ($phpLiteAdmin==1)
{

	
	$Result = SQL("select * from SQLite where SQLiteID='$SQLiteID'");
	foreach ($Result as $Row)
	{
	setcookie ("CookiesSQLiteDirectory",$Row['Directory'],time() + (86400 * 30), "/");
	setcookie ("CookiesSQLitePassword",$Row[Password],time() + (86400 * 30), "/");

	header("Location: phpliteadmin.php");
	}


exit;
}



If ($Delete==1 and $Step==1)
{

	echo Error("Delete Access \"$Directory\" ? <a href=\"javascript:Load('$CurrentFileName?Delete=1&&ServiceControl=$ServiceControl&Step=2&Domain={$_REQUEST['Domain']}&Directory={$_REQUEST['Directory']}')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName?ControlID=$ControlID')\" class=Action>No</a>");
	exit;
	
}

if ($Delete==1 and $Step==2)
{

include "access.php";
$Domain=ValidateDomain($_REQUEST['Domain']);
$Domain=strtolower($Domain);

	$Error=SSH ("/go/sqlite $Domain $Directory delete",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");

	exit;

}

if ($_REQUEST['Domain']!="")
{
include "access.php";
$Domain=ValidateDomain($_REQUEST['Domain']);
$Domain=strtolower($Domain);

	$Error=SSH ("/go/sqlite $Domain $Directory add",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
}


	Echo "
	<form name=Form method=POST onsubmit='return SQLite(this);' action='$CurrentFileName'>
	<input type=hidden name=Edit value='$Edit'><input type=hidden name=ServiceControl value='$ServiceControl'>
	<input type=hidden name=SQLiteID value='$SQLiteID'>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Domain']}
	<br>
	";
	

		$Result = SQL("select * from Site where RecycleBin=0 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['Domain'];
		}
		
		$Result = SQL("select * from Addon where AddonID>=1 $SearchSql");
		foreach ($Result as $Row)
		{
		$Domains[]=$Row['AddonDomain'];
		}
		
		if (is_array($Domains))
		{
			sort($Domains);
		}
		else
		{
			$Domains[]="";
		}
		
		echo "
		<select name='Domain' id='Domain' onchange='SetDirectory()' class=Select>
		";
		
		foreach ($Domains as $Domain) 
		{
			if ($Directory=="") {$Directory="/home/$Domain";}
			echo "
			<option value='$Domain'>$Domain</option>
			";
		}

		echo "
		</select>
	
	
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Directory']}
	<br>

	<input type='Text' name='Directory' id='Directory' value='$Directory' maxlength=255 class=InputText30> {$LNG['DirectoryRelativeThisFileSearchDatabases']}
	</div> 

	<div id=DivSubmit class=DivSubmit>
	";
	
	if ($Edit==1)
	{
		Echo "<input type=submit value='{$LNG['SaveChanges']}' Class=InputButton>";
	}
	else
	{
		Echo "<input type=submit value='{$LNG['Save']}' Class=InputButton>";
	}

	echo "
	</div>

</form>



	
	";
	

	if($Edit!=1)
	{
	

		include "search.php";

		Echo "
		<div class=DivXTable>
		<table cellPadding='8' cellSpacing='0' width='100%' class='Table'>

		<THEAD>
		
		<tr>
		
		<th align='$DAlign' width='2%' height=40>

		</th>
		
		<th align='$DAlign' width='25%'>
		{$LNG['SQLiteDirectory']}
		</th>
		
		<th align='$DAlign' width='25%'>
		{$LNG['Domain']}
		</th>
		
		<th align='$DAlign' width='25%'>
		{$LNG['CreatedDate']}
		</th>

		<th width='23%'>
		
		</th>

		</tr>
		
		</THEAD>

		";

		$Table="SQLite";$Field="SQLiteID>=1";
		$DefaultSortBy="Username";
		$DefaultDirection=="ASC";
		include "include/sql.php";

		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		
			if ($X==0)
			{
			echo "<TBODY>";
			}

			if ($X%2==0)
			{
			$TDColor="Td";
			}
			else
			{
			$TDColor="TdB";
			}
			
			$SerialNo=(($Page-1)*$PageNo)+($X+1);
			
			$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

			echo "
			<tr name=R$i id=R$i divid=Find find='{$Row['Domain']}-{$Row['Directory']}' class='$TDColor'>


			<TD align='middle' height=40>
			$SerialNo
			</span>
			</TD>

			
			<TD><a  href='$CurrentFileName?SQLiteID={$Row['SQLiteID']}&phpLiteAdmin=1&ServiceControl=$ServiceControl' target='_blank'>{$Row['Directory']}</a></TD>

			<TD>{$Row['Username']}</TD>
			
			<TD>$CreatedDate</TD>

			<TD align='$OAlign'>
			
			<a href=\"javascript:Load('$CurrentFileName?Delete=1&Step=1&Directory={$Row['Directory']}&Username={$Row['Username']}')\" class=Action>Delete</a>

			<a href=\"$CurrentFileName?SQLiteID={$Row['SQLiteID']}&phpLiteAdmin=1&ServiceControl=$ServiceControl\" target='_blank' class=Action>phpLiteAdmin</a>
			
			</TD> 
			
			";
			
		$X++;
		}
		

		if ($X!=0)
		{
		echo "</TBODY>";
		}

		echo "
		<TFOOT>

		<tr class=TdDown>

		<th align='$DAlign' colspan=3>
		Showing $X of $RowsNo records.
		</th>
		
		<th align='$OAlign' colspan=4>
		";
				
		include "pages.php";

		echo "
		</th>

		</tr>

		</TFOOT>

		</TABLE>
		</div>
		</form>
		";
		

		
	}


?>