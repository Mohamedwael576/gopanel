<?php
include "nav.php";
$Buttons="";
include "title.php";



$SiteID=intval($_REQUEST['SiteID']);
$Domain=ValidateDomain($_REQUEST['Domain']);

if (intval($PageNo)==0) {$PageNo=20;}

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{
	
	if ($_SESSION['SessionResellerUsername']=="")
	{
		echo "
		Sorry, You Are Not Allowed to Access This Page
		";
		
		exit;
	}
}

if ($Action!="")
{
	include "access.php";
	
	$Error=SSH ("/go/ssh $Domain $Action",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error("$Error");
	
}


include "search.php";

$Header=DesignCode($Header,"$Control (Header)");
echo $Header;

$Table="Site";$Field="RecycleBin=0";
$DefaultSortBy="Domain";
$DefaultDirection=="ASC";
include "include/sql.php";

$X=0;
$Result = SQL($Sql);
foreach ($Result as $Row)
{
	$SiteID=$Row['SiteID'];
	
	$Domain=$Row['Domain'];
	
	$Shell=$Row['Shell'];
	$JailedShell=$Row['JailedShell'];
	
	if ($X%2==0)
	{
		$TDColor="Td";
	}
	else
	{
		$TDColor="TdB";
	}
	

	

	if ($Shell==1)
	{
	$ShellCode="
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=DisableShell&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox' checked>
	<span class='slider round'></span>
	</label>	
	";
	}
	else
	{
	$ShellCode="
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=EnableShell&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox'>
	<span class='slider round'></span>
	</label>	
	";
	}
	
	

	if ($JailedShell==1)
	{
	$JailedShellCode="
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=DisableJailedShell&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox' checked>
	<span class='slider round'></span>
	</label>	
	";
	}
	else
	{
	$JailedShellCode="
	<label class='switch' onclick=\"Load('$CurrentFileName?Action=EnableJailedShell&Domain=$Domain&SiteID=$SiteID&ControlID=$ControlID&Page=$Page')\">
	<input type='checkbox'>
	<span class='slider round'></span>
	</label>	
	";
	}
	
	echo DesignCode($Loop,"$Control (Loop)");
	
	$X++;
}

	$Footer=DesignCode($Footer,"$Control (Footer)");
	echo $Footer;

?>