<?php
include "nav.php";
$Buttons="";
include "title.php";

$Suspend=$_REQUEST['Suspend'];
$Unsuspend=$_REQUEST['Unsuspend'];
$SiteID=$_REQUEST['SiteID'];
$Action=$_REQUEST['Action'];
$CheckList=$_REQUEST['CheckList'];

$UserNo=RowCount("select * from Site where SiteID>=1");
    
$Domain=ValidateDomain($_REQUEST['Domain']);
	
If ($Suspend==1)
{
	
	$Error=SSH ("/go/suspend $Domain suspend",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	if (stristr($Error,"Suspended"))
	{
	$Error=str_replace("\r","",$Error);
	$Error=str_replace("\n","",$Error);
	echo Error($Error." &nbsp;&nbsp;&nbsp; <a href=\"javascript:Load('$CurrentFileName?Unsuspend=1&Domain=$Domain')\" class=Action>Undo</a>");	
	}
	else
	{
	echo Error($Error);
	}
	
}
	

If ($Unsuspend==1)
{

	$Error=SSH ("/go/suspend $Domain unsuspend",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	$Error=str_replace("\r","",$Error);
	$Error=str_replace("\n","",$Error);
	echo Error($Error);

}


If ($Action=="Suspend")
{
	$CountCheckList=count($CheckList);

	for ($i=0 ;$i<$CountCheckList ; $i++)
	{
		$Sql = "select * from Site where SiteID='{$CheckList[$i]}' and Suspend=0";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		$Error=SSH ("/go/suspend {$Row['Domain']} bulksuspend",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		Echo Error("<h1>{$Row['Domain']}</h1>$Error");
		}
	}
	
	$Error=SSH ("/go/httpd",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

}

If ($Action=="Unsuspend")
{

	$CountCheckList=count($CheckList);

	for ($i=0 ;$i<$CountCheckList ; $i++)
	{
		$Sql = "select * from Site where SiteID='{$CheckList[$i]}' and Suspend=1";
		$Result = SQL($Sql);
		foreach ($Result as $Row)
		{
		$Error=SSH ("/go/suspend {$Row['Domain']} bulkunsuspend",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		Echo Error("<h1>{$Row['Domain']}</h1>$Error");
		}
	}
	
	$Error=SSH ("/go/httpd",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

}


	include "search.php";

	$Header=DesignCode($Header,"$Control (Header)");
	echo $Header;
	


	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";


	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
		$SiteID=$Row['SiteID'];
		$Domain=$Row['Domain'];

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}


		if ($Row['Suspend']==1)
		{
		$TDColor="TdEr";
		}
		
			
		$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

		$Status="Active";
		if ($Row['RecycleBin']==1)
		{
		$Status="Terminated";
		}
		elseif ($Row['Suspend']==1)
		{
		$Status="Suspended";
		}
		elseif ($Row['Unpublish']==1)
		{
		$Status="Unpublished";
		}
				
		if ($Row['SpaceUsed']>$Row['DiskSpace'] and $Row['DiskSpace']!=0)
		{
		$Reason="Disk Quota Exceeded";
		}
		elseif ($Row['BandwidthUsed']>$Row['Bandwidth'] and $Row['DiskSpace']!=0)
		{
		$Reason=$LNG['BandwidthLimitExceeded'];
		}
		else
		{
		$Reason="";
		}
		
		echo DesignCode($Loop,"$Control (Loop)");

	$X++;
	}
	

	$Footer=DesignCode($Footer,"$Control (Footer)");
	echo $Footer;
		
?>