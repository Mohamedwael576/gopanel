<?php
include "navigator.php";
$Buttons="";
include "title.php";

$SiteID=intval($_REQUEST['SiteID']);

if (intval($PageNo)==0) {$PageNo=20;}

if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
{


	echo "
	Sorry, You Are Not Allowed to Access This Page
	";

	exit;
	
}


if ($_REQUEST['IncrementalTime']!="")
{
$BackupType=trim($_REQUEST['BackupType']);
$IncrementalTime=ValidateNumber($_REQUEST['IncrementalTime']);
$DifferentialTime=ValidateNumber($_REQUEST['DifferentialTime']);
$Destination=trim($_REQUEST['Destination']);
$SYNCPath=trim($_REQUEST['SYNCPath']);
$RemoteServer=trim($_REQUEST['RemoteServer']);
$RemoteUser=trim($_REQUEST['RemoteUser']);
$RemotePassword=trim($_REQUEST['RemotePassword']);
$Email=trim($_REQUEST['Email']);
$RemoteDir=trim($_REQUEST['RemoteDir']);



if ($BackupType=="")
{
$BackupType="-";
}


if ($SYNCPath=="")
{
$SYNCPath="-";
}


if ($RemoteServer=="")
{
$RemoteServer="-";
}

if ($RemoteUser=="")
{
$RemoteUser="root";
}

if ($RemotePassword=="")
{
$RemotePassword="-";
}

if ($Email=="")
{
$Email="-";
}

if ($RemoteDir=="")
{
$RemoteDir="-";
}

	$SYNCPath=str_replace(" ",":","$SYNCPath");
	$SYNCPath=str_replace("*","\*","$SYNCPath");
		
	$Error=SSH ("/go/sync $BackupType $IncrementalTime $DifferentialTime $SYNCPath $Destination $RemoteServer $RemoteUser $RemotePassword $RemoteDir $Email",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
	
	exit;

}

	$Sync=@file_get_contents("/panel/sync.db");
	$SyncArray=explode("|",$Sync);

	if (stristr($SyncArray[0],"incremental"))
	{
	$IncrementalChecked="checked";
	}

	if (stristr($SyncArray[0],"differential"))
	{
	$DifferentialChecked="checked";
	}

	if ($SyncArray[1]=="60")
	{
	$IncrementalHourlySelected="selected";
	}
	elseif ($SyncArray[1]=="120")
	{
	$IncrementalTwoSelected="selected";
	}
	elseif ($SyncArray[1]=="180")
	{
	$IncrementalThreeSelected="selected";
	}
	elseif ($SyncArray[1]=="240")
	{
	$IncrementalFourSelected="selected";
	}
	elseif ($SyncArray[1]=="300")
	{
	$IncrementalFiveSelected="selected";
	}
	elseif ($SyncArray[1]=="360")
	{
	$IncrementalSixSelected="selected";
	}
	elseif ($SyncArray[1]=="420")
	{
	$IncrementalSevenSelected="selected";
	}
	elseif ($SyncArray[1]=="480")
	{
	$IncrementalEightSelected="selected";
	}
	elseif ($SyncArray[1]=="540")
	{
	$IncrementalNineSelected="selected";
	}
	elseif ($SyncArray[1]=="600")
	{
	$TenSelected="selected";
	}
	elseif ($SyncArray[1]=="660")
	{
	$IncrementalElevenSelected="selected";
	}
	elseif ($SyncArray[1]=="720")
	{
	$IncrementalTwelveSelected="selected";
	}
	elseif ($SyncArray[1]=="1440")
	{
	$IncrementalDailySelected="selected";
	}

	if ($SyncArray[2]=="1")
	{
	$DifferentialDailySelected="selected";
	}
	elseif ($SyncArray[2]=="2")
	{
	$DifferentialTwoSelected="selected";
	}
	elseif ($SyncArray[2]=="3")
	{
	$DifferentialThreeSelected="selected";
	}
	elseif ($SyncArray[2]=="4")
	{
	$DifferentialFourSelected="selected";
	}
	elseif ($SyncArray[2]=="5")
	{
	$DifferentialFiveSelected="selected";
	}
	elseif ($SyncArray[2]=="6")
	{
	$DifferentialSixSelected="selected";
	}
	elseif ($SyncArray[2]=="7")
	{
	$DifferentialWeeklySelected="selected";
	}
	elseif ($SyncArray[2]=="14")
	{
	$DifferentialFourteenSelected="selected";
	}
	elseif ($SyncArray[2]=="30")
	{
	$DifferentialMonthlySelected="selected";
	}

	$SYNCPath=$SyncArray[3];
	if ($SYNCPath=="-")
	{
	$SYNCPath="";
	}

	if (stristr($SyncArray[3],"/home/*/www"))
	{
	$HomeChecked="checked";
	}
	
	if (stristr($SyncArray[3],"/home/*/mail"))
	{
	$MailChecked="checked";
	}
	
	if ($SyncArray[4]=="LOCAL")
	{
	$LOCALSelected="selected";
	}
	elseif ($SyncArray[4]=="SCP")
	{
	$SCPSelected="selected";
	}
	
	$RemoteDir=$SyncArray[8];
	
	if ($RemoteDir=="")
	{
	$RemoteDir="/sync";
	}
	
	
	$Email=$SyncArray[9];

	echo "
	<form name=Form method=POST onsubmit='return SyncBackup(this);' autocomplete='off' action='$CurrentFileName'>
	<input type=hidden name=ControlID value='$ControlID'>

	<div class='DivInput {$Dir}DivInput'>Backup Type<br>

		<table width=100%>
		<td width=30%>
			<label class=Label> Incremental Backup
				<input type='checkbox' name='Incremental' id='Incremental' value='Incremental' $IncrementalChecked>
				<span class='Checkbox'></span>
			</label>
			
		</td>
		
		<td width=70%>

			<select name='IncrementalTime' class=Select>
			<option value='0'>Disable Incremental Backup</option>
			<option value='60' $IncrementalHourlySelected>Hourly</option>
			<option value='120' $IncrementalTwoSelected>2 Hours</option>
			<option value='180' $IncrementalThreeSelected>3 Hours</option>
			<option value='240' $IncrementalFourSelected>4 Hours</option>
			<option value='300' $IncrementalFiveSelected>5 Hours</option>
			<option value='360' $IncrementalSixSelected>6 Hours</option>
			<option value='420' $IncrementalSevenSelected>7 Hours</option>
			<option value='480' $IncrementalEightSelected>8 Hours</option>
			<option value='540' $IncrementalNineSelected>9 Hours</option>
			<option value='600' $IncrementalTenSelected>10 Hours</option>
			<option value='660' $IncrementalElevenSelected>11 Hours</option>
			<option value='720' $IncrementalTwelveSelected>12 Hours</option>
			<option value='1440' $IncrementalDailySelected>Daily</option>
			</select> 

		</td>
		
		<tr>
		
		<td width=30%>
			<label class=Label> Differential Backup
				<input type='checkbox' name='Differential' id='Differential' value='Differential' $DifferentialChecked>
				<span class='Checkbox'></span>
			</label>

			
		</td>
		
		<td width=70%>
		
			<select name='DifferentialTime' class=Select>
			<option value='0'>Disable Differential Backup</option>
			<option value='1' $DifferentialDailySelected>Daily</option>
			<option value='2' $DifferentialTwoSelected>2 Days</option>
			<option value='3' $DifferentialThreeSelected>3 Days</option>
			<option value='4' $DifferentialFourSelected>4 Days</option>
			<option value='5' $DifferentialFiveSelected>5 Days</option>
			<option value='6' $DifferentialSixSelected>6 Days</option>
			<option value='7' $DifferentialWeeklySelected>Weekly</option>
			<option value='14' $DifferentialFourteenSelected>2 Weeks</option>
			<option value='30' $DifferentialMonthlySelected>Monthly</option>
			</select> 
		
		</td>



		</table>
	
	</div>


	<div class='DivInput {$Dir}DivInput'>Path<br>

		<label class=Label onclick='SyncPath()'> Home (www)
			<input type='checkbox' name='Home' id='Home' value='Home' $HomeChecked>
			<span class='Checkbox'></span>
		</label>

		<label class=Label onclick='SyncPath()'> Mail
			<input type='checkbox' name='Mail' id='Mail' value='Mail' $MailChecked>
			<span class='Checkbox'></span>
		</label>
		
		<input type='text' name='SYNCPath' id=SYNCPath placeholder='PATH' value='$SYNCPath' class=InputText size=40>

	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Destination']}<br>

	<select name='Destination' class=Select>
	<option value='LOCAL' $LOCALSelected>Local</option>
	<option value='SCP' $SCPSelected>Secure Copy (SCP)</option>
	</select>
	
	</div>

	<div class='DivInput {$Dir}DivInput'>{$LNG['Email']}<br>
	<input type='text' name='Email' value='$Email' maxlength=100 class=InputText>
	</div>

	<div class=DivInput id=RemoteServer>{$LNG['RemoteServer']}<br>
	<input type='text' name='RemoteServer' value='{$SyncArray[5]}' maxlength=100 class=InputText size=40>
	</div>

	<div class=DivInput id=RemoteUser>{$LNG['RemoteUser']}<br>
	<input type='text' name='RemoteUser' value='{$SyncArray[6]}' maxlength=100 class=InputText> 
	</div>

	<div class=DivInput id=RemotePassword>{$LNG['RemotePassword']}<br>
	<input type='text' name='RemotePassword' maxlength=100 class=InputText>
	</div>

	<div class=DivInput id=RemoteDir>{$LNG['RemoteDir']}<br>
	<input type='text' name='RemoteDir' value='$RemoteDir' maxlength=100 class=InputText size=40>
	</div>

	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['Save']}' Class=InputButton>
	</div>

</form>
";

  
	
	


	
?>