<?php



include "navigator.php";
$Buttons="";
include "title.php";


$DefaultWebsitePageCode=$_REQUEST['DefaultWebsitePageCode'];
$AccountSuspendedCode=$_REQUEST['AccountSuspendedCode'];
$DiskQuotaExceededCode=$_REQUEST['DiskQuotaExceededCode'];
$BandwidthLimitExceededCode=$_REQUEST['BandwidthLimitExceededCode'];
$AccountUnpublishedCode=$_REQUEST['AccountUnpublishedCode'];
$HostingExpiredCode=$_REQUEST['HostingExpiredCode'];

	if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
	{
		echo "
		You Are Not Allowed to Access This Page
		";

	exit;
	}


if ($DefaultWebsitePageCode!="" or $AccountSuspendedCode!="" or $AccountUnpublishedCode!="")
{

	$Result = SQL("UPDATE Template Set Code='$DefaultWebsitePageCode' where Name='Default Website Page'");
	$Result = SQL("UPDATE Template Set Code='$AccountSuspendedCode' where Name='Account Suspended'");
	$Result = SQL("UPDATE Template Set Code='$DiskQuotaExceededCode' where Name='Disk Quota Exceeded'");
	$Result = SQL("UPDATE Template Set Code='$BandwidthLimitExceededCode' where Name='Bandwidth Limit Exceeded'");
	$Result = SQL("UPDATE Template Set Code='$AccountUnpublishedCode' where Name='Account Unpublished'");
	$Result = SQL("UPDATE Template Set Code='$HostingExpiredCode' where Name='Hosting Expired'");
	
	$Error=SSH ("/go/template",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);

	echo Error("$Error");

exit;
}

	$Result = SQL("select * from Template where TemplateID>=1");
	foreach ($Result as $Row)
	{
	
		if ($Row['Name']=="Default Website Page")
		{
		$DefaultWebsitePageCode=$Row['Code'];
		}
	
		if ($Row['Name']=="Account Suspended")
		{
		$AccountSuspendedCode=$Row['Code'];
		}

		if ($Row['Name']=="Disk Quota Exceeded")
		{
		$DiskQuotaExceededCode=$Row['Code'];
		}

		if ($Row['Name']=="Bandwidth Limit Exceeded")
		{
		$BandwidthLimitExceededCode=$Row['Code'];
		}

		if ($Row['Name']=="Account Unpublished")
		{
		$AccountUnpublishedCode=$Row['Code'];
		}

		if ($Row['Name']=="Hosting Expired")
		{
		$HostingExpiredCode=$Row['Code'];
		}
		
	}
	

	Echo "
	<form name=Form method=POST onsubmit='return Template(this);' autocomplete='off' action='$CurrentFileName'><input type=hidden name=ServiceControl value='$ServiceControl'>

	<div <div class='TitleB {$Dir}TitleB'>{$LNG['DefaultWebsitePage']}</div>
	
	<div class=DivTable>

		<div style='border-left:8px solid #FFFFFF;border-right:8px solid #FFFFFF;border-top:8px solid #FFFFFF;border-bottom:4px solid #FFFFFF;background:#FFFFFF'>
		<textarea rows='10' name='DefaultWebsitePageCode' id='DefaultWebsitePageCode' cols=112 style='width:100%;'>$DefaultWebsitePageCode</textarea>
		</div>
		
	</div>
	
	<div <div class='TitleB {$Dir}TitleB'>{$LNG['AccountSuspended']}</div>
	
	<div class=DivTable>
		<div style='border-left:8px solid #FFFFFF;border-right:8px solid #FFFFFF;border-top:8px solid #FFFFFF;border-bottom:4px solid #FFFFFF;background:#FFFFFF'>
		<textarea rows='10' name='AccountSuspendedCode' id='AccountSuspendedCode' cols=112 style='width:100%'>$AccountSuspendedCode</textarea>
		</div>
	</div>

	<div <div class='TitleB {$Dir}TitleB'>{$LNG['DiskQuotaExceeded']}</div>
	
	<div class=DivTable>
		<div style='border-left:8px solid #FFFFFF;border-right:8px solid #FFFFFF;border-top:8px solid #FFFFFF;border-bottom:4px solid #FFFFFF;background:#FFFFFF'>
		<textarea rows='10' name='DiskQuotaExceededCode' id='DiskQuotaExceededCode' cols=112 style='width:100%'>$DiskQuotaExceededCode</textarea>
		</div>
	</div>
	
	<div <div class='TitleB {$Dir}TitleB'>{$LNG['BandwidthLimitExceeded']}</div>
	
	<div class=DivTable>
		<div style='border-left:8px solid #FFFFFF;border-right:8px solid #FFFFFF;border-top:8px solid #FFFFFF;border-bottom:4px solid #FFFFFF;background:#FFFFFF'>
		<textarea rows='10' name='BandwidthLimitExceededCode' id='BandwidthLimitExceededCode' cols=112 style='width:100%'>$BandwidthLimitExceededCode</textarea>
		</div>
	</div>
		
	<div <div class='TitleB {$Dir}TitleB'>{$LNG['AccountUnpublished']}</div>
	
	<div class=DivTable>
		<div style='border-left:8px solid #FFFFFF;border-right:8px solid #FFFFFF;border-top:8px solid #FFFFFF;border-bottom:4px solid #FFFFFF;background:#FFFFFF'>
		<textarea rows='10' name='AccountUnpublishedCode' id='AccountUnpublishedCode' cols=112 style='width:100%'>$AccountUnpublishedCode</textarea>
		</div>
	</div>

	<div <div class='TitleB {$Dir}TitleB'>{$LNG['HostingExpired']}</div>
	
	<div class=DivTable>
		<div style='border-left:8px solid #FFFFFF;border-right:8px solid #FFFFFF;border-top:8px solid #FFFFFF;border-bottom:4px solid #FFFFFF;background:#FFFFFF'>
		<textarea rows='10' name='HostingExpiredCode' id='HostingExpiredCode' cols=112 style='width:100%'>$HostingExpiredCode</textarea>
		</div>
	</div>

	<div id=DivSubmit class=DivSubmit>
	<input type=submit value='{$LNG['Save']}' class=InputButton>
	</div>

	</form>
	";

?>