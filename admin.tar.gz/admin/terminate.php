<?php
include "nav.php";
$Buttons="";
include "title.php";

if (!StartsWith(getcwd(),"/panel"))
{
	echo "Invalid Go Panel Path";
	exit;
}

$SortBy=$_REQUEST['SortBy'];
$Step=$_REQUEST['Step'];
$Delete=$_REQUEST['Delete'];
$Action=$_REQUEST['Action'];

$Username=ValidateUsername($_REQUEST['Username']);
$Domain=ValidateUsername($_REQUEST['Domain']);
$SiteID=$_REQUEST['SiteID'];
$CompanyNotes=$_REQUEST['CompanyNotes'];
$Action=$_REQUEST['Action'];
$Restore=$_REQUEST['Restore'];
$CheckList=$_REQUEST['CheckList'];


	if ($_SESSION['SessionSSHUsername']!="root" and $_SESSION['SessionSSHUsername']!=$SSHUsername)
	{

		if ($_SESSION['SessionResellerUsername']=="")
		{
		Echo "
		Sorry, You Are Not Allowed to Access This Page
		";

		exit;
		}
	}

    $UserNo=RowCount("select * from Site where RecycleBin=0");
    
If ($Restore==1)
{
include "access.php";

	$Error=SSH ("/go/recover $Username",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	echo Error($Error);
}


If ($Delete==1 and $Step==1)
{
include "access.php";

	echo Error("Delete $Username ? <a href=\"javascript:Load(' $CurrentFileName?Delete=1&&Step=2&Username=$Username&Domain=$Domain&SiteID=$SiteID')\" class=Action>Yes</a> <a href=\"javascript:Load('$CurrentFileName?ServiceControl=$CurrentFileName')\" class=Action>No</a>");
	exit;
	
}

If ($Delete==1 and $Step==2)
{
	include "access.php";

	if ($DemoPassword!="" and stristr($Domain,"demo."))
	{
	echo Error($LNG['ThisFunctionalityNotAvailableDemoMode']);
	exit;
	}
	
	if ($DemoPassword!="" and stristr($Domain,"gpanel.org"))
	{
	echo Error($LNG['ThisFunctionalityNotAvailableDemoMode']);
	exit;
	}

	$Error=SSH ("/go/terminate $Username",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
	
	if (stristr($Error,"Terminated"))
	{
	$Error=str_replace("\n","",$Error);
	echo Error($Error." &nbsp;&nbsp;&nbsp; <a href=\"javascript:Load('$CurrentFileName?Restore=1&Username=$Username&Domain=$Domain')\" class=Action>Undo</a>");	
	}
	else
	{
	echo Error($Error);
	}
	
}
	
	
If ($Action=="Delete")
{

	$CountCheckList=count($CheckList);

	for ($i=0 ;$i<$CountCheckList ; $i++)
	{

		$Domain=$CheckList[$i];
		include "access.php";

		$Result = SQL("select * from Site where Username='$Username'");
		foreach ($Result as $Row)
		{
		$Error=SSH ("/go/terminate {$Row['Username']} bulk",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);
		Echo Error("<h1>{$Row['Domain']}</h1>$Error");
		}
		

		
	}
	$Error=SSH ("/go/httpd",$_SESSION['SessionSSHUsername'],$_SESSION['SessionSSHPassword']);


    

}


	include "search.php";
	
	$Header=DesignCode($Header,"$Control (Header)");
	echo $Header;
	
	$Table="Site";$Field="RecycleBin=0";
	$DefaultSortBy="Domain";
	$DefaultDirection=="ASC";
	include "include/sql.php";    

	$X=0;
    $Result = SQL($Sql);
    foreach ($Result as $Row)
    {
	$SiteID=$Row['SiteID'];
	$Username=$Row['Username'];
	$Domain=$Row['Domain'];

		if ($X%2==0)
		{
		$TDColor="Td";
		}
		else
		{
		$TDColor="TdB";
		}

		if ($Row['Suspend']==1)
		{
		$TDColor="TdEr";
		}


	$CreatedDate=date("D j M Y g:i a", $Row['TimeStamp']);

	$Status="Active";
	if ($Row['RecycleBin']==1)
	{
	$Status="Terminated";
	}
	elseif ($Row['Suspend']==1)
	{
	$Status="Suspended";
	}
	elseif ($Row['Unpublish']==1)
	{
	$Status="Unpublished";
	}
	
	$PingIP=gethostbyname($Domain);

	echo DesignCode($Loop,"$Control (Loop)");

	
	$X++;
	}
	
	$Footer=DesignCode($Footer,"$Control (Footer)");
	echo $Footer;

?>